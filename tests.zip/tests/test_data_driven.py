"""

Data-driven tests — all scenarios loaded from test_data/test_data.xlsx.

New test IDs covered (extends the 19 manual tests):

  Login:       TC-008 to TC-012   (extra credential scenarios)

  Edge Cases:  TC-301 to TC-310   (injection, long input, special chars)

  Navigation:  TC-206 to TC-210   (internal page access)

  Dashboard:   TC-108 to TC-110   (avatar dropdown, page-load readiness)

"""

import time

import pytest

from selenium.webdriver.common.by import By

from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC

from pages.login_page import LoginPage

from pages.dashboard_page import DashboardPage

from pages.base_page import BasePage

from config.config import USERNAME, PASSWORD, BASE_URL

from utils.test_data_reader import (

    login_test_data,

    dashboard_test_data,

    navigation_test_data,

    edge_case_test_data,

)

# ── Helper to build parametrize ids ──────────────────────────────────────────

def _ids(rows):

    return [f"{r.TC_ID}" for r in rows]


# ── Load once at collection time ──────────────────────────────────────────────

_all_login    = login_test_data()

_all_dash     = dashboard_test_data()

_all_nav      = navigation_test_data()

_all_edge     = edge_case_test_data()

# Rows whose Expected_Result indicates login should be rejected

_negative_login = [r for r in _all_login if "rejected" in r.Expected_Result.lower()]

# Extra navigation rows (TC-206 to TC-210) not covered by test_navigation.py

_extra_nav      = [r for r in _all_nav if r.TC_ID not in

                   ("TC-201","TC-202","TC-203","TC-204","TC-205")]

# Extra dashboard rows (TC-108 to TC-110)

_extra_dash     = [r for r in _all_dash if r.TC_ID not in

                   ("TC-101","TC-102","TC-103","TC-104","TC-105","TC-106","TC-107")]


# ══════════════════════════════════════════════════════════════════════════════

    """Parametrized login scenarios read directly from Login_TestData sheet."""

    @pytest.mark.parametrize("row", _negative_login, ids=_ids(_negative_login))

class TestDataDriven:
    def test_login_negative(self, driver, reporter, row):
            """All rows with Expected_Result='Login rejected' must not authenticate."""
            try:
            lp = LoginPage(driver)
            lp.open()
            if row.Username:
            lp.enter_username(str(row.Username))
            if row.Password:
            lp.enter_password(str(row.Password))
            lp.click_login()
            lp.wait_for_page_load()

            assert not lp.is_logged_in(), \
            f"Expected login to be rejected but it succeeded for: {row.Username!r}"

            reporter.add_result(
            test_id   = row.TC_ID,
            test_name = row.Description,
            module    = "Login-DataDriven",
            status    = "PASS",
            screenshot = lp.take_screenshot(row.TC_ID),
            )
            except Exception as e:
            reporter.add_result(
            test_id   = row.TC_ID,
            test_name = row.Description,
            module    = "Login-DataDriven",
            status    = "FAIL",
            error_msg = str(e),
            screenshot = BasePage(driver).take_screenshot(f"{row.TC_ID}_fail"),
            )
            pytest.fail(str(e))

            # ══════════════════════════════════════════════════════════════════════════════

        """Security / boundary edge cases from EdgeCase_TestData sheet."""

        @pytest.mark.parametrize("row", _all_edge, ids=_ids(_all_edge))
    def test_edge_case_login(self, driver, reporter, row):
            """All edge-case inputs must NOT result in successful authentication."""
            try:
            lp = LoginPage(driver)
            lp.open()

            # Map input field and supply the value
            field = (row.Input_Field or "").strip().lower()
            value = str(row.Input_Value or "")

            # Expand shorthand placeholders used in the Excel sheet
            if "(spaces only)" in value:
            value = "     "
            elif "(200 total)" in value:
            value = "a" * 200
            elif "[TAB]" in value:
            value = value.replace("[TAB]", "\t")
            elif "[NULL]" in value:
            value = value.replace("[NULL]", "\x00")

            if field == "username":
            lp.enter_username(value)
            lp.enter_password(PASSWORD)   # valid password — only username is bad
            elif field == "password":
            lp.enter_username(USERNAME)   # valid username — only password is bad
            lp.enter_password(value)
            else:
            lp.enter_username(value)
            lp.enter_password(value)

            lp.click_login()
            lp.wait_for_page_load()

            assert not lp.is_logged_in(), \
            f"Edge-case input should not authenticate: field={field!r} value={value[:50]!r}"

            reporter.add_result(
            test_id   = row.TC_ID,
            test_name = row.Description,
            module    = "EdgeCase-DataDriven",
            status    = "PASS",
            screenshot = lp.take_screenshot(row.TC_ID),
            )
            except Exception as e:
            reporter.add_result(
            test_id   = row.TC_ID,
            test_name = row.Description,
            module    = "EdgeCase-DataDriven",
            status    = "FAIL",
            error_msg = str(e),
            screenshot = BasePage(driver).take_screenshot(f"{row.TC_ID}_fail"),
            )
            pytest.fail(str(e))

            # ══════════════════════════════════════════════════════════════════════════════

        """Extra navigation page-access tests from Navigation_TestData sheet."""

        @pytest.mark.parametrize("row", _extra_nav, ids=_ids(_extra_nav))
    def test_page_access(self, driver, reporter, row):
            """Navigate to each URL; respects Login_Required column from Excel."""
            try:
            target_url = f"https://engineering.ultrivalms.com{row.URL_Path}"
            lp = LoginPage(driver)

            if (row.Login_Required or "").strip().lower() == "yes":
            lp.login(USERNAME, PASSWORD)
            assert lp.is_logged_in(), "Pre-condition: login must succeed"
            driver.get(target_url)
            BasePage(driver).wait_for_page_load()
            assert lp.is_logged_in() or "UserName" not in driver.page_source, \
            "Unexpectedly redirected to login page"
            else:
            # Unauthenticated — just open the URL
            driver.get(target_url)
            BasePage(driver).wait_for_page_load()

            if row.TC_ID == "TC-210":
            # Verify Forgot Password link is present on the login page
            present = lp.is_element_present(
            By.XPATH, "//a[contains(@href,'ForgotPassword')]", timeout=8)
            assert present, "Forgot Password link not found on login page"
            else:
            assert len(driver.page_source) > 200, "Page appears empty"

            reporter.add_result(
            test_id   = row.TC_ID,
            test_name = row.Description,
            module    = "Navigation-DataDriven",
            status    = "PASS",
            screenshot = BasePage(driver).take_screenshot(row.TC_ID),
            )
            except Exception as e:
            reporter.add_result(
            test_id   = row.TC_ID,
            test_name = row.Description,
            module    = "Navigation-DataDriven",
            status    = "FAIL",
            error_msg = str(e),
            screenshot = BasePage(driver).take_screenshot(f"{row.TC_ID}_fail"),
            )
            pytest.fail(str(e))

            # ══════════════════════════════════════════════════════════════════════════════

        """Extra dashboard element checks from Dashboard_TestData sheet."""
    def test_avatar_dropdown_trigger(self, driver, reporter):
            """TC-109: Avatar button (dropdown trigger) should be visible."""
            row = next((r for r in _extra_dash if r.TC_ID == "TC-109"), None)
            if not row:
            pytest.skip("TC-109 not found in Dashboard_TestData")
            try:
            LoginPage(driver).login(USERNAME, PASSWORD)
            present = BasePage(driver).is_element_present(
            By.XPATH,
            "//button[contains(@class,'avatar-btn') or contains(@class,'dropdown-toggle')]",
            timeout=10,
            )
            assert present, "Avatar dropdown trigger button not found"

            reporter.add_result(
            test_id   = "TC-109",
            test_name = row.Description,
            module    = "Dashboard-DataDriven",
            status    = "PASS",
            screenshot = BasePage(driver).take_screenshot("TC-109"),
            )
            except Exception as e:
            reporter.add_result(
            test_id="TC-109", test_name=row.Description,
            module="Dashboard-DataDriven", status="FAIL", error_msg=str(e),
            screenshot=BasePage(driver).take_screenshot("TC-109_fail"),
            )
            pytest.fail(str(e))
    def test_my_account_link(self, driver, reporter):
            """TC-110: My Account link inside avatar dropdown should be present."""
            row = next((r for r in _extra_dash if r.TC_ID == "TC-110"), None)
            if not row:
            pytest.skip("TC-110 not found in Dashboard_TestData")
            try:
            LoginPage(driver).login(USERNAME, PASSWORD)
            present = BasePage(driver).is_element_present(
            By.XPATH,
            "//a[contains(@href,'MyAccount/Home')]",
            timeout=10,
            )
            assert present, "My Account link not found in DOM"

            reporter.add_result(
            test_id   = "TC-110",
            test_name = row.Description,
            module    = "Dashboard-DataDriven",
            status    = "PASS",
            screenshot = BasePage(driver).take_screenshot("TC-110"),
            )
            except Exception as e:
            reporter.add_result(
            test_id="TC-110", test_name=row.Description,
            module="Dashboard-DataDriven", status="FAIL", error_msg=str(e),
            screenshot=BasePage(driver).take_screenshot("TC-110_fail"),
            )
            pytest.fail(str(e))
    def test_page_ready_state(self, driver, reporter):
            """TC-108: document.readyState must be 'complete' within page load timeout."""
            row = next((r for r in _extra_dash if r.TC_ID == "TC-108"), None)
            if not row:
            pytest.skip("TC-108 not found in Dashboard_TestData")
            try:
            LoginPage(driver).login(USERNAME, PASSWORD)
            t0 = time.time()
            WebDriverWait(driver, 30).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
            )
            elapsed = round(time.time() - t0, 2)

            reporter.add_result(
            test_id   = "TC-108",
            test_name = f"{row.Description} ({elapsed}s)",
            module    = "Dashboard-DataDriven",
            status    = "PASS",
            duration  = elapsed,
            screenshot = BasePage(driver).take_screenshot("TC-108"),
            )
            except Exception as e:
            reporter.add_result(
            test_id="TC-108", test_name=row.Description,
            module="Dashboard-DataDriven", status="FAIL", error_msg=str(e),
            screenshot=BasePage(driver).take_screenshot("TC-108_fail"),
            )
            pytest.fail(str(e))