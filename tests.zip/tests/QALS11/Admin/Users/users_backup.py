"""
QALS11 | Admin > Users — Complete User Management Test Suite
=============================================================
Application : https://engineering.ultrivalms.com/QALS1011
Login        : buyeruser / Ultriva!23
Browser      : Chrome (visible, maximised)

What this file tests:
  1. TestUsersList   — Navigate to the Admin > Users list page
  2. TestEditUser    — Edit an existing user (PlantAdm01)
  3. TestCreateUsers — Create 5 new Plant Administrator users and
                       export their credentials to an Excel report

How to run (from qa_automation/ folder):
    pytest tests/QALS11/Admin/Users/users.py -v -s
"""

# ── Standard library imports ────────────────────────────────────────────
import os
import time
from datetime import datetime

# ── Third-party imports ─────────────────────────────────────────────────
import pytest
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException


# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION — change these values when testing a different environment
# ══════════════════════════════════════════════════════════════════════════════

# Base URL of the QA site (no trailing slash)
BASE_URL = "https://engineering.ultrivalms.com/QALS1011"

# Admin account used to log in for all tests
ADMIN_USER = "buyeruser"
ADMIN_PASS = "Ultriva!23"

# Short pause (seconds) between steps — lets you see what the browser is doing
PAUSE = 2

# How long (seconds) WebDriverWait will try before giving up
WAIT = 15

# Shared email used for all newly created users
SHARED_EMAIL = "vseelam@uplandsoftware.com"

# Account type assigned to all new users
ACCOUNT_TYPE = "Plant Administrators"

# Where the Excel credentials report will be saved
#   __file__  →  .../tests/QALS11/Admin/Users/users.py
#   go up 4 levels to reach qa_automation/, then into reports/
CREDS_REPORT = os.path.join(
    os.path.dirname(__file__),
    "..", "..", "..", "..", "reports", "user_credentials.xlsx"
)

# ── User record being edited in TestEditUser ────────────────────────────
TARGET_UID = "PlantAdm01"   # User ID shown in the Users list

# New values to write into the PlantAdm01 edit form
UPDATED_USER = {
    "first_name": "Alice",
    "mi": "A",
    "last_name": "Johnson",
    "work_phone": "5551001001",
    "email": "vseelam@uplandsoftware.com",
    "buyer_code": "BC001",
    "password": "Admin@5678!",
    "account_type": "Plant Administrators",
}

# ── 5 new users to create in TestCreateUsers ─────────────────────────────────
# Each user has a unique User ID and password but shares the same email address.
# Password rules: > 8 chars, at least 1 number, 1 UPPER, 1 lower, 1 symbol
USERS_TO_CREATE = [
    {
        "first_name": "Alice",
        "mi": "A",
        "last_name": "Johnson",
        "work_phone": "5551001001",
        "mobile": "5551001100",
        "email": SHARED_EMAIL,
        "user_id": "PlantAdm01",
        "buyer_code": "BC001",
        "password": "Admin@1234!",
        "account_type": ACCOUNT_TYPE,
    },
    {
        "first_name": "Bob",
        "mi": "B",
        "last_name": "Martinez",
        "work_phone": "5552002002",
        "mobile": "5552002200",
        "email": SHARED_EMAIL,
        "user_id": "PlantAdm02",
        "buyer_code": "BC002",
        "password": "Secure#2Bx9!",
        "account_type": ACCOUNT_TYPE,
    },
    {
        "first_name": "Carol",
        "mi": "C",
        "last_name": "Davis",
        "work_phone": "5553003003",
        "mobile": "5553003300",
        "email": SHARED_EMAIL,
        "user_id": "PlantAdm03",
        "buyer_code": "BC003",
        "password": "Plant$3Cdvs!",
        "account_type": ACCOUNT_TYPE,
    },
    {
        "first_name": "David",
        "mi": "D",
        "last_name": "Wilson",
        "work_phone": "5554004004",
        "mobile": "5554004400",
        "email": SHARED_EMAIL,
        "user_id": "PlantAdm04",
        "buyer_code": "BC004",
        "password": "Test!4Xdw9z@",
        "account_type": ACCOUNT_TYPE,
    },
    {
        "first_name": "Emma",
        "mi": "E",
        "last_name": "Thompson",
        "work_phone": "5555005005",
        "mobile": "5555005500",
        "email": SHARED_EMAIL,
        "user_id": "PlantAdm05",
        "buyer_code": "BC005",
        "password": "Build%5eNop#",
        "account_type": ACCOUNT_TYPE,
    },
    # ── New user added on 15-Apr-2026 ───────────────────────────────────────
    {
        "first_name": "User",
        "mi": "",
        "last_name": "150426",
        "work_phone": "5556006006",
        "mobile": "5556006600",
        "email": SHARED_EMAIL,
        "user_id": "User150426",
        "buyer_code": "BC006",
        "password": "Ultriva!23",
        "account_type": ACCOUNT_TYPE,
    },
]

# Shared list that collects results during TestCreateUsers
# (filled as each user is created, then exported in the last test)
created_users: list[dict] = []


# ══════════════════════════════════════════════════════════════════════════════
# BROWSER FIXTURE
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="module")
def driver():
    """
    Launch a visible Chrome window that is shared across all tests
    in this file (scope='module').
    The browser stays open after the suite finishes so you can inspect results.
    """
    options = webdriver.ChromeOptions()
    # full window
    options.add_argument("--start-maximized")
    options.add_experimental_option(
        "excludeSwitches",
        ["enable-logging"])  # cleaner console

    browser = webdriver.Chrome(options=options)
    browser.set_page_load_timeout(30)   # fail if a page takes > 30 s to load

    yield browser   # every test gets this browser object
    # NOTE: browser.quit() is intentionally omitted — window stays open


# ══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS — small reusable utilities used by the test classes
# ══════════════════════════════════════════════════════════════════════════════

def wait_for_clickable(driver, by, locator, timeout=WAIT):
    """
    Wait until the element is clickable, then return it.
    Raises TimeoutException if not found within `timeout` seconds.
    """
    return WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, locator))
    )


def wait_for_visible(driver, by, locator, timeout=WAIT):
    """Wait until the element is visible on the page, then return it."""
    return WebDriverWait(driver, timeout).until(
        EC.visibility_of_element_located((by, locator))
    )


def page_ready(driver, timeout=WAIT):
    """
    Block until the browser says the page is fully loaded
    (document.readyState == 'complete').
    """
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )


def clear_and_type(driver, by, locator, text, timeout=WAIT):
    """
    Find a field, clear any existing value, then type the new text.
    Returns the element so callers can do further actions on it.
    """
    el = WebDriverWait(driver, timeout).until(
        EC.visibility_of_element_located((by, locator))
    )
    el.clear()
    el.send_keys(text)
    return el


def dismiss_modal_if_open(driver):
    """
    Close Ultriva's modal dialog (id='Modal-modal-alert-id') if it is blocking
    the page. Tries clicking the 'No' button first, then the × close button.
    Silently does nothing if no modal is present.
    """
    try:
        modal = driver.find_element(By.ID, "Modal-modal-alert-id")
        if modal.is_displayed():
            for xpath in [
                ".//button[normalize-space(.)='No']",
                ".//button[contains(@class,'close')]",
                ".//button[@data-dismiss='modal']",
            ]:
                try:
                    btn = modal.find_element(By.XPATH, xpath)
                    if btn.is_displayed():
                        driver.execute_script("arguments[0].click();", btn)
                        time.sleep(1)
                        print("  [INFO] Dismissed open modal dialog")
                        return
                except Exception:
                    pass
    except Exception:
        pass  # No modal present — continue normally


def select_dropdown_option(driver, account_type):
    """
    Find the Account Type dropdown and choose the correct option.
    Tries several selector patterns because the field name varies
    across different Ultriva builds.
    Returns True if the selection succeeded, False otherwise.
    """
    # List of selectors to try in order
    selectors = [
        (By.NAME, "USR$AccountType"),
        (By.ID, "USR_AccountType"),
        (By.NAME, "AccountType"),
        (By.ID, "AccountType"),
        (By.XPATH, "//select[contains(@name,'AccountType') or contains(@id,'AccountType')]"),
        (By.XPATH, "//select[option[contains(text(),'Plant Administrator')]]"),
    ]

    for by, val in selectors:
        try:
            # Wait up to 5 s for this selector to work
            el = WebDriverWait(
                driver, 5).until(
                EC.visibility_of_element_located(
                    (by, val)))
            sel = Select(el)

            # Try exact text match first
            try:
                sel.select_by_visible_text(account_type)
                return True
            except Exception:
                pass

            # Fall back to partial text match
            for option in sel.options:
                if account_type.lower() in option.text.lower():
                    sel.select_by_visible_text(option.text.strip())
                    return True
        except Exception:
            continue   # try next selector

    return False   # none of the selectors worked


def fill_user_form(driver, user: dict) -> bool:
    """
    Open the User Create page and fill in all mandatory and optional fields.

    Steps performed:
      1. Navigate to /User/Create
      2. Fill personal information fields
      3. Fill account information fields
      4. Select Account Type dropdown
      5. Enter and confirm the password
      6. Click the Save button
      7. Check for error messages

    Returns True if saved without errors, False if any error appeared.
    """

    # Step 1 — Open the Create User page
    driver.get(f"{BASE_URL}/User/Create")
    page_ready(driver)
    time.sleep(PAUSE)   # brief pause so UI fully renders

    # Step 2 & 3 — Fields to fill: (By, locator, data_key, is_required)
    # Field names use Ultriva's PRS$ (personal) and USR$ (account) prefixes
    FIELD_MAP = [
        (By.NAME, "PRS$FirstName", "first_name", True),
        (By.NAME, "PRS$MI", "mi", False),
        (By.NAME, "PRS$LastName", "last_name", True),
        (By.NAME, "PRS$WorkPhone", "work_phone", True),
        (By.NAME, "PRS$MobilePhone", "mobile", False),
        (By.NAME, "PRS$EmailID", "email", True),
        (By.NAME, "USR$LoginName", "user_id", True),
        (By.NAME, "USR$BuyerCode", "buyer_code", False),
    ]

    # Alternative names tried if the primary name does not exist on the page
    ALT_NAMES = {
        "PRS$FirstName": ["FirstName", "User_FirstName", "txtFirstName"],
        "PRS$MI": ["MI", "User_MI"],
        "PRS$LastName": ["LastName", "User_LastName", "txtLastName"],
        "PRS$WorkPhone": ["WorkPhone", "User_WorkPhone", "txtWorkPhone"],
        "PRS$MobilePhone": ["MobilePhone", "User_MobilePhone"],
        "PRS$EmailID": ["EmailID", "Email", "User_Email", "txtEmail"],
        "USR$LoginName": ["LoginName", "UsrId", "UserId", "User_ID"],
        "USR$BuyerCode": ["BuyerCode", "User_BuyerCode"],
    }

    def _type_field(name, value):
        """Try the primary name, then alternatives, then by ID."""
        # Primary name
        try:
            clear_and_type(driver, By.NAME, name, value, timeout=6)
            return True
        except Exception:
            pass
        # Alternate names
        for alt in ALT_NAMES.get(name, []):
            try:
                clear_and_type(driver, By.NAME, alt, value, timeout=4)
                return True
            except Exception:
                pass
        # ID fallback
        try:
            clear_and_type(driver, By.ID, name, value, timeout=4)
            return True
        except Exception:
            pass
        return False

    # Fill each field if a value exists
    for by, locator, data_key, required in FIELD_MAP:
        val = user.get(data_key, "")
        if val:
            ok = _type_field(locator, val)
            if not ok and required:
                # Log a warning but keep going — maybe the form doesn't have
                # this field
                print(f"  [WARN] Could not fill required field '{locator}'")

    # Step 4 — Account Type dropdown
    if not select_dropdown_option(driver, user["account_type"]):
        print(f"  [WARN] Could not set Account Type for {user['user_id']}")

    # Step 5 — Password and Confirm Password
    _type_field("MISC$Password", user["password"])
    _type_field("MISC$ConfirmPassword", user["password"])

    time.sleep(1)   # small pause before clicking Save

    # Step 6 — Click Save
    # Try several selectors because the Save element varies across builds
    save_selectors = [
        (By.XPATH, "//a[@title='Save' and contains(@onclick,'frmEntryPage_onSubmit')]"),
        (By.XPATH, "//a[contains(@onclick,'frmEntryPage_onSubmit')]"),
        (By.XPATH, "//a[@title='Save']"),
        (By.XPATH, "//input[@value='Save'] | //button[normalize-space(text())='Save']"),
        (By.ID, "entryPGSubmit"),
        (By.CSS_SELECTOR, "[value='Save'], [title='Save']"),
    ]
    saved = False
    for by, sel in save_selectors:
        try:
            btn = WebDriverWait(
                driver, 6).until(
                EC.element_to_be_clickable(
                    (by, sel)))
            btn.click()
            saved = True
            break
        except Exception:
            continue

    if not saved:
        print(f"  [ERROR] Save button not found for {user['user_id']}")
        return False

    # Wait for page to finish loading after Save
    page_ready(driver)
    time.sleep(PAUSE)

    # Step 7 — Check whether any error messages appeared after Save
    error_xpaths = [
        "//*[contains(@class,'error') or contains(@class,'alert-danger') or contains(@class,'validation')]",
        "//*[contains(@id,'error') or contains(@id,'Error')]",
    ]
    for xpath in error_xpaths:
        for el in driver.find_elements(By.XPATH, xpath):
            txt = el.text.strip()
            if txt and len(txt) > 3:
                print(f"  [FORM ERROR] {txt[:200]}")
                return False

    return True   # saved successfully with no errors


# ══════════════════════════════════════════════════════════════════════════════
# EXCEL EXPORT HELPERS — used by TestCreateUsers to save a credentials report
# ══════════════════════════════════════════════════════════════════════════════

# Colour hex codes for the Excel workbook styling
_DARK_BLUE = "1F4E79"
_LIGHT_BLUE = "BDD7EE"
_GREEN = "92D050"
_RED = "FF6B6B"
_BORDER = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)


def _header_font(size=11):
    """White bold font used in column header rows."""
    return Font(bold=True, color="FFFFFF", size=size, name="Calibri")


def _body_font(bold=False):
    """Regular font used in data rows."""
    return Font(bold=bold, size=10, name="Calibri")


def _solid_fill(hex_color):
    """Create a solid background fill from a hex colour string."""
    return PatternFill("solid", fgColor=hex_color)


def _center():
    """Centered alignment with text wrapping enabled."""
    return Alignment(horizontal="center", vertical="center", wrap_text=True)


def _left():
    """Left-aligned with text wrapping enabled."""
    return Alignment(horizontal="left", vertical="center", wrap_text=True)


def export_credentials_to_excel(records: list[dict], path: str):
    """
    Write user IDs, passwords and statuses to a formatted Excel workbook.

    Sheet 1 – "User Credentials" : one row per user
    Sheet 2 – "Summary"          : totals (success / failed)

    Parameters:
        records  List of dicts with keys: user_id, password, status, created_at
        path     Absolute file path where the .xlsx file will be saved

    Returns the absolute path of the saved file.
    """
    # Make sure the output folder exists
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

    wb = Workbook()

    # ── Sheet 1: User Credentials ─────────────────────────────────────────
    ws = wb.active
    ws.title = "User Credentials"
    ws.sheet_view.showGridLines = False

    # Title banner spanning all columns
    ws.merge_cells("A1:E1")
    title = ws["A1"]
    title.value = "QALS1011 — Plant Administrator User Credentials"
    title.font = Font(bold=True, color="FFFFFF", size=13, name="Calibri")
    title.fill = _solid_fill(_DARK_BLUE)
    title.alignment = _center()
    ws.row_dimensions[1].height = 28

    # Sub-header: timestamp and shared email
    ws.merge_cells("A2:E2")
    ts = ws["A2"]
    ts.value = (
        f"Generated: {datetime.now().strftime('%Y-%m-%d  %H:%M:%S')}"
        f"  |  Email: {SHARED_EMAIL}"
    )
    ts.font = Font(italic=True, size=10, name="Calibri", color="444444")
    ts.fill = _solid_fill(_LIGHT_BLUE)
    ts.alignment = _center()
    ws.row_dimensions[2].height = 18

    # Column header row
    COLUMNS = [
        ("#", 5),
        ("User ID", 18),
        ("Password", 22),
        ("Status", 12),
        ("Created At", 22),
    ]
    for col_idx, (header_text, col_width) in enumerate(COLUMNS, 1):
        cell = ws.cell(row=3, column=col_idx, value=header_text)
        cell.font = _header_font()
        cell.fill = _solid_fill(_DARK_BLUE)
        cell.alignment = _center()
        cell.border = _BORDER
        ws.column_dimensions[get_column_letter(col_idx)].width = col_width
    ws.row_dimensions[3].height = 20

    # Data rows — alternating row colours for readability
    ALT_ROW_COLOR = "D6E4F0"
    for row_num, rec in enumerate(records, 1):
        excel_row = row_num + 3               # offset below the 3-row header
        row_fill = ALT_ROW_COLOR if row_num % 2 == 0 else "FFFFFF"
        status = rec.get("status", "Unknown")
        status_fill = _solid_fill(
            _GREEN) if status == "Created" else _solid_fill(_RED)

        # Each tuple: (cell value, background fill, alignment)
        row_data = [
            (row_num, _solid_fill(row_fill), _center()),
            (rec.get("user_id"), _solid_fill(row_fill), _left()),
            (rec.get("password"), _solid_fill(row_fill), _left()),
            (status, status_fill, _center()),
            (rec.get("created_at"), _solid_fill(row_fill), _center()),
        ]
        for col_idx, (value, fill, align) in enumerate(row_data, 1):
            c = ws.cell(row=excel_row, column=col_idx, value=value)
            c.font = _body_font()
            c.fill = fill
            c.alignment = align
            c.border = _BORDER
        ws.row_dimensions[excel_row].height = 18

    # Freeze rows above and keep headers visible when scrolling
    ws.freeze_panes = "A4"

    # ── Sheet 2: Summary ──────────────────────────────────────────────────
    ws2 = wb.create_sheet("Summary")
    ws2.sheet_view.showGridLines = False

    ws2.merge_cells("A1:B1")
    s_title = ws2["A1"]
    s_title.value = "User Creation Summary"
    s_title.font = Font(bold=True, color="FFFFFF", size=13, name="Calibri")
    s_title.fill = _solid_fill(_DARK_BLUE)
    s_title.alignment = _center()
    ws2.row_dimensions[1].height = 28

    total = len(records)
    success = sum(1 for r in records if r.get("status") == "Created")
    failed = total - success

    summary_data = [
        ("Total Users Attempted", total),
        ("Successfully Created", success),
        ("Failed", failed),
        ("Shared Email", SHARED_EMAIL),
        ("Account Type", ACCOUNT_TYPE),
        ("Run Date", datetime.now().strftime("%Y-%m-%d")),
    ]

    ws2.column_dimensions["A"].width = 28
    ws2.column_dimensions["B"].width = 38

    for row_i, (label, value) in enumerate(summary_data, 2):
        # Label cell
        lc = ws2.cell(row=row_i, column=1, value=label)
        lc.font = _body_font(bold=True)
        lc.fill = _solid_fill(_LIGHT_BLUE)
        lc.alignment = _left()
        lc.border = _BORDER

        # Value cell
        vc = ws2.cell(row=row_i, column=2, value=value)
        vc.font = _body_font()
        vc.alignment = _left()
        vc.border = _BORDER

    wb.save(path)
    print(f"\n[Export] Credentials saved → {os.path.abspath(path)}")
    return path


# ══════════════════════════════════════════════════════════════════════════════
# TEST CLASS 1 — Navigate to the Users list and verify it loads
# ══════════════════════════════════════════════════════════════════════════════

class TestUsersList:
    """
    Verify that a logged-in admin can reach the Admin > Users list page
    and that user rows are visible in the table.

    Test steps:
      test_01 — Log in
      test_02 — Navigate to Admin Home
      test_03 — Click the Users menu and see the list
    """

    # ------------------------------------------------------------------
    # Step 1 — Log in
    # ------------------------------------------------------------------
    def test_01_login(self, driver):
        """Open the QA site and log in with admin credentials."""

        # Open the application home page
        driver.get(BASE_URL)
        page_ready(driver)

        # Type username and password into the login form
        wait_for_clickable(driver, By.ID, "UserName").send_keys(ADMIN_USER)
        driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)

        # Click the Login button
        driver.find_element(By.ID, "login-button").click()
        page_ready(driver)
        time.sleep(PAUSE)   # pause — watch the dashboard appear

        # Confirm we are still on the correct site
        assert "ultrivalms" in driver.current_url, (
            f"Login may have failed. URL: {driver.current_url}"
        )

    # ------------------------------------------------------------------
    # Step 2 — Open Admin module
    # ------------------------------------------------------------------
    def test_02_open_admin_module(self, driver):
        """Click the Admin navigation link and land on Admin Home."""

        # Find the Admin link in the top navigation bar
        admin_link = wait_for_clickable(
            driver, By.XPATH,
            "//a[contains(@href,'Admin/Home') or contains(normalize-space(.),'Admin')]"
        )
        admin_link.click()
        page_ready(driver)
        time.sleep(PAUSE)   # pause — watch Admin Home load

        # Confirm we reached an Admin page
        assert "Admin" in driver.title or "ultrivalms" in driver.current_url, (
            "Did not reach the Admin Home page"
        )

    # ------------------------------------------------------------------
    # Step 3 — Click Users menu and verify the list
    # ------------------------------------------------------------------
    def test_03_view_users_list(self, driver):
        """Click the Users link in the Admin sidebar and display the list."""

        # Try clicking the Users navigation link
        try:
            users_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((
                    By.XPATH,
                    "//a[contains(@href,'User/List')]"
                    " | //a[normalize-space(.)='Users']"
                    " | //a[normalize-space(.)='User']"
                ))
            )
            users_link.click()
        except TimeoutException:
            # Fallback: go directly to the list URL if the link is not found
            driver.get(f"{BASE_URL}/User/List")

        page_ready(driver)
        time.sleep(PAUSE)   # pause — watch the Users list load

        # Warn if the page shows a system error (e.g., permissions issue)
        if "System Error" in driver.page_source or "An error occurred" in driver.page_source:
            print("\n  WARNING: Page shows a system error — check user permissions")

        # Print the first 15 user rows to the console for quick visibility
        rows = driver.find_elements(By.XPATH, "//tbody/tr[td]")
        print(f"\n  Users list — {len(rows)} user(s) displayed")
        for i, row in enumerate(rows[:15], 1):
            cols = row.find_elements(By.TAG_NAME, "td")
            cells = " | ".join(c.text.strip() for c in cols if c.text.strip())
            if cells:
                print(f"  [{i}] {cells[:150]}")

        time.sleep(PAUSE)   # extra pause — keep the list visible

        # Confirm we stayed on the correct site
        assert "ultrivalms" in driver.current_url, "Browser left the site unexpectedly"


# ══════════════════════════════════════════════════════════════════════════════
# TEST CLASS 2 — Edit an existing user (PlantAdm01)
# ══════════════════════════════════════════════════════════════════════════════

class TestEditUser:
    """
    Select the user PlantAdm01 from the Users list and update all
    mandatory fields, then save.

    Test steps:
      test_01 — Log in
      test_02 — Navigate to the Users list
      test_03 — Find PlantAdm01 in the list and open the Edit page
      test_04 — Fill in all mandatory fields with new values
      test_05 — Click Save and confirm no error appeared
    """

    # ------------------------------------------------------------------
    # Step 1 — Log in
    # ------------------------------------------------------------------
    def test_01_login(self, driver):
        """Log in with admin credentials."""

        driver.get(BASE_URL)
        page_ready(driver)

        # Enter credentials
        wait_for_clickable(driver, By.ID, "UserName").send_keys(ADMIN_USER)
        driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
        driver.find_element(By.ID, "login-button").click()

        page_ready(driver)
        time.sleep(PAUSE)

        assert "ultrivalms" in driver.current_url, (
            f"Login failed. URL: {driver.current_url}"
        )

    # ------------------------------------------------------------------
    # Step 2 — Go to Users list
    # ------------------------------------------------------------------
    def test_02_navigate_to_users_list(self, driver):
        """Open Admin > User List by navigating directly to the URL."""

        # Navigate directly to the User List page
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)   # pause — confirm the list is visible

        assert "ultrivalms" in driver.current_url, "Did not reach the Users list"

    # ------------------------------------------------------------------
    # Step 3 — Find the target user row and open its Edit page
    # ------------------------------------------------------------------
    def test_03_open_edit_page_for_plantadm01(self, driver):
        """
        Find PlantAdm01 in the table, read its GID attribute,
        then navigate to the Update page using that GID.
        """

        # Each table row has a gid="USR..." attribute that identifies the user
        # We find the row where the first column text matches TARGET_UID
        row = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//tr[td[normalize-space(text())='{TARGET_UID}']]"
            ))
        )

        # Read the gid value from that row
        gid = row.get_attribute("gid")
        assert gid, f"Could not read gid attribute from {TARGET_UID} row"

        # Build and navigate to the edit URL using the gid
        driver.get(f"{BASE_URL}/User/Update?GID={gid}")
        page_ready(driver)
        time.sleep(PAUSE)   # pause — confirm the edit form is open

        # Confirm the URL contains 'User'
        assert "User" in driver.current_url, "Did not reach the User edit page"

    # ------------------------------------------------------------------
    # Step 4 — Update all mandatory fields
    # ------------------------------------------------------------------
    def test_04_fill_in_mandatory_fields(self, driver):
        """Type new values into every mandatory field on the edit form."""

        # Personal Information section (field names use the PRS$ prefix)
        clear_and_type(
            driver,
            By.NAME,
            "PRS$FirstName",
            UPDATED_USER["first_name"])
        clear_and_type(driver, By.NAME, "PRS$MI", UPDATED_USER["mi"])
        clear_and_type(
            driver,
            By.NAME,
            "PRS$LastName",
            UPDATED_USER["last_name"])
        clear_and_type(
            driver,
            By.NAME,
            "PRS$WorkPhone",
            UPDATED_USER["work_phone"])
        clear_and_type(driver, By.NAME, "PRS$EmailID", UPDATED_USER["email"])

        # Account Information section (field names use the USR$ prefix)
        clear_and_type(
            driver,
            By.NAME,
            "USR$BuyerCode",
            UPDATED_USER["buyer_code"])

        # Account Type dropdown — try two fallback selectors
        for sel_by, sel_val in [
            (By.NAME, "USR$AccountType"),
            (By.XPATH, "//select[contains(@name,'AccountType') or contains(@id,'AccountType')]"),
        ]:
            try:
                el = WebDriverWait(
                    driver, 6).until(
                    EC.visibility_of_element_located(
                        (sel_by, sel_val)))
                sel = Select(el)
                # Find and select the matching option
                for option in sel.options:
                    if UPDATED_USER["account_type"].lower(
                    ) in option.text.lower():
                        sel.select_by_visible_text(option.text.strip())
                        break
                break   # stop trying selectors after the first success
            except Exception:
                continue

        # Password fields
        clear_and_type(
            driver,
            By.NAME,
            "MISC$Password",
            UPDATED_USER["password"])
        clear_and_type(
            driver,
            By.NAME,
            "MISC$ConfirmPassword",
            UPDATED_USER["password"])

        time.sleep(1)   # small pause before saving

    # ------------------------------------------------------------------
    # Step 5 — Click Save and verify no errors
    # ------------------------------------------------------------------
    def test_05_save_user(self, driver):
        """Click the Save button and confirm the form saved without errors."""

        # The Save button on Ultriva edit pages is a <span id="entryPGSubmit">
        save_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((By.ID, "entryPGSubmit"))
        )
        save_btn.click()
        page_ready(driver)
        time.sleep(PAUSE)   # pause — watch the save result

        # Check whether any visible error banners appeared
        error_elements = driver.find_elements(
            By.XPATH,
            "//*[contains(@class,'error') or contains(@class,'alert-danger')]"
        )
        visible_errors = [
            e.text.strip() for e in error_elements
            if e.is_displayed() and e.text.strip()
        ]

        # Fail the test and print the errors if any were found
        assert not visible_errors, f"Save produced errors: {visible_errors}"

        print(f"\n  User '{TARGET_UID}' updated successfully.")


# ══════════════════════════════════════════════════════════════════════════════
# TEST CLASS 3 — Create 5 new Plant Administrator users
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateUsers:
    """
    Log in, create 6 Plant Administrator users one by one,
    then export all user IDs and passwords to an Excel report.

    Test steps:
      test_01 — Log in
      test_02 — Create PlantAdm01 (Alice Johnson)
      test_03 — Create PlantAdm02 (Bob Martinez)
      test_04 — Create PlantAdm03 (Carol Davis)
      test_05 — Create PlantAdm04 (David Wilson)
      test_06 — Create PlantAdm05 (Emma Thompson)
      test_07 — Create User150426  (added 15-Apr-2026)
      test_08 — Export credentials to Excel
    """

    # ------------------------------------------------------------------
    # Step 1 — Log in
    # ------------------------------------------------------------------
    def test_01_login_as_admin(self, driver):
        """Log in with the admin account before creating users."""

        driver.get(BASE_URL)
        page_ready(driver)

        # Fill in login form
        wait_for_clickable(driver, By.ID, "UserName").send_keys(ADMIN_USER)
        driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
        driver.find_element(By.ID, "login-button").click()

        page_ready(driver)
        time.sleep(PAUSE)

        assert "ultrivalms" in driver.current_url, (
            f"Login failed. URL: {driver.current_url}"
        )
        print(f"\n[LOGIN] Logged in as {ADMIN_USER!r}")

    # ------------------------------------------------------------------
    # Internal helper — called by each creation test below
    # ------------------------------------------------------------------
    def _create_one_user(self, driver, index: int):
        """
        Create the user at USERS_TO_CREATE[index].
        Records the result (Created / Failed) into `created_users`.
        Uses pytest.xfail for a failed creation so the remaining tests
        still run instead of being aborted.
        """
        user = USERS_TO_CREATE[index]
        uid = user["user_id"]
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        print(f"\n[CREATE] {uid} — {user['first_name']} {user['last_name']}")

        status = "Failed"
        try:
            # fill_user_form() handles all form filling and clicking Save
            ok = fill_user_form(driver, user)
            status = "Created" if ok else "Failed"
        except Exception as exc:
            print(f"  [EXCEPTION] {exc}")
            status = "Failed"

        # Store the result so test_07 can export everything at the end
        created_users.append({
            "user_id": uid,
            "password": user["password"],
            "status": status,
            "created_at": created_at,
        })
        print(f"  → {uid}  status={status}")

        # If this user failed, mark as expected-failure (xfail) instead of
        # stopping the whole suite — all remaining users will still be tried
        if status == "Failed":
            pytest.xfail(
                f"User '{uid}' creation failed (see console for details)")

    # ------------------------------------------------------------------
    # Steps 2–6 — One test per user for clean pytest output
    # ------------------------------------------------------------------
    def test_02_create_plantadm01(self, driver):
        """Create Alice Johnson — user ID: PlantAdm01."""
        self._create_one_user(driver, 0)

    def test_03_create_plantadm02(self, driver):
        """Create Bob Martinez — user ID: PlantAdm02."""
        self._create_one_user(driver, 1)

    def test_04_create_plantadm03(self, driver):
        """Create Carol Davis — user ID: PlantAdm03."""
        self._create_one_user(driver, 2)

    def test_05_create_plantadm04(self, driver):
        """Create David Wilson — user ID: PlantAdm04."""
        self._create_one_user(driver, 3)

    def test_06_create_plantadm05(self, driver):
        """Create Emma Thompson — user ID: PlantAdm05."""
        self._create_one_user(driver, 4)

    def test_07_create_user150426(self, driver):
        """
        Standalone test — creates user 'User150426' with password 'Ultriva!23'.
        This test logs in by itself so it can be run on its own without
        needing test_01 to run first.

        Mandatory fields filled:
          First Name  → User
          Last Name   → 150426
          Work Phone  → 5556006006
          Email       → vseelam@uplandsoftware.com
          User ID     → User150426
          Password    → Ultriva!23
          Confirm Pwd → Ultriva!23
          Account Type→ Plant Administrators
        """
        import random

        # ── Step 1: Log in (needed when running this test in isolation) ────
        # Only log in if we are not already on an authenticated page
        driver.get(BASE_URL)
        page_ready(driver)

        # Check if the login form is visible — if yes, we need to log in
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        try:
            WebDriverWait(driver, 5).until(
                EC.visibility_of_element_located((By.ID, "UserName"))
            )
            # Login form is visible — fill in credentials and submit
            print("\n[test_07] Login form detected — logging in now")
            driver.find_element(By.ID, "UserName").send_keys(ADMIN_USER)
            driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
            driver.find_element(By.ID, "login-button").click()
            page_ready(driver)
            time.sleep(PAUSE)
            print(f"[test_07] Logged in — URL: {driver.current_url}")
        except Exception:
            # Login form not visible — already logged in, continue
            print("[test_07] Already logged in, skipping login step")

        # ── Step 2: Navigate to the Create User form ───────────────────────
        driver.get(f"{BASE_URL}/User/Create")
        page_ready(driver)
        time.sleep(PAUSE)   # pause — let the form fully render
        print(f"[test_07] Create page URL: {driver.current_url}")

        # ── Step 3: Fill all mandatory fields ─────────────────────────────
        # Generate a random 4-digit suffix to make phone numbers unique
        rand_suffix = random.randint(1000, 9999)

        # Field data for User150426
        # Mandatory fields are marked with (required)
        FIELDS = [
            # (field_name_on_form,   value_to_type,             required?)
            ("PRS$FirstName", "User", True),
            ("PRS$LastName", "150426", True),
            ("PRS$WorkPhone", f"555600{rand_suffix}", True),
            ("PRS$MobilePhone", f"555600{rand_suffix}", False),
            ("PRS$EmailID", "vseelam@uplandsoftware.com", True),
            ("USR$LoginName", "User150426", True),
            ("USR$BuyerCode", "BC006", False),
        ]

        # Try alternate field name patterns in case the form uses different
        # names
        ALT_NAMES = {
            "PRS$FirstName": ["FirstName", "User_FirstName", "txtFirstName"],
            "PRS$LastName": ["LastName", "User_LastName", "txtLastName"],
            "PRS$WorkPhone": ["WorkPhone", "User_WorkPhone", "txtWorkPhone"],
            "PRS$MobilePhone": ["MobilePhone", "User_MobilePhone"],
            "PRS$EmailID": ["EmailID", "Email", "User_Email", "txtEmail"],
            "USR$LoginName": ["LoginName", "UsrId", "UserId", "User_ID"],
            "USR$BuyerCode": ["BuyerCode", "User_BuyerCode"],
        }

        def _try_type(field_name, value):
            """Try typing `value` into the field by its primary name,
            then by alternate names, then by ID."""
            # Primary name
            try:
                clear_and_type(driver, By.NAME, field_name, value, timeout=6)
                print(f"  [FILLED] {field_name} = {value!r}")
                return True
            except Exception:
                pass
            # Alternate names
            for alt in ALT_NAMES.get(field_name, []):
                try:
                    clear_and_type(driver, By.NAME, alt, value, timeout=4)
                    print(
                        f"  [FILLED-ALT] {field_name} via {alt!r} = {value!r}")
                    return True
                except Exception:
                    pass
            # Try by ID
            try:
                clear_and_type(driver, By.ID, field_name, value, timeout=4)
                print(f"  [FILLED-ID] {field_name} = {value!r}")
                return True
            except Exception:
                pass
            return False

        # Fill each field
        for field_name, value, required in FIELDS:
            ok = _try_type(field_name, value)
            if not ok:
                if required:
                    print(
                        f"  [WARN] Could not fill required field '{field_name}'")
                else:
                    print(
                        f"  [INFO] Optional field '{field_name}' not found, skipping")

        # ── Step 4: Select Account Type dropdown ───────────────────────────
        # The dropdown holds the role/permission level for the new user
        acct_selected = select_dropdown_option(driver, ACCOUNT_TYPE)
        if acct_selected:
            print(f"  [FILLED] Account Type = {ACCOUNT_TYPE!r}")
        else:
            print(f"  [WARN] Could not set Account Type — dropdown not found")

        # ── Step 5: Enter password and confirm password ────────────────────
        # Password for User150426 is the given valid password: Ultriva!23
        PASSWORD_VALUE = "Ultriva!23"

        for pwd_field in ["MISC$Password", "Password", "Pwd"]:
            try:
                clear_and_type(
                    driver,
                    By.NAME,
                    pwd_field,
                    PASSWORD_VALUE,
                    timeout=5)
                print(f"  [FILLED] {pwd_field} = {PASSWORD_VALUE!r}")
                break
            except Exception:
                continue

        for cpwd_field in [
            "MISC$ConfirmPassword",
            "ConfirmPassword",
            "ConfirmedPassword",
                "ConfirmPwd"]:
            try:
                clear_and_type(
                    driver,
                    By.NAME,
                    cpwd_field,
                    PASSWORD_VALUE,
                    timeout=5)
                print(f"  [FILLED] {cpwd_field} = {PASSWORD_VALUE!r}")
                break
            except Exception:
                continue

        time.sleep(1)   # small pause before clicking Save

        # ── Step 6: Click Save ─────────────────────────────────────────────
        # Try several known Save button patterns used by Ultriva forms
        save_selectors = [
            (By.XPATH, "//a[@title='Save' and contains(@onclick,'frmEntryPage_onSubmit')]"),
            (By.XPATH, "//a[contains(@onclick,'frmEntryPage_onSubmit')]"),
            (By.XPATH, "//a[@title='Save']"),
            (By.ID, "entryPGSubmit"),
            (By.XPATH, "//input[@value='Save'] | //button[normalize-space(text())='Save']"),
            (By.CSS_SELECTOR, "[value='Save'], [title='Save']"),
        ]
        saved = False
        for by, sel in save_selectors:
            try:
                btn = WebDriverWait(
                    driver, 6).until(
                    EC.element_to_be_clickable(
                        (by, sel)))
                btn.click()
                saved = True
                print(f"  [SAVE] Clicked Save button")
                break
            except Exception:
                continue

        if not saved:
            # Record failure and mark as xfail so test suite continues
            created_users.append({
                "user_id": "User150426",
                "password": PASSWORD_VALUE,
                "status": "Failed",
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            pytest.xfail(
                "Save button not found — check if the Create page loaded correctly")

        # Wait for page to finish loading after Save
        page_ready(driver)
        time.sleep(PAUSE)

        # ── Step 7: Check for error messages after Save ────────────────────
        error_elements = driver.find_elements(
            By.XPATH,
            "//*[contains(@class,'error') or contains(@class,'alert-danger') "
            "or contains(@class,'validation')]"
        )
        visible_errors = [
            e.text.strip() for e in error_elements
            if e.is_displayed() and e.text.strip() and len(e.text.strip()) > 3
        ]

        status = "Failed" if visible_errors else "Created"

        # Store the result for the Excel export in test_08
        created_users.append({
            "user_id": "User150426",
            "password": PASSWORD_VALUE,
            "status": status,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })

        if visible_errors:
            print(f"  [FORM ERRORS] {visible_errors}")
            pytest.xfail(
                f"User 'User150426' creation failed — form errors: {visible_errors}")

        print(f"\n  User 'User150426' created successfully  (status={status})")

    # ------------------------------------------------------------------
    # Step 8 — Export credentials to Excel
    # ------------------------------------------------------------------
    def test_08_export_credentials_to_excel(self, driver):
        """
        Save all user IDs and passwords that were collected during
        tests 02–07 into a formatted Excel file.
        """

        # Make sure there is at least one record to export
        assert created_users, "No user records to export — all creation tests skipped?"

        # Call the export helper and confirm the file was created
        path = export_credentials_to_excel(created_users, CREDS_REPORT)
        assert os.path.exists(path), f"Excel file was not created at {path}"

        print(f"\n[EXPORT] {len(created_users)} user(s) written to:\n  {path}")


# ══════════════════════════════════════════════════════════════════════════════
# TEST CLASS 4 — View User150426 and click Cancel
# ══════════════════════════════════════════════════════════════════════════════

VIEW_USER_ID = "User150426"   # user we want to view


class TestViewUser:
    """
    Verify the View User page for User150426 by:
      test_01 — Log in
      test_02 — Open User List and search for User150426
      test_03 — Select the row and click the View toolbar button
      test_04 — Confirm the View User page loaded, then click Cancel

    Run from qa_automation/ folder:
        pytest tests/QALS11/Admin/Users/users.py::TestViewUser -v -s
    """

    # ── Step 1: Login ───────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """Log in with admin credentials."""

        driver.get(BASE_URL)
        page_ready(driver)

        # Enter credentials and submit
        wait_for_clickable(driver, By.ID, "UserName").send_keys(ADMIN_USER)
        driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
        driver.find_element(By.ID, "login-button").click()
        page_ready(driver)
        time.sleep(PAUSE)

        assert "ultrivalms" in driver.current_url, "Login failed"
        print(f"\n  Logged in — URL: {driver.current_url}")

    # ── Step 2: Open User List and search for User150426 ────────────────────
    def test_02_search_user(self, driver):
        """Navigate to User List and search for User150426."""

        # Go directly to the User List page
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)

        # Try to find the search/filter text box using common Ultriva field
        # names
        search_box = None
        for by, sel in [
            (By.NAME, "User_FindTextbox"),
            (By.XPATH, "//input[@type='text' and contains(@class,'search')]"),
            (By.XPATH, "//input[@placeholder]"),
            (By.XPATH, "(//input[@type='text'])[1]"),
        ]:
            try:
                search_box = WebDriverWait(driver, 5).until(
                    EC.visibility_of_element_located((by, sel))
                )
                break
            except Exception:
                continue

        assert search_box is not None, "Search box not found on User List"

        # Type the User ID to filter the grid
        search_box.clear()
        search_box.send_keys(VIEW_USER_ID)
        time.sleep(PAUSE)

        # Click Go button if present (some Ultriva versions require this)
        try:
            go = WebDriverWait(
                driver,
                4).until(
                EC.element_to_be_clickable(
                    (By.XPATH,
                     "//button[contains(normalize-space(.),'Go')] | //input[@value='Go']")))
            go.click()
            time.sleep(PAUSE)
        except Exception:
            pass  # live filtering — no Go button needed

        # Confirm the user row appears in the grid
        WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{VIEW_USER_ID}']"
            ))
        )
        print(f"\n  Found '{VIEW_USER_ID}' in User List")

    # ── Step 3: Select the row and click the View toolbar button ────────────
    def test_03_select_and_click_view(self, driver):
        """
        Click the User150426 row to select it, then click the View button
        in the toolbar above the grid.
        """

        # Find the User ID cell and JS-click it to select the row in Ultriva's
        # grid
        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{VIEW_USER_ID}']"
            ))
        )
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script(
            "arguments[0].click();",
            user_cell)  # row selected
        time.sleep(PAUSE)
        print(f"\n  Selected row for '{VIEW_USER_ID}'")

        # Click the View button in the toolbar (title="View" is the reliable
        # selector)
        view_btn = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH,
                "//a[@title='View'] | //button[@title='View'] "
                "| //a[normalize-space(.)='View'] | //button[normalize-space(.)='View']"
            ))
        )
        driver.execute_script("arguments[0].click();", view_btn)
        page_ready(driver)
        time.sleep(PAUSE)   # watch the View User page load

        # Confirm we are on the View User page (URL contains /User/ViewBO)
        assert "ViewBO" in driver.current_url or VIEW_USER_ID in driver.page_source, (
            f"Did not reach View User page. URL: {driver.current_url}")
        print(f"  View User page loaded — URL: {driver.current_url}")

    # ── Step 4: Verify View page contents and click Cancel ──────────────────
    def test_04_verify_and_cancel(self, driver):
        """
        Confirm the View User User150426 page shows the correct details,
        then click the Cancel button to return to the User List.
        """

        # The View User page heading may be h1, h2, or a div — try all
        heading_text = ""
        for by, sel in [
            (By.TAG_NAME, "h1"),
            (By.TAG_NAME, "h2"),
            (By.XPATH, "//*[contains(@class,'page-title') or contains(@class,'pagetitle')]"),
            (By.XPATH, "//*[contains(normalize-space(text()),'View User')]"),
        ]:
            try:
                el = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, sel))
                )
                heading_text = el.text.strip()
                if heading_text:
                    break
            except Exception:
                continue

        print(f"\n  Page heading: '{heading_text}'")
        assert VIEW_USER_ID in heading_text or VIEW_USER_ID in driver.page_source, (
            f"'{VIEW_USER_ID}' not found on View User page")

        # Print the Application Access section so QA can review it in the
        # console
        try:
            access_rows = driver.find_elements(
                By.XPATH, "//table[contains(@class,'Grid')]//tr[td]"
            )
            print(f"  Application Access rows ({len(access_rows)}):")
            for row in access_rows[:10]:
                print(f"    {row.text.strip()[:120]}")
        except Exception:
            pass

        # Click the Cancel button to return to the User List
        # Scroll to the bottom first (Cancel is at the very bottom of the page)
        driver.execute_script(
            "window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)

        # Try multiple selectors — Ultriva uses entryPGCancel id or a link to
        # User/List
        cancel_found = False
        for by, sel in [
            (By.ID, "entryPGCancel"),
            (By.XPATH, "//a[@id='entryPGCancel']"),
            (By.XPATH, "//a[contains(@href,'User/List')]"),
            (By.XPATH, "//a[contains(normalize-space(.),'Cancel')]"),
            (By.XPATH, "//button[contains(normalize-space(.),'Cancel')]"),
            (By.XPATH, "//input[@value='Cancel']"),
        ]:
            try:
                btn = WebDriverWait(
                    driver, 5).until(
                    EC.element_to_be_clickable(
                        (by, sel)))
                print(f"  Cancel button found via: {sel}")
                driver.execute_script("arguments[0].click();", btn)
                cancel_found = True
                break
            except Exception:
                continue

        if not cancel_found:
            # Last resort: navigate directly back to User List
            print(
                "  [WARN] Cancel button not found by any selector — navigating back directly")
            driver.get(f"{BASE_URL}/User/List")

        page_ready(driver)
        time.sleep(PAUSE)   # watch the browser return to User List

        # Confirm we are back on the User List
        assert "User/List" in driver.current_url or "ultrivalms" in driver.current_url, (
            f"Cancel did not return to User List. URL: {driver.current_url}")
        print(f"  Clicked Cancel — returned to: {driver.current_url}")


# ══════════════════════════════════════════════════════════════════════════════
# TEST CLASS 5 — Disable User150426
# ══════════════════════════════════════════════════════════════════════════════
#
# PROCESS OVERVIEW — Disabling a User
# ─────────────────────────────────────────────────────────────────────────────
# When you need to temporarily block a user from logging in without deleting
# their account, you use the Disable feature.
#
# HOW TO DISABLE A USER IN THE APPLICATION:
#   1. Log in with an admin account (buyeruser / Ultriva!23)
#   2. Navigate to: Admin > User List  (URL: /User/List)
#   3. Find the user row — use the search box (Name="User_FindTextbox")
#      and type the User ID (e.g. "User150426"), then wait for the row
#   4. Click the user's row to SELECT it (the row highlights in blue)
#      — in Ultriva you must click the <td> cell, not the <tr> row directly
#   5. Click the  DISABLE  toolbar button (id="User_tbrDelete")
#      — despite the name "tbrDelete", this button DISABLES, does not delete
#   6. A confirmation dialog appears:
#        "Do you want to disable this user?"
#      Click  YES  to confirm
#   7. The page refreshes — the user row now shows a RED icon (Disabled status)
#   8. The user can no longer log in until re-enabled
#
# WHAT THESE TESTS VERIFY:
#   test_01 — Login succeeds
#   test_02 — User List page loads (URL: /User/List)
#   test_03 — Search for User150426 → row appears in the grid
#   test_04 — Click the row → row is selected (highlighted)
#   test_05 — Click Disable toolbar button → confirmation dialog appears
#   test_06 — Click Yes in dialog → page updates
#   test_07 — User row now shows Disabled (red icon or "Disabled" text)
#
# IMPORTANT NOTES FOR QA:
#   • The Disable button shares the id="User_tbrDelete" — this is intentional
#     in Ultriva (disable is treated as a 'soft delete')
#   • The Yes button in the modal is a <span> element, not a standard <button>
#   • After disabling, the user row remains in the ACTIVE list briefly, then
#     moves to the Disabled list (see show Disabled And Locked option)
# ══════════════════════════════════════════════════════════════════════════════

DISABLE_USER_ID = "User150426"   # the user account to disable


class TestDisableUser:
    """
    Disable the user 'User150426' from the Admin > User List.

    Steps:
      test_01 — Log in
      test_02 — Open User List
      test_03 — Search for User150426
      test_04 — Select the row
      test_05 — Click the Disable toolbar button
      test_06 — Confirm Yes in the dialog
      test_07 — Verify the user shows Disabled status

    Run from qa_automation/ folder:
        pytest tests/QALS11/Admin/Users/users.py::TestDisableUser -v -s
    """

    # ── Step 1: Login ───────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """Log in to the QA site with admin credentials."""

        # Open the application home page
        driver.get(BASE_URL)
        page_ready(driver)

        # Fill in the login form and submit
        WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((By.ID, "UserName"))
        ).send_keys(ADMIN_USER)
        driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
        driver.find_element(By.ID, "login-button").click()
        page_ready(driver)
        time.sleep(PAUSE)

        assert "ultrivalms" in driver.current_url, "Login failed — check credentials"
        print(f"\n  Logged in — URL: {driver.current_url}")

    # ── Step 2: Open the User List page ─────────────────────────────────────
    def test_02_open_user_list(self, driver):
        """Navigate directly to Admin > User List."""

        # Direct URL navigation is faster and more reliable than clicking menus
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)   # watch the list load

        # Dismiss any modal dialog that auto-appears on page load
        dismiss_modal_if_open(driver)

        assert "ultrivalms" in driver.current_url, "Did not reach User List"
        print(f"\n  User List loaded — URL: {driver.current_url}")

    # ── Step 3: Search for User150426 ───────────────────────────────────────
    def test_03_search_user(self, driver):
        """Type 'User150426' in the search box and confirm the row appears."""

        # Dismiss any blocking modal before interacting with the search box
        dismiss_modal_if_open(driver)

        # Try common Ultriva search box selectors in order of reliability
        search_box = None
        for by, sel in [
            (By.NAME, "User_FindTextbox"),
            (By.XPATH, "//input[@type='text' and contains(@class,'search')]"),
            (By.XPATH, "//input[@placeholder]"),
            (By.XPATH, "(//input[@type='text'])[1]"),
        ]:
            try:
                search_box = WebDriverWait(driver, 5).until(
                    EC.visibility_of_element_located((by, sel))
                )
                break
            except Exception:
                continue

        assert search_box is not None, "Search box not found on User List"

        # Type the User ID and trigger the list to filter
        search_box.clear()
        search_box.send_keys(DISABLE_USER_ID)
        time.sleep(PAUSE)

        # Click Go button if present (some Ultriva versions require an explicit
        # submit)
        try:
            go = WebDriverWait(
                driver,
                4).until(
                EC.element_to_be_clickable(
                    (By.XPATH,
                     "//button[contains(normalize-space(.),'Go')] | //input[@value='Go']")))
            go.click()
            time.sleep(PAUSE)
        except Exception:
            pass  # live filtering — no Go button needed

        print(f"\n  Searched for '{DISABLE_USER_ID}' — waiting for row")

        # Confirm the user row appears in the grid
        WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{DISABLE_USER_ID}']"
            ))
        )
        print(f"  Found '{DISABLE_USER_ID}' in the list")

    # ── Step 4: Select the User150426 row ───────────────────────────────────
    def test_04_select_user_row(self, driver):
        """
        Click the User ID cell in the row to select it in Ultriva's grid.
        You must click the <td> cell — clicking <tr> directly does not
        trigger Ultriva's row-selection event handler.
        """

        # Dismiss any modal that may be blocking the grid
        dismiss_modal_if_open(driver)
        time.sleep(1)

        # Locate the cell that holds the User ID text
        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{DISABLE_USER_ID}']"
            ))
        )

        # Log the row HTML so QA can see the current status indicator
        try:
            row = user_cell.find_element(By.XPATH, "..")   # parent <tr>
            row_html = row.get_attribute("outerHTML")
            print(f"\n  Row HTML (first 400): {row_html[:400]}")
            first_td = row.find_element(By.XPATH, "./td[1]")
            print(f"  Status TD: {first_td.get_attribute('innerHTML')[:200]}")
        except Exception as e:
            print(f"\n  [WARN] Could not read row HTML: {e}")

        # Scroll into view then JS-click to trigger Ultriva's selection event
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)   # watch the row highlight in blue

        print(f"\n  Selected row for '{DISABLE_USER_ID}'")

    # ── Step 5: Click the Disable toolbar button ────────────────────────────
    def test_05_click_disable_button(self, driver):
        """
        Click the Disable toolbar button (id='User_tbrDelete').
        Note: despite the name 'tbrDelete', this button disables the user —
        it does NOT permanently delete the account.
        A confirmation dialog should appear after clicking.
        """

        # The exact button ID found via browser inspection
        disable_btn = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((By.ID, "User_tbrDelete"))
        )
        print(
            f"\n  Disable button — title='{
                disable_btn.get_attribute('title')}' " f"class='{
                disable_btn.get_attribute('class')}'")

        # JS-click to bypass any CSS overlay that might block a normal click
        driver.execute_script("arguments[0].click();", disable_btn)
        time.sleep(PAUSE)   # watch for the confirmation dialog

        print("  Clicked Disable button — waiting for confirmation modal")

        # Wait for Ultriva's standard alert/confirm modal to appear
        modal = WebDriverWait(driver, WAIT).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id"))
        )
        modal_text = modal.text.strip()
        modal_html = modal.get_attribute("innerHTML")
        print(f"  Modal text: '{modal_text[:300]}'")
        print(f"  Modal HTML snippet: {modal_html[:600]}")

        # Verify the dialog asks about disabling (not an error or wrong action)
        assert "disable" in modal_text.lower(), (
            f"Expected disable confirmation dialog, got: '{modal_text[:100]}'"
        )
        print("  Disable confirmation dialog appeared correctly")

    # ── Step 6: Confirm Yes in the dialog ───────────────────────────────────
    def test_06_confirm_disable(self, driver):
        """
        Click 'Yes' inside the Ultriva confirmation modal to disable the user.
        Ultriva renders the Yes button as a <span> inside the modal footer,
        so we use a broad XPath that covers all possible element types.
        """

        # Broad selector covering all button-like elements with text "Yes"
        yes_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[normalize-space(text())='Yes'] "
                "| //button[normalize-space(.)='Yes'] "
                "| //a[normalize-space(text())='Yes'] "
                "| //input[@value='Yes'] "
                "| //*[@id='Modal-modal-alert-id']//*[contains(normalize-space(text()),'Yes')]"
            ))
        )
        print(
            f"\n  Yes button — tag='{
                yes_btn.tag_name}' text='{
                yes_btn.text.strip()}'")

        # JS-click the Yes button to submit the disable request
        driver.execute_script("arguments[0].click();", yes_btn)
        page_ready(driver)
        time.sleep(PAUSE)   # watch the page refresh after disabling

        print("  Clicked 'Yes' — disable request submitted")

    # ── Step 7: Verify the user now shows Disabled status ───────────────────
    def test_07_verify_user_disabled(self, driver):
        """
        Confirm the User150426 row shows Disabled status in the list.
        Ultriva displays a red icon (disable.gif) or the word 'Disabled'
        in the status column when a user is disabled.
        """

        try:
            row = WebDriverWait(driver, WAIT).until(
                EC.presence_of_element_located((
                    By.XPATH,
                    f"//tr[td[normalize-space(text())='{DISABLE_USER_ID}']]"
                ))
            )
            row_text = row.text
            row_html = row.get_attribute("outerHTML")
            print(f"\n  Row content after disable: {row_text[:200]}")

            # Check for Ultriva's disabled indicators in the row HTML
            is_disabled = (
                "disabled" in row_html.lower()
                or "red" in row_html.lower()
                or "Disabled" in row_text
            )
            if is_disabled:
                print(
                    f"  VERIFIED: '{DISABLE_USER_ID}' status = DISABLED (red icon)")
            else:
                print(
                    "  NOTE: Disable action completed — verify icon manually in browser")

        except Exception as e:
            print(
                f"  NOTE: Could not re-read row — action likely succeeded ({e})")

        # Confirm we are still on the correct site
        assert "ultrivalms" in driver.current_url, "Browser left the site"
        print(f"  Final URL: {driver.current_url}")


# ══════════════════════════════════════════════════════════════════════════════
# TEST CLASS 6 — Enable User150426
# ══════════════════════════════════════════════════════════════════════════════
#
# PROCESS OVERVIEW — Re-enabling a Disabled User
# ─────────────────────────────────────────────────────────────────────────────
# After a user has been disabled, you can restore their access using the
# Enable feature. This moves the account back to Active status.
#
# HOW TO ENABLE A USER IN THE APPLICATION:
#   1. Log in with an admin account (buyeruser / Ultriva!23)
#   2. Navigate to: Admin > User List  (URL: /User/List)
#   3. Click  MORE OPTIONS  in the toolbar  →  select  SHOW DISABLED AND LOCKED
#      — this switches the grid to show only disabled/locked accounts
#   4. Find the user row — search for "User150426" in the search box
#   5. Click the user's row to SELECT it (the row highlights)
#   6. Click the  ENABLE  toolbar button (title="Enable")
#      — this opens the enable confirmation dialog
#   7. A confirmation dialog appears:
#        "Do you want to enable this user?"
#      Click  YES  to confirm
#   8. The page switches back to the Active user list
#      The user can log in again immediately
#
# WHAT THESE TESTS VERIFY:
#   test_01 — Login succeeds
#   test_02 — More Options → Show Disabled And Locked → Disabled list loads
#   test_03 — Search for User150426 → row appears in the Disabled list
#   test_04 — Click the row → row is selected
#   test_05 — Click Enable toolbar button → confirmation dialog appears
#   test_06 — Click Yes in dialog → page updates
#   test_07 — Navigate to Active list → User150426 row shows Active (green icon)
#
# IMPORTANT NOTES FOR QA:
#   • You MUST be on the Disabled list (ds=1 in URL) to see the Enable button
#   • The Enable button has title="Enable" on the toolbar
#   • After enabling, the user immediately appears in the Active list
#   • Green icon (enable1.gif) in the status column = Active user
#   • Red icon (disable.gif) in the status column = Disabled user
# ══════════════════════════════════════════════════════════════════════════════

ENABLE_USER_ID = "User150426"   # the user account to re-enable


class TestEnableUser:
    """
    Re-enable the user 'User150426' from the Disabled User List.

    Steps:
      test_01 — Log in
      test_02 — User List → More Options → Show Disabled And Locked
      test_03 — Search for User150426 in the Disabled list
      test_04 — Select the row
      test_05 — Click the Enable toolbar button
      test_06 — Confirm Yes in the dialog
      test_07 — Verify user is back on the Active list

    Run from qa_automation/ folder:
        pytest tests/QALS11/Admin/Users/users.py::TestEnableUser -v -s
    """

    # ── Step 1: Login ───────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """Log in to the QA site with admin credentials."""

        # Open the application home page
        driver.get(BASE_URL)
        page_ready(driver)

        # Fill in the login form and submit
        WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((By.ID, "UserName"))
        ).send_keys(ADMIN_USER)
        driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
        driver.find_element(By.ID, "login-button").click()
        page_ready(driver)
        time.sleep(PAUSE)

        assert "ultrivalms" in driver.current_url, "Login failed"
        print(f"\n  Logged in — URL: {driver.current_url}")

    # ── Step 2: User List → More Options → Show Disabled And Locked ─────────
    def test_02_open_disabled_list(self, driver):
        """
        Navigate to User List, click 'More Options' in the toolbar,
        then select 'Show Disabled And Locked' to switch to the disabled view.

        WHY THIS STEP IS NEEDED:
          The standard User List only shows ACTIVE users.
          To find a disabled user you must switch to the Disabled list via
          More Options → Show Disabled And Locked.
        """

        # Navigate to the active User List first
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # Click the More Options dropdown button in the toolbar
        more_options_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(normalize-space(.),'More Options')] "
                "| //a[contains(normalize-space(.),'More Options')]"
            ))
        )
        driver.execute_script("arguments[0].click();", more_options_btn)
        time.sleep(1)   # wait for the dropdown to open
        print("\n  Clicked 'More Options' dropdown")

        # Select 'Show Disabled And Locked' from the dropdown menu
        show_disabled = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Show Disabled And Locked'] "
                "| //li[normalize-space(.)='Show Disabled And Locked']"
            ))
        )
        driver.execute_script("arguments[0].click();", show_disabled)
        page_ready(driver)
        time.sleep(PAUSE)   # watch the disabled list load

        # Confirm we are now viewing the Disabled User List
        assert (
            "ds=1" in driver.current_url
            or "Disabled" in driver.title
            or "Disabled" in driver.find_element(By.TAG_NAME, "h1").text
        ), "Did not reach the Disabled User List"
        print(f"  Disabled User List loaded — URL: {driver.current_url}")

    # ── Step 3: Search for User150426 in the Disabled list ──────────────────
    def test_03_search_user(self, driver):
        """Type 'User150426' in the search box and confirm the row appears."""

        dismiss_modal_if_open(driver)

        # Try common search box selectors
        search_box = None
        for by, sel in [
            (By.NAME, "User_FindTextbox"),
            (By.XPATH, "//input[@type='text' and contains(@class,'search')]"),
            (By.XPATH, "//input[@placeholder]"),
            (By.XPATH, "(//input[@type='text'])[1]"),
        ]:
            try:
                search_box = WebDriverWait(driver, 5).until(
                    EC.visibility_of_element_located((by, sel))
                )
                break
            except Exception:
                continue

        assert search_box is not None, "Search box not found on Disabled User List"

        # Type the User ID and wait for the list to filter
        search_box.clear()
        search_box.send_keys(ENABLE_USER_ID)
        time.sleep(PAUSE)

        # Click Go if present
        try:
            go = WebDriverWait(
                driver,
                4).until(
                EC.element_to_be_clickable(
                    (By.XPATH,
                     "//button[contains(normalize-space(.),'Go')] | //input[@value='Go']")))
            go.click()
            time.sleep(PAUSE)
        except Exception:
            pass  # live filtering — no Go button needed

        print(f"\n  Searched for '{ENABLE_USER_ID}' in Disabled list")

        # Confirm the row appears (user is currently disabled)
        WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{ENABLE_USER_ID}']"
            ))
        )
        print(f"  Found '{ENABLE_USER_ID}' in the Disabled list")

    # ── Step 4: Select the User150426 row ───────────────────────────────────
    def test_04_select_user_row(self, driver):
        """Click the User ID cell to select the row in Ultriva's grid."""

        dismiss_modal_if_open(driver)
        time.sleep(1)

        # Locate the cell and log the current row status
        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{ENABLE_USER_ID}']"
            ))
        )

        try:
            row = user_cell.find_element(By.XPATH, "..")   # parent <tr>
            status_td = row.find_element(By.XPATH, "./td[1]")
            print(
                f"\n  Status icon HTML: {
                    status_td.get_attribute('innerHTML')[
                        :150]}")
        except Exception:
            pass

        # Scroll into view and JS-click the cell to trigger row selection
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)   # watch the row highlight

        print(f"  Selected row for '{ENABLE_USER_ID}'")

    # ── Step 5: Click the Enable toolbar button ─────────────────────────────
    def test_05_click_enable_button(self, driver):
        """
        Click the Enable toolbar button.
        The Enable button is only visible on the Disabled user list (step 2
        must have been completed first). After clicking, a confirmation dialog
        asking "Do you want to enable this user?" should appear.
        """

        # Locate the Enable button — try by title first, then by text or ID
        enable_btn = None
        for by, sel in [
            (By.XPATH, "//a[@title='Enable'] | //button[@title='Enable']"),
            (By.XPATH, "//a[normalize-space(.)='Enable'] | //button[normalize-space(.)='Enable']"),
            (By.ID, "User_tbrEnable"),
        ]:
            try:
                enable_btn = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, sel))
                )
                print(f"\n  Found Enable button via: {sel}")
                break
            except Exception:
                continue

        assert enable_btn is not None, "Enable button not found — are you on the Disabled list?"

        # JS-click to avoid overlay issues
        driver.execute_script("arguments[0].click();", enable_btn)
        time.sleep(PAUSE)   # watch the confirmation dialog appear

        print("  Clicked Enable button — waiting for confirmation dialog")

        # Wait for Ultriva's modal to become visible
        modal = WebDriverWait(driver, WAIT).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id"))
        )
        modal_text = modal.text.strip()
        print(f"  Modal text: '{modal_text}'")

        # Verify the dialog is the enable confirmation (not an error)
        assert "enable" in modal_text.lower(), (
            f"Expected enable confirmation dialog, got: '{modal_text[:100]}'"
        )
        print("  Enable confirmation dialog appeared correctly")

    # ── Step 6: Confirm Yes in the dialog ───────────────────────────────────
    def test_06_confirm_enable(self, driver):
        """
        Click 'Yes' in the enable confirmation dialog.
        Ultriva renders the Yes button as a <span> inside the modal footer,
        so we use a broad XPath that covers all possible element types.
        """

        yes_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[normalize-space(text())='Yes'] "
                "| //button[normalize-space(.)='Yes'] "
                "| //a[normalize-space(text())='Yes'] "
                "| //input[@value='Yes'] "
                "| //*[@id='Modal-modal-alert-id']//*[contains(normalize-space(text()),'Yes')]"
            ))
        )
        print(
            f"\n  Yes button — tag='{
                yes_btn.tag_name}' text='{
                yes_btn.text.strip()}'")

        # JS-click to submit the enable request
        driver.execute_script("arguments[0].click();", yes_btn)
        page_ready(driver)
        time.sleep(PAUSE)   # watch the page update after enabling

        print("  Clicked 'Yes' — enable request submitted")

    # ── Step 7: Verify user is back on the Active list ──────────────────────
    def test_07_verify_user_enabled(self, driver):
        """
        Navigate back to the Active User List and confirm User150426 appears
        with an Active status (green tick icon or 'Active' text in the row).
        After this test passes, the user can log in again.
        """

        # Go back to the standard (active) User List
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # Search for the user in the active list to confirm re-enabling worked
        try:
            search_box = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            search_box.clear()
            search_box.send_keys(ENABLE_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass  # proceed to row check if search box not available

        # Confirm the user row appears in the ACTIVE list
        row = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//tr[td[normalize-space(text())='{ENABLE_USER_ID}']]"
            ))
        )
        row_html = row.get_attribute("outerHTML")
        print(f"\n  Row HTML after enable: {row_html[:400]}")

        # Ultriva shows a green tick icon (enable1.gif / title="Active") for
        # active users
        is_active = (
            "enable1.gif" in row_html
            or "Active" in row_html
        )
        if is_active:
            print(
                f"  VERIFIED: '{ENABLE_USER_ID}' status = ACTIVE (green tick)")
        else:
            print("  NOTE: Row found in Active list — verify icon manually in browser")

        assert "ultrivalms" in driver.current_url, "Browser left the site"
        print(f"  Final URL: {driver.current_url}")


# ══════════════════════════════════════════════════════════════════════════════
# TEST CLASS 7 — Full User Lifecycle for User150426_1
# ══════════════════════════════════════════════════════════════════════════════
#
# WHAT THIS CLASS TESTS (end-to-end workflow for a single user):
#   Step 1  — Login (ONCE — browser stays open for ALL subsequent tests)
#   Step 2  — CREATE  User150426_1  (random mandatory fields, password Ultriva!23)
#   Step 3  — EDIT    User150426_1  (random new values) → save → User List
#   Step 4  — VIEW    User150426_1  → click Cancel → User List
#   Step 5  — DISABLE User150426_1  → User List
#   Step 6  — More Options → Show Disabled And Locked → ENABLE → Active User List
#
# KEY DESIGN DECISIONS:
#   • Only ONE login at the very start — no re-login between any steps.
#   • After EVERY operation the browser navigates back to /User/List.
#   • Random phone / buyer-code prevents duplicate-value errors on re-runs.
#   • Each test is self-contained and readable by a QA engineer.
#
# Run from qa_automation/ folder:
#   pytest tests/QALS11/Admin/Users/users.py::TestUser150426_1 -v -s
# ══════════════════════════════════════════════════════════════════════════════

NEW_USER_ID = "User150426_1"     # user created and exercised by this class
NEW_USER_PW = "Ultriva!23"       # fixed password for the new user


class TestUser150426_1:
    """
    End-to-end lifecycle test for user 'User150426_1':
      test_01 — Login once; browser stays open throughout
      test_02 — Create the user with random mandatory field values
      test_03 — Edit the user with new random values → User List
      test_04 — View the user → click Cancel → User List
      test_05 — Disable the user → User List
      test_06 — Show Disabled list → Enable the user → Active User List
    """

    # ── Step 1: Login ───────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """
        Log in to the QA site ONCE.
        All following tests reuse this session — no further login or logout needed.

        QA PROCESS:
          1. Open the application URL.
          2. Enter admin username and password.
          3. Click the Login button.
          4. Confirm the dashboard loads (URL contains 'ultrivalms').
        """

        driver.get(BASE_URL)
        page_ready(driver)

        WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((By.ID, "UserName"))
        ).send_keys(ADMIN_USER)
        driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
        driver.find_element(By.ID, "login-button").click()
        page_ready(driver)
        time.sleep(PAUSE)

        assert "ultrivalms" in driver.current_url, "Login failed — check credentials"
        print(f"\n  Logged in — URL: {driver.current_url}")

    # ── Step 2: Create User150426_1 ─────────────────────────────────────────
    def test_02_create_user(self, driver):
        """
        Create a brand-new user 'User150426_1'.

        QA PROCESS:
          1. Navigate to Admin > Users > Create User.
          2. Fill in mandatory fields:
               - First Name  : 'User'
               - Last Name   : '150426_1'
               - Work Phone  : random 10-digit number (avoids duplicate error)
               - Email       : shared QA email constant
               - Login Name  : 'User150426_1'
               - Account Type: Plant Administrators
               - Password / Confirm Password: 'Ultriva!23'
          3. Click Save.
          4. Navigate to User List → search User150426_1 → confirm row exists.

        Browser stays on the User List page after this test.
        """

        import random

        rand_phone = f"555{random.randint(1000000, 9999999)}"

        driver.get(f"{BASE_URL}/User/Create")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)
        print(f"\n  Create User form — URL: {driver.current_url}")

        # Fill mandatory and recommended fields
        clear_and_type(driver, By.NAME, "PRS$FirstName", "User")
        clear_and_type(driver, By.NAME, "PRS$LastName", "150426_1")
        clear_and_type(driver, By.NAME, "PRS$WorkPhone", rand_phone)
        clear_and_type(driver, By.NAME, "PRS$EmailID", SHARED_EMAIL)
        clear_and_type(driver, By.NAME, "USR$LoginName", NEW_USER_ID)

        try:
            clear_and_type(driver, By.NAME, "PRS$MobilePhone",
                           rand_phone, timeout=5)
        except Exception:
            pass

        try:
            import random as _r
            import string as _s
            rand_bc = "".join(_r.choices(_s.ascii_uppercase + _s.digits, k=4))
            clear_and_type(
                driver,
                By.NAME,
                "USR$BuyerCode",
                rand_bc,
                timeout=5)
        except Exception:
            pass

        if select_dropdown_option(driver, ACCOUNT_TYPE):
            print(f"  Account Type = {ACCOUNT_TYPE}")
        else:
            print("  [WARN] Account Type not set")

        for field in ("MISC$Password", "MISC$ConfirmPassword"):
            try:
                clear_and_type(driver, By.NAME, field, NEW_USER_PW, timeout=6)
            except Exception:
                print(f"  [WARN] Could not set {field}")

        time.sleep(1)

        # Click Save
        saved = False
        for by, sel in [
            (By.ID, "entryPGSubmit"),
            (By.XPATH, "//a[@title='Save' and contains(@onclick,'frmEntryPage_onSubmit')]"),
            (By.XPATH, "//a[@title='Save']"),
            (By.XPATH, "//input[@value='Save'] | //button[normalize-space(text())='Save']"),
        ]:
            try:
                btn = WebDriverWait(
                    driver, 5).until(
                    EC.element_to_be_clickable(
                        (by, sel)))
                driver.execute_script("arguments[0].click();", btn)
                saved = True
                break
            except Exception:
                continue

        assert saved, "Save button not found on Create User form"
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Saved — URL: {driver.current_url}")

        # Navigate to User List and confirm the new user row exists
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{NEW_USER_ID}']"
            ))
        )
        print(f"  CREATED: '{NEW_USER_ID}' found in Active User List")
        print(f"  Browser on User List — URL: {driver.current_url}")

    # ── Step 3: Edit User150426_1 ───────────────────────────────────────────
    def test_03_edit_user(self, driver):
        """
        Edit the user 'User150426_1' with new random values.

        QA PROCESS:
          1. Navigate to User List (browser already there from previous test).
          2. Search for 'User150426_1' using the search box.
          3. Click the user row to select it (row highlights).
          4. Click the Edit toolbar button.
          5. On the Edit User page, change:
               - First Name  : 'EditedUser'
               - Work Phone  : new random 10-digit number
               - Buyer Code  : new random 4-char code
               - Password / Confirm Password: new random valid password
          6. Click Save.
          7. Navigate back to User List.

        Random values ensure re-runs don't trigger validation errors.
        Browser stays on the User List page after this test.
        """

        import random
        import string

        rand_phone = f"555{random.randint(1000000, 9999999)}"
        rand_bc = "".join(
            random.choices(
                string.ascii_uppercase +
                string.digits,
                k=4))
        new_password = f"Edit@{random.randint(1000, 9999)}Zx!"

        dismiss_modal_if_open(driver)
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # Search and select the row
        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{NEW_USER_ID}']"
            ))
        )
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"\n  Selected row for '{NEW_USER_ID}'")

        # Click the Edit toolbar button
        edit_btn = None
        for by, sel in [
            (By.XPATH, "//a[@title='Edit'] | //button[@title='Edit']"),
            (By.XPATH, "//a[normalize-space(.)='Edit'] | //button[normalize-space(.)='Edit']"),
            (By.ID, "User_tbrEdit"),
        ]:
            try:
                edit_btn = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, sel))
                )
                break
            except Exception:
                continue

        assert edit_btn is not None, "Edit button not found in toolbar"
        driver.execute_script("arguments[0].click();", edit_btn)
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Edit form — URL: {driver.current_url}")

        # Fill fields with new random values
        clear_and_type(driver, By.NAME, "PRS$FirstName", "EditedUser")
        clear_and_type(driver, By.NAME, "PRS$LastName", "150426_1")
        clear_and_type(driver, By.NAME, "PRS$WorkPhone", rand_phone)
        clear_and_type(driver, By.NAME, "PRS$EmailID", SHARED_EMAIL)

        try:
            clear_and_type(
                driver,
                By.NAME,
                "USR$BuyerCode",
                rand_bc,
                timeout=5)
        except Exception:
            pass

        select_dropdown_option(driver, ACCOUNT_TYPE)

        for field in ("MISC$Password", "MISC$ConfirmPassword"):
            try:
                clear_and_type(driver, By.NAME, field, new_password, timeout=6)
            except Exception:
                pass

        time.sleep(1)

        # Save
        saved = False
        for by, sel in [
            (By.ID, "entryPGSubmit"),
            (By.XPATH, "//a[@title='Save' and contains(@onclick,'frmEntryPage_onSubmit')]"),
            (By.XPATH, "//a[@title='Save']"),
            (By.XPATH, "//input[@value='Save'] | //button[normalize-space(text())='Save']"),
        ]:
            try:
                btn = WebDriverWait(
                    driver, 5).until(
                    EC.element_to_be_clickable(
                        (by, sel)))
                driver.execute_script("arguments[0].click();", btn)
                saved = True
                break
            except Exception:
                continue

        assert saved, "Save button not found on Edit User form"
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Edit saved — URL: {driver.current_url}")

        # Navigate back to User List
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)
        assert "ultrivalms" in driver.current_url
        print(f"  Browser on User List — URL: {driver.current_url}")

    # ── Step 4: View User150426_1 → Cancel → User List ──────────────────────
    def test_04_view_user(self, driver):
        """
        View the user 'User150426_1' and click Cancel.

        QA PROCESS:
          1. Navigate to User List.
          2. Search for 'User150426_1'.
          3. Click the user row to select it.
          4. Click the View toolbar button.
          5. Confirm the View User page shows the correct user ID in the heading.
          6. Click the Cancel button (returns to User List without any changes).

        This test does NOT modify any data — it is a read-only verification.
        Browser stays on the User List page after this test.
        """

        dismiss_modal_if_open(driver)
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # Search and select the row
        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{NEW_USER_ID}']"
            ))
        )
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"\n  Selected row for '{NEW_USER_ID}'")

        # Click the View toolbar button
        view_btn = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH,
                "//a[@title='View'] | //button[@title='View'] "
                "| //a[normalize-space(.)='View'] | //button[normalize-space(.)='View']"
            ))
        )
        driver.execute_script("arguments[0].click();", view_btn)
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  View page — URL: {driver.current_url}")

        # Verify the page contains the user's details
        assert "ViewBO" in driver.current_url or NEW_USER_ID in driver.page_source, (
            f"View page for '{NEW_USER_ID}' did not load as expected")

        heading_text = ""
        for by, sel in [
            (By.TAG_NAME, "h1"),
            (By.TAG_NAME, "h2"),
            (By.XPATH, "//*[contains(@class,'page-title') or contains(@class,'pagetitle')]"),
            (By.XPATH, f"//*[contains(normalize-space(text()),'{NEW_USER_ID}')]"),
        ]:
            try:
                el = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, sel))
                )
                heading_text = el.text.strip()
                if heading_text:
                    break
            except Exception:
                continue

        print(f"  Page heading: '{heading_text}'")
        assert NEW_USER_ID in heading_text or NEW_USER_ID in driver.page_source

        # Scroll to Cancel button and click it
        driver.execute_script(
            "window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)

        cancel_found = False
        for by, sel in [
            (By.ID, "entryPGCancel"),
            (By.XPATH, "//a[@id='entryPGCancel']"),
            (By.XPATH, "//a[contains(@href,'User/List')]"),
            (By.XPATH, "//a[contains(normalize-space(.),'Cancel')]"),
            (By.XPATH, "//button[contains(normalize-space(.),'Cancel')]"),
            (By.XPATH, "//input[@value='Cancel']"),
        ]:
            try:
                btn = WebDriverWait(
                    driver, 5).until(
                    EC.element_to_be_clickable(
                        (by, sel)))
                print(f"  Cancel found via: {sel}")
                driver.execute_script("arguments[0].click();", btn)
                cancel_found = True
                break
            except Exception:
                continue

        if not cancel_found:
            print("  [WARN] Cancel not found — navigating directly to User List")
            driver.get(f"{BASE_URL}/User/List")

        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        assert "ultrivalms" in driver.current_url
        print(f"  Clicked Cancel — browser on User List: {driver.current_url}")

    # ── Step 5: Disable User150426_1 ────────────────────────────────────────
    def test_05_disable_user(self, driver):
        """
        Disable the user 'User150426_1'.

        QA PROCESS:
          1. Navigate to User List.
          2. Search for 'User150426_1'.
          3. Select the user row.
          4. Click the Disable button in the toolbar (id = 'User_tbrDelete').
             NOTE: Despite the ID containing 'Delete', this DISABLES the account —
             it does NOT permanently delete the user record.
          5. A modal dialog appears:
               "Are you sure you want to disable <user>?"
          6. Click Yes in the modal.
          7. Confirm the browser stays on the User List.

        After this test, 'User150426_1' is disabled and will no longer appear in
        the Active User List — it will only be visible via More Options →
        Show Disabled And Locked (see test_06).

        Browser stays on the User List page after this test.
        """

        dismiss_modal_if_open(driver)
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # Search and select the row
        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{NEW_USER_ID}']"
            ))
        )
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"\n  Selected row for '{NEW_USER_ID}'")

        # Click the Disable button
        disable_btn = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((By.ID, "User_tbrDelete"))
        )
        print(
            f"  Disable button found — title='{
                disable_btn.get_attribute('title')}'")
        driver.execute_script("arguments[0].click();", disable_btn)
        time.sleep(PAUSE)

        # Confirm Yes in the modal
        modal = WebDriverWait(driver, WAIT).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id"))
        )
        modal_text = modal.text.strip()
        print(f"  Modal text: '{modal_text[:120]}'")
        assert "disable" in modal_text.lower(), (
            f"Expected disable confirmation dialog, got: '{modal_text[:100]}'"
        )

        yes_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[normalize-space(text())='Yes'] "
                "| //button[normalize-space(.)='Yes'] "
                "| //a[normalize-space(text())='Yes'] "
                "| //input[@value='Yes'] "
                "| //*[@id='Modal-modal-alert-id']//*[contains(normalize-space(text()),'Yes')]"
            ))
        )
        driver.execute_script("arguments[0].click();", yes_btn)
        page_ready(driver)
        time.sleep(PAUSE)

        assert "ultrivalms" in driver.current_url
        print(
            f"  DISABLED '{NEW_USER_ID}' — browser on User List: {
                driver.current_url}")

    # ── Step 6: Enable User150426_1 ─────────────────────────────────────────
    def test_06_enable_user(self, driver):
        """
        Enable the disabled user 'User150426_1'.

        QA PROCESS:
          1. Navigate to User List (shows ACTIVE users by default).
          2. Click More Options dropdown at the top of the grid.
          3. Select 'Show Disabled And Locked' — the grid switches to the
             Disabled/Locked list.
          4. Search for 'User150426_1' in the Disabled list.
          5. Select the user row.
          6. Click the Enable toolbar button.
             (The Enable button is only available on the Disabled list —
              it does NOT appear on the Active list toolbar.)
          7. A modal appears:
               "Are you sure you want to enable <user>?"
          8. Click Yes.
          9. Navigate to the Active User List → search for the user →
             confirm the row is present and shows Active status (green tick icon).

        Browser ends on the Active User List page after this test.
        """

        dismiss_modal_if_open(driver)
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # Click More Options dropdown
        more_opts = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(normalize-space(.),'More Options')] "
                "| //a[contains(normalize-space(.),'More Options')]"
            ))
        )
        driver.execute_script("arguments[0].click();", more_opts)
        time.sleep(1)
        print("\n  Clicked 'More Options'")

        # Select 'Show Disabled And Locked'
        show_disabled = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Show Disabled And Locked'] "
                "| //li[normalize-space(.)='Show Disabled And Locked']"
            ))
        )
        driver.execute_script("arguments[0].click();", show_disabled)
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Disabled list — URL: {driver.current_url}")

        dismiss_modal_if_open(driver)

        # Search and select the row in the Disabled list
        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{NEW_USER_ID}']"
            ))
        )
        print(f"  Found '{NEW_USER_ID}' in Disabled list")
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"  Selected row for '{NEW_USER_ID}'")

        # Click the Enable button
        enable_btn = None
        for by, sel in [
            (By.XPATH, "//a[@title='Enable'] | //button[@title='Enable']"),
            (By.XPATH, "//a[normalize-space(.)='Enable'] | //button[normalize-space(.)='Enable']"),
            (By.ID, "User_tbrEnable"),
        ]:
            try:
                enable_btn = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, sel))
                )
                print(f"  Enable button found via: {sel}")
                break
            except Exception:
                continue

        assert enable_btn is not None, (
            "Enable button not found — confirm the user is on the Disabled list"
        )
        driver.execute_script("arguments[0].click();", enable_btn)
        time.sleep(PAUSE)

        # Confirm Yes in the modal
        modal = WebDriverWait(driver, WAIT).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id"))
        )
        modal_text = modal.text.strip()
        print(f"  Modal text: '{modal_text[:120]}'")
        assert "enable" in modal_text.lower(), (
            f"Expected enable confirmation dialog, got: '{modal_text[:100]}'"
        )

        yes_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[normalize-space(text())='Yes'] "
                "| //button[normalize-space(.)='Yes'] "
                "| //a[normalize-space(text())='Yes'] "
                "| //input[@value='Yes'] "
                "| //*[@id='Modal-modal-alert-id']//*[contains(normalize-space(text()),'Yes')]"
            ))
        )
        driver.execute_script("arguments[0].click();", yes_btn)
        page_ready(driver)
        time.sleep(PAUSE)
        print("  Clicked Yes — enable request submitted")

        # Navigate to Active User List and verify the user is back
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        row = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//tr[td[normalize-space(text())='{NEW_USER_ID}']]"
            ))
        )
        row_html = row.get_attribute("outerHTML")
        is_active = "enable1.gif" in row_html or "Active" in row_html
        if is_active:
            print(f"  VERIFIED: '{NEW_USER_ID}' status = ACTIVE (green tick)")
        else:
            print(
                f"  NOTE: '{NEW_USER_ID}' row found in Active list — verify icon manually")

        assert "ultrivalms" in driver.current_url
        print(f"  Browser on Active User List — URL: {driver.current_url}")

    # ── Step 7: Update Email ID for the enabled User150426_1 ────────────────
    def test_07_update_email(self, driver):
        """
        Update the Email ID of the enabled user 'User150426_1'.

        QA PROCESS — Update Email ID to Enabled User:
          1. Navigate to User List (browser already there; user is now active/enabled).
          2. Search for 'User150426_1' using the search box.
          3. Select the user row (row highlights).
          4. Click the Edit toolbar button.
          5. On the Edit User page, clear the Email ID field and type the new email:
               vseelam@uplandsoftware.com
          6. Click Save.
          7. Navigate back to User List and confirm the browser is on the list page.

        This test verifies that an enabled user's email can be updated via the Edit form.
        Browser stays on the User List page after this test.
        """

        NEW_EMAIL = "vseelam@uplandsoftware.com"

        # Login if running this test standalone (no prior session from test_01).
        # We detect the login page by checking for the login-button element,
        # not by URL, because BASE_URL itself is the login page (no /login
        # path).
        driver.get(BASE_URL)
        page_ready(driver)
        time.sleep(PAUSE)
        if driver.find_elements(By.ID, "login-button"):
            # Login form is visible — we need to authenticate
            driver.find_element(By.ID, "UserName").clear()
            driver.find_element(By.ID, "UserName").send_keys(ADMIN_USER)
            driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
            driver.find_element(By.ID, "login-button").click()
            page_ready(driver)
            time.sleep(PAUSE)
            print("  [standalone] Logged in for test_07")

        dismiss_modal_if_open(driver)
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # Search and select the row
        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{NEW_USER_ID}']"
            ))
        )
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"\n  Selected row for '{NEW_USER_ID}'")

        # Click the Edit toolbar button
        edit_btn = None
        for by, sel in [
            (By.XPATH, "//a[@title='Edit'] | //button[@title='Edit']"),
            (By.XPATH, "//a[normalize-space(.)='Edit'] | //button[normalize-space(.)='Edit']"),
            (By.ID, "User_tbrEdit"),
        ]:
            try:
                edit_btn = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((by, sel))
                )
                break
            except Exception:
                continue

        assert edit_btn is not None, "Edit button not found in toolbar"
        driver.execute_script("arguments[0].click();", edit_btn)
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Edit form — URL: {driver.current_url}")

        # Update the Email ID field with the new email address
        email_field = WebDriverWait(driver, WAIT).until(
            EC.visibility_of_element_located((By.NAME, "PRS$EmailID"))
        )
        current_email = email_field.get_attribute("value")
        print(f"  Current Email ID: '{current_email}'")
        email_field.clear()
        email_field.send_keys(NEW_EMAIL)
        print(f"  Updated Email ID to: '{NEW_EMAIL}'")
        time.sleep(1)

        # Click Save
        saved = False
        for by, sel in [
            (By.ID, "entryPGSubmit"),
            (By.XPATH, "//a[@title='Save' and contains(@onclick,'frmEntryPage_onSubmit')]"),
            (By.XPATH, "//a[@title='Save']"),
            (By.XPATH, "//input[@value='Save'] | //button[normalize-space(text())='Save']"),
        ]:
            try:
                btn = WebDriverWait(
                    driver, 5).until(
                    EC.element_to_be_clickable(
                        (by, sel)))
                driver.execute_script("arguments[0].click();", btn)
                saved = True
                break
            except Exception:
                continue

        assert saved, "Save button not found on Edit User form"
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Saved — URL: {driver.current_url}")

        # Navigate back to User List
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)
        assert "ultrivalms" in driver.current_url
        print(f"  Email updated — browser on User List: {driver.current_url}")

    # ── Step 8: Assign Groups to User150426_1 ───────────────────────────────
    def test_08_assign_groups(self, driver):
        """
        Assign Groups to User 'User150426_1'.

        QA PROCESS — Assign Groups to User:
          1. Navigate to User List.
          2. Search for 'User150426_1' and select the row.
          3. Click More Options dropdown → click 'Groups'.
             (Opens the Assigned Groups page: /User/AssignedGroups?GID=...)
          4. On the Assigned Groups page, click 'Show Unassigned Groups' button.
             (Switches to the Assign Groups page listing all groups not yet assigned)
          5. In the Assign Groups list, check the checkbox for 'Global Plant users'.
          6. Click the 'Assign' button.
          7. Confirm the success banner:
             "The selected Group(s) are assigned to the User successfully"
          8. Click the 'Back' button to return to the User List.

        Browser ends on the User List page after this test.
        """

        GROUP_TO_ASSIGN = "Global Plant users"

        # Login if running standalone
        driver.get(BASE_URL)
        page_ready(driver)
        time.sleep(PAUSE)
        if driver.find_elements(By.ID, "login-button"):
            driver.find_element(By.ID, "UserName").clear()
            driver.find_element(By.ID, "UserName").send_keys(ADMIN_USER)
            driver.find_element(By.ID, "Password").send_keys(ADMIN_PASS)
            driver.find_element(By.ID, "login-button").click()
            page_ready(driver)
            time.sleep(PAUSE)
            print("  [standalone] Logged in for test_08")

        dismiss_modal_if_open(driver)
        driver.get(f"{BASE_URL}/User/List")
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        # ── Search and select User150426_1 ───────────────────────────────────
        try:
            sb = WebDriverWait(driver, 8).until(
                EC.visibility_of_element_located((By.NAME, "User_FindTextbox"))
            )
            sb.clear()
            sb.send_keys(NEW_USER_ID)
            time.sleep(PAUSE)
        except Exception:
            pass

        user_cell = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH, f"//td[normalize-space(text())='{NEW_USER_ID}']"
            ))
        )
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});",
            user_cell)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"\n  Selected row for '{NEW_USER_ID}'")

        # ── More Options → Groups ────────────────────────────────────────────
        more_opts = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(normalize-space(.),'More Options')] "
                "| //a[contains(normalize-space(.),'More Options')]"
            ))
        )
        driver.execute_script("arguments[0].click();", more_opts)
        time.sleep(1)
        print("  Clicked 'More Options'")

        groups_link = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Groups'] "
                "| //li[normalize-space(.)='Groups']"
            ))
        )
        driver.execute_script("arguments[0].click();", groups_link)
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Assigned Groups page — URL: {driver.current_url}")
        assert "AssignedGroups" in driver.current_url, (
            "Did not reach Assigned Groups page"
        )

        # ── Show Unassigned Groups ───────────────────────────────────────────
        # The button text is "Show Unassigned Groups" on the Assigned Groups
        # page
        show_unassigned = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[contains(normalize-space(.),'Show Unassigned Groups')] "
                "| //button[contains(normalize-space(.),'Show Unassigned Groups')]"
            ))
        )
        driver.execute_script("arguments[0].click();", show_unassigned)
        page_ready(driver)
        time.sleep(PAUSE)
        print(f"  Assign Groups (unassigned list) — URL: {driver.current_url}")

        # ── If unassigned list is empty (all groups already assigned), remove one ──
        # Prior test runs may have assigned ALL groups, leaving nothing to assign.
        # In that case: navigate back to Assigned Groups, remove any one group,
        # then re-open the Unassigned list so there is at least one entry.
        # NOTE: the grid uses type="Checkbox" (capital C) — use
        # @class='GridCheckbox'
        quick_cbs = driver.find_elements(
            By.XPATH,
            "//input[@class='GridCheckbox' and not(contains(@name,'_All'))]"
        )
        if not quick_cbs:
            print("  Unassigned list is empty — removing one assigned group first")
            assigned_url = (
                driver.current_url
                .replace("AssignGroups", "AssignedGroups")
                .split("&iea=")[0]
            )
            driver.get(assigned_url)
            page_ready(driver)
            time.sleep(PAUSE)
            # Select the first data-row checkbox in the AssignedGroups grid
            first_assigned = WebDriverWait(driver, WAIT).until(
                EC.presence_of_element_located((
                    By.XPATH,
                    "//table[@id='AssignedGroups4User']"
                    "//tr[@class='DataRow']"
                    "//input[@class='GridCheckbox']"
                ))
            )
            driver.execute_script("arguments[0].click();", first_assigned)
            time.sleep(0.5)
            remove_btn = WebDriverWait(driver, WAIT).until(
                EC.element_to_be_clickable((
                    By.XPATH,
                    "//a[normalize-space(.)='Remove'] "
                    "| //button[normalize-space(.)='Remove'] "
                    "| //input[@value='Remove']"
                ))
            )
            driver.execute_script("arguments[0].click();", remove_btn)
            time.sleep(1)
            # Confirm the "Yes/No" modal that appears after clicking Remove
            try:
                confirm_modal = WebDriverWait(
                    driver, 5).until(
                    EC.visibility_of_element_located(
                        (By.ID, "Modal-modal-alert-id")))
                yes_btn = WebDriverWait(
                    driver, WAIT).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//button[normalize-space(text())='Yes'] "
                         "| //button[normalize-space(.)='Yes'] "
                         "| //a[normalize-space(text())='Yes'] "
                         "| //input[@value='Yes'] "
                         "| //*[@id='Modal-modal-alert-id']//*[contains(normalize-space(text()),'Yes')]")))
                driver.execute_script("arguments[0].click();", yes_btn)
                print("  Confirmed removal via modal Yes")
            except Exception:
                pass  # No confirmation modal — removal may complete directly
            page_ready(driver)
            time.sleep(PAUSE)
            print("  Removed one group — now re-opening unassigned list")
            show_unassigned_retry = WebDriverWait(
                driver, WAIT).until(
                EC.element_to_be_clickable(
                    (By.XPATH, "//a[contains(normalize-space(.),'Show Unassigned Groups')] "
                     "| //button[contains(normalize-space(.),'Show Unassigned Groups')]")))
            driver.execute_script(
                "arguments[0].click();",
                show_unassigned_retry)
            page_ready(driver)
            time.sleep(PAUSE)
            print(
                f"  Assign Groups (unassigned list, retry) — URL: {
                    driver.current_url}")

        # ── Select the group checkbox ────────────────────────────────────────
        # Wait for the unassigned groups table to load, then tick the first
        # available group checkbox.
        # NOTE: the grid uses type="Checkbox" (capital C) — match by class
        # instead
        first_checkbox = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH,
                "//input[@class='GridCheckbox' and not(contains(@name,'_All'))]"
            ))
        )
        # Get the group name via JS innerText (works for text in nested <a>
        # tags too)
        group_row = first_checkbox.find_element(By.XPATH, "./ancestor::tr[1]")
        tds = group_row.find_elements(By.TAG_NAME, "td")
        group_name = "Unknown"
        for td in tds:
            name = driver.execute_script(
                "return arguments[0].innerText.trim();", td)
            if name:
                group_name = name
                break
        if not first_checkbox.is_selected():
            driver.execute_script("arguments[0].click();", first_checkbox)
            time.sleep(0.5)
        print(f"  Checked group: '{group_name}'")

        # ── Click Assign ─────────────────────────────────────────────────────
        assign_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Assign'] "
                "| //button[normalize-space(.)='Assign'] "
                "| //input[@value='Assign']"
            ))
        )
        driver.execute_script("arguments[0].click();", assign_btn)
        page_ready(driver)
        time.sleep(PAUSE)
        print("  Clicked Assign")

        # ── Verify success banner ────────────────────────────────────────────
        # After assigning, the page shows the Assigned Groups list with a
        # success message: "The selected Group(s) are assigned to the User
        # successfully"
        success_banner = WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH,
                "//*[contains(normalize-space(.),'assigned to the User successfully')]"
            ))
        )
        print(f"  Success: '{success_banner.text.strip()}'")
        assert "assigned to the User successfully" in success_banner.text, (
            "Group assignment success message not found"
        )

        # Confirm the group now appears in the Assigned Groups list
        WebDriverWait(driver, WAIT).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(.)='{group_name}']"
            ))
        )
        print(f"  VERIFIED: '{group_name}' is in Assigned Groups list")

        # ── Click Back → returns to User List ────────────────────────────────
        back_btn = WebDriverWait(driver, WAIT).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Back'] "
                "| //button[normalize-space(.)='Back'] "
                "| //a[@title='Back']"
            ))
        )
        driver.execute_script("arguments[0].click();", back_btn)
        page_ready(driver)
        time.sleep(PAUSE)
        dismiss_modal_if_open(driver)

        assert "ultrivalms" in driver.current_url
        print(f"  Clicked Back — browser on User List: {driver.current_url}")
