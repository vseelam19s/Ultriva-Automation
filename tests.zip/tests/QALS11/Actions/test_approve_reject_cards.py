"""
QALS11 | Actions > Approve — Approve Cards & Reject Cards (Combined)
=====================================================================
URL   : https://engineering.ultrivalms.com/QALS1011
User  : buyeruser / Ultriva!23

Test Flows
----------
  [TestApproveCards   — TC-APR-001 … TC-APR-007]
    1.  Login as buyeruser
    2.  Navigate to Actions menu
    3.  Click Approve → ApproveFilter
    4.  Apply filter (Go) → ApproveItems list
    5.  Click first item → ApproveCards list
    6.  Select cards → click Approve → verify ApproveResults
        ("Following Cards were successful" / "Card Successfully Approved.")
    7.  Click Back to Items → verify return to ApproveItems

  [TestRejectApproveCards — TC-REJ-001 … TC-REJ-007]
    1.  Login as buyeruser
    2.  Navigate to Actions menu
    3.  Click Approve → ApproveFilter
    4.  Apply filter (Go) → ApproveItems list
    5.  Click first item → ApproveCards list
    6.  Enter rejection comment on page → click Reject
        → verify RejectResults
        ("Following Cards were successful" / "Card Successfully Rejected.")
    7.  Click Back to Items → verify return to ApproveItems

Run (from qa_automation/):
    pytest tests/QALS11/Actions/test_approve_reject_cards.py -v -s
"""

import os
import time
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ============================================================================
# CONFIGURATION
# ============================================================================
BASE_URL = "https://engineering.ultrivalms.com/QALS1011"
USERNAME = "buyeruser"
PASSWORD = "Ultriva!23"
PAUSE = 1.5
REJECT_COMMENT = "Rejecting card — quality issue noted during inspection."

# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture(scope="class")
def driver():
    """Class-scoped Chrome driver — one browser session per test class."""
    options = webdriver.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-logging"])
    drv = webdriver.Chrome(options=options)
    drv.implicitly_wait(10)
    drv.set_page_load_timeout(30)
    drv.maximize_window()
    yield drv
    drv.quit()

# ============================================================================
# HELPERS
# ============================================================================

def wait_ready(driver, timeout=30):
    """Wait for document.readyState == complete."""
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )

def find(driver, by, locator, timeout=15):
    return WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((by, locator))
    )

def clickable(driver, by, locator, timeout=15):
    return WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, locator))
    )

def scroll_to(driver, el):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'})", el)
    time.sleep(0.3)

def take_screenshot(driver, name, prefix="ar"):
    """Save screenshot to reports/screenshots/{prefix}_{name}_{timestamp}.png."""
    screenshots_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "..", "reports", "screenshots"
    )
    os.makedirs(screenshots_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(screenshots_dir, f"{prefix}_{name}_{ts}.png")
    driver.save_screenshot(path)
    print(f"  [screenshot] {path}")
    return path

def _navigate_to_approve_filter(driver):
    """Shared helper: navigate to BuyerAction/ApproveFilter (not RLApprove)."""
    locators = [
        (By.XPATH, "//a[contains(@href,'ApproveFilter') and not(contains(@href,'RLApprove'))]"),
        (By.XPATH, "//a[contains(@href,'BuyerAction/Approve') and not(contains(@href,'RLApprove'))]"),
        (By.XPATH, "//span[normalize-space(text())='Approve' and not(ancestor::*[contains(@href,'RLApprove')])]."),
        (By.XPATH, "(//a[normalize-space(.)='Approve' or contains(@href,'ApproveFilter')])[1]"),
    ]
    for locator in locators:
        try:
            tile = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
            if "RLApprove" not in (tile.get_attribute("href") or ""):
                driver.execute_script("arguments[0].click()", tile)
                wait_ready(driver)
                time.sleep(PAUSE)
                if "RLApprove" not in driver.current_url:
                    return
        except Exception:
            continue
    # Direct fallback
    driver.get(f"{BASE_URL}/BuyerAction/ApproveFilter")
    wait_ready(driver)
    time.sleep(PAUSE)

def _click_go_load_items(driver):
    """Shared helper: click Go on ApproveFilter → land on ApproveItems."""
    if "ApproveFilter" not in driver.current_url:
        driver.get(f"{BASE_URL}/BuyerAction/ApproveFilter")
        wait_ready(driver)
        time.sleep(PAUSE)
    
    time.sleep(PAUSE)  # let filter page fully render
    go_btn = None
    locators = [
        (By.ID, "btnGoBot"),
        (By.ID, "btnGoTop"),
        (By.XPATH, "//button[normalize-space(text())='Go']"),
        (By.XPATH, "//input[@type='button' and @value='Go']"),
        (By.XPATH, "//span[normalize-space(text())='Go' and (contains(@class,'btn') or contains(@class,'toolbar'))]"),
        (By.XPATH, "//a[normalize-space(text())='Go']"),
        (By.XPATH, "//*[@id='btnGo' or contains(@id,'btnGo') or contains(@id,'BtnGo')]"),
        (By.XPATH, "//span[@id='imgMatStatusGo']"),
    ]
    for locator in locators:
        try:
            go_btn = WebDriverWait(driver, 8).until(EC.element_to_be_clickable(locator))
            break
        except Exception:
            continue
            
    if not go_btn:
        go_btn = driver.execute_script(
            "var els=document.querySelectorAll('button,input,a,span');"
            "for(var i=0;i<els.length;i++){"
            "  var t=(els[i].innerText||els[i].value||'').trim();"
            "  if(t==='Go'&&els[i].offsetParent!==null) return els[i];"
            "} return null;"
        )
        if go_btn:
            print("  [INFO] Go button found via JS")
            
    if go_btn:
        driver.execute_script("arguments[0].click()", go_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)
    else:
        print("  [INFO] Go button not found — navigating directly to ApproveItems...")
        driver.get(f"{BASE_URL}/BuyerAction/ApproveItems")
        wait_ready(driver)
        time.sleep(PAUSE)
        
    if "RLApprove" in driver.current_url:
        driver.get(f"{BASE_URL}/BuyerAction/ApproveItems")
        wait_ready(driver)
        time.sleep(PAUSE)

def _find_items(driver, timeout=3):
    """Shared helper: find clickable item links on ApproveItems page."""
    locators = [
        (By.XPATH, "//a[contains(@class,'GridLink')]"),
        (By.XPATH, "//table//td//a[not(contains(@class,'btn'))]"),
        (By.XPATH, "//a[contains(@href,'ApproveCards')]"),
        (By.XPATH, "//a[contains(@href,'GID=')]"),
    ]
    for locator in locators:
        try:
            found = WebDriverWait(driver, timeout).until(EC.presence_of_all_elements_located(locator))
            links = [l for l in found if l.text.strip()]
            if links:
                return links
        except Exception:
            continue
    return []

def _select_card_checkboxes(driver):
    """Shared helper: select up to 3 card row checkboxes inside <td> cells."""
    WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.XPATH, "//table//td")))
    time.sleep(PAUSE)
    
    card_cbs = driver.find_elements(By.XPATH, "//table//td//input[@type='checkbox']")
    if not card_cbs:
        all_cbs = driver.find_elements(By.XPATH, "//input[@type='checkbox']")
        card_cbs = [
            cb for cb in all_cbs
            if 'GridCheckbox' in (cb.get_attribute('class') or '')
            and 'grid-all-checkbox' not in (cb.get_attribute('class') or '')
        ]
        
    selected = 0
    for cb in card_cbs[:3]:
        try:
            cb_name = cb.get_attribute('name') or ''
            cb_value = cb.get_attribute('value') or ''
            cb_class = cb.get_attribute('class') or ''
            print(f"  [INFO] Checkbox — name={cb_name!r}  value={cb_value!r}  class={cb_class!r}")
            scroll_to(driver, cb)
            driver.execute_script("arguments[0].click()", cb)
            time.sleep(0.5)
            selected += 1
            print(f"  [INFO] Selected checkbox #{selected}")
        except Exception as e:
            print(f"  [WARN] Could not click checkbox: {e}")
    return selected

def _click_back_to_items(driver):
    """Shared helper: click Back to Items and return the resulting URL."""
    back_btn = None
    locators = [
        (By.ID, "btnBackPageTop"),
        (By.ID, "btnBackPageBot"),
        (By.XPATH, "//span[@id='btnBackPageTop' or @id='btnBackPageBot']"),
        (By.XPATH, "//span[contains(@class,'vd-blue-btn') and contains(normalize-space(),'Back')]"),
        (By.XPATH, "//*[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
    ]
    for locator in locators:
        try:
            back_btn = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
            print(f"  [INFO] Found Back button: '{back_btn.text.strip()}'")
            break
        except Exception:
            continue
            
    if not back_btn:
        back_btn = driver.execute_script(
            "return document.getElementById('btnBackPageTop')"
            " || document.getElementById('btnBackPageBot')"
            " || (function(){"
            "  var all=document.querySelectorAll('*');"
            "  for(var i=0;i<all.length;i++){"
            "    var t=(all[i].innerText||'').trim().toLowerCase();"
            "    if(t==='back to items'&&all[i].offsetParent!==null) return all[i];"
            "  } return null; })()"
        )
        if back_btn:
            print("  [INFO] Back to Items found via JS")
    return back_btn

# ============================================================================
# TEST CLASS 1 — APPROVE CARDS
# ============================================================================

@pytest.mark.usefixtures("driver")
class TestApproveRejectCards:
    """End-to-end flow: select cards → Approve / Reject → verify Results."""

    # ── TC-APR-001 ───────────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """Login to QA site with buyeruser credentials."""
        print("\n[TC-APR-001] Logging in to QA site...")
        driver.get(BASE_URL)
        wait_ready(driver)

        username_field = find(driver, By.ID, "UserName")
        password_field = find(driver, By.ID, "Password")
        login_button = clickable(driver, By.ID, "login-button")

        username_field.clear()
        username_field.send_keys(USERNAME)
        password_field.clear()
        password_field.send_keys(PASSWORD)
        login_button.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "01_after_login", "approve")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert BASE_URL.lower() in current_url.lower() or "Home" in current_url, \
            f"Login may have failed. URL: {current_url}"
        print("  [PASS] Login successful.")

    # ── TC-APR-002 ───────────────────────────────────────────────────────
    def test_02_navigate_to_actions(self, driver):
        """Click Actions in the left sidebar to open the Buyer Actions page."""
        print("\n[TC-APR-002] Navigating to Actions page...")
        actions_link = clickable(
            driver, By.XPATH,
            "//a[contains(@href,'Action/Home') or (.//span[normalize-space()='Actions']) or normalize-space(.)='Actions']",
        )
        scroll_to(driver, actions_link)
        actions_link.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "02_actions_page", "approve")
        assert "Action/Home" in driver.current_url, f"Expected Actions page. Got: {driver.current_url}"
        print(f"  [PASS] Actions page loaded: {driver.current_url}")

    # ── TC-APR-003 ───────────────────────────────────────────────────────
    def test_03_click_approve(self, driver):
        """Click the Approve tile from the Buyer Actions page → ApproveFilter."""
        print("\n[TC-APR-003] Clicking Approve tile in Buyer Actions...")
        _navigate_to_approve_filter(driver)

        take_screenshot(driver, "03_approve_filter", "approve")
        print(f"  [URL] {driver.current_url}")
        assert any(kw in driver.current_url for kw in ["ApproveFilter", "Approve"]), \
            f"Expected ApproveFilter. Got: {driver.current_url}"
        print(f"  [PASS] Approve page loaded: {driver.current_url}")

    # ── TC-APR-004 ───────────────────────────────────────────────────────
    def test_04_apply_filter_and_load_items(self, driver):
        """Click Go on Approve Filter page to load the Approve Items List."""
        print("\n[TC-APR-004] Applying filter — clicking Go button...")

        current_url = driver.current_url
        if "ApproveItems" in current_url and "RLApprove" not in current_url:
            print("  [INFO] Already on Approve Items page.")
        else:
            _click_go_load_items(driver)

        take_screenshot(driver, "04_approve_items_list", "approve")
        print(f"  [URL] {driver.current_url}")
        assert "ApproveItem" in driver.current_url and "RLApprove" not in driver.current_url, \
            f"Expected ApproveItems (not RLApprove). Got: {driver.current_url}"
        print(f"  [PASS] Approve Items List loaded: {driver.current_url}")

    # ── TC-APR-005 ───────────────────────────────────────────────────────
    def test_05_select_item_show_cards(self, driver):
        """Click the first item in the list to reach Approve Cards."""
        print("\n[TC-APR-005] Selecting first item and clicking Show Cards...")

        item_links = _find_items(driver, timeout=10)
        if not item_links:
            pytest.skip("No items available in Approve Items List — test data may be depleted")

        first_item = item_links[0]
        print(f"  [INFO] First item found: '{first_item.text.strip()}'")
        scroll_to(driver, first_item)
        driver.execute_script("arguments[0].click()", first_item)
        wait_ready(driver)
        time.sleep(PAUSE * 2)
        take_screenshot(driver, "05a_after_item_click", "approve")
        print(f"  [INFO] URL after item click: {driver.current_url}")
        
        if any(kw in driver.current_url for kw in ["ApproveCard", "approvecard"]):
            print("  [INFO] Navigated directly to Approve Cards page.")
            return

        # Try Show Cards button if GridLink didn't navigate directly
        locators = [
            (By.ID, "btnShowCardsT"), (By.ID, "btnShowCardsB"),
            (By.XPATH, "//button[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Show Cards')]"),
        ]
        for locator in locators:
            try:
                btn = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
                scroll_to(driver, btn)
                driver.execute_script("arguments[0].click()", btn)
                wait_ready(driver)
                time.sleep(PAUSE * 2)
                break
            except Exception:
                continue

        take_screenshot(driver, "05b_approve_cards_list", "approve")
        print(f"  [URL] {driver.current_url}")
        assert any(kw in driver.current_url for kw in ["ApproveCard", "approvecard"]), \
            f"Expected Approve Cards page. Got: {driver.current_url}"
        print(f"  [PASS] Approve Cards List confirmed: {driver.current_url}")

    # ── TC-APR-006 ───────────────────────────────────────────────────────
    def test_06_select_cards_approve_and_finish(self, driver):
        """Select cards → Approve → verify ApproveResults success page."""
        print("\n[TC-APR-006] Selecting cards → Approve → verify success message...")

        if "ApproveCard" not in driver.current_url:
            print("  [INFO] Not on ApproveCards — navigating via ApproveItems...")
            driver.get(f"{BASE_URL}/BuyerAction/ApproveItems")
            wait_ready(driver)
            time.sleep(PAUSE)
            links = _find_items(driver)
            if not links:
                pytest.skip("No items available in Approve Items List — test data may be depleted")
            driver.execute_script("arguments[0].click()", links[0])
            wait_ready(driver)
            time.sleep(PAUSE * 2)

        selected = _select_card_checkboxes(driver)
        assert selected > 0, "Could not select any card checkboxes"
        print(f"  [INFO] Total selected: {selected}")
        take_screenshot(driver, "06a_cards_selected", "approve")

        # Click Approve button
        print("  [INFO] Clicking Approve button...")
        approve_btn = None
        locators = [
            (By.ID, "btndoActTop"), (By.ID, "btndoActBot"),
            (By.XPATH, "//span[@onclick='da()']"),
            (By.XPATH, "//button[normalize-space(text())='Approve Cards']"),
            (By.XPATH, "//button[normalize-space(text())='Approve']"),
            (By.XPATH, "//a[normalize-space(text())='Approve Cards']"),
            (By.XPATH, "//a[normalize-space(text())='Approve']"),
            (By.XPATH, "//span[contains(normalize-space(),'Approve') and (contains(@class,'btn') or contains(@class,'toolbar')) and not(contains(normalize-space(),'Back'))]"),
            (By.XPATH, "//*[@id='btnApprove' or contains(@id,'doAct')]"),
        ]
        for locator in locators:
            try:
                candidate = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
                btn_text = candidate.text.strip().lower()
                if btn_text not in ("back to items", "back", ""):
                    approve_btn = candidate
                    break
            except Exception:
                continue

        assert approve_btn, "Approve button not found on ApproveCards page"
        print(f"  [INFO] Found Approve button: '{approve_btn.text.strip()}'")
        scroll_to(driver, approve_btn)
        driver.execute_script("arguments[0].click()", approve_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)
        take_screenshot(driver, "06b_after_approve_click", "approve")
        print(f"  [INFO] URL after Approve click: {driver.current_url}")

        # Handle optional Notes dialog
        dialog_locators = [
            (By.ID, "btnapNodoAct"),
            (By.XPATH, "//button[contains(normalize-space(),'Approve without Notes')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Approve without Notes')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Approve without Notes')]"),
        ]
        for locator in dialog_locators:
            try:
                dialog_btn = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
                print(f"  [INFO] Notes dialog: '{dialog_btn.text.strip()}' — clicking...")
                driver.execute_script("arguments[0].click()", dialog_btn)
                wait_ready(driver)
                time.sleep(PAUSE * 2)
                take_screenshot(driver, "06c_after_notes_dialog", "approve")
                print(f"  [INFO] URL after notes dialog: {driver.current_url}")
                break
            except Exception:
                continue

        # Verify ApproveResults
        print("  [INFO] Waiting for ApproveResults page and success message...")
        try:
            WebDriverWait(driver, 15).until(lambda d: "ApproveResult" in d.current_url)
            print(f"  [INFO] Landed on results page: {driver.current_url}")
        except Exception:
            print(f"  [INFO] Still on: {driver.current_url} — checking success text")

        take_screenshot(driver, "06d_approve_results", "approve")
        success_found = False
        msg_locators = [
            (By.XPATH, "//*[contains(normalize-space(),'Following Cards were successful')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Card Successfully Approved')]"),
            (By.XPATH, "//*[contains(normalize-space(),'successful')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Approve Cards Results')]"),
        ]
        for locator in msg_locators:
            try:
                el = WebDriverWait(driver, 8).until(EC.presence_of_element_located(locator))
                print(f"  [INFO] Success message: '{el.text.strip()[:120]}'")
                success_found = True
                break
            except Exception:
                continue

        assert "ApproveResult" in driver.current_url or success_found, \
            f"Expected ApproveResults with success message. URL: {driver.current_url} success_found={success_found}"
        print("  [PASS] Approve Cards Results page verified — cards successfully approved.")

    # ── TC-APR-007 ───────────────────────────────────────────────────────
    def test_07_back_to_items(self, driver):
        """Click Back to Items and verify return to Approve Items List."""
        print("\n[TC-APR-007] Clicking Back to Items...")
        print(f"  [INFO] Currently on: {driver.current_url}")

        if "ApproveCard" not in driver.current_url and "ApproveResult" not in driver.current_url:
            print("  [INFO] Re-navigating via ApproveItems → item click...")
            driver.get(f"{BASE_URL}/BuyerAction/ApproveItems")
            wait_ready(driver)
            time.sleep(PAUSE)
            links = _find_items(driver, timeout=20)
            if not links:
                pytest.skip("No items available in Approve Items List — test data may be depleted")
            print(f"  [INFO] Clicking item: '{links[0].text.strip()}'")
            driver.execute_script("arguments[0].click()", links[0])
            wait_ready(driver)
            time.sleep(PAUSE * 2)

        back_btn = _click_back_to_items(driver)
        assert back_btn, "Back to Items button not found"
        scroll_to(driver, back_btn)
        driver.execute_script("arguments[0].click()", back_btn)
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "07_back_to_items", "approve")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert any(kw in current_url for kw in ["ApproveItem", "Approve", "approve"]), \
            f"Expected Approve Items page. Got: {current_url}"
        print("  [PASS] Successfully returned to Approve Items List.")


# ============================================================================
# TEST CLASS 2 — REJECT APPROVE CARDS (WITH COMMENTS)
# ============================================================================

@pytest.mark.usefixtures("driver")
class TestRejectApproveCards:
    """End-to-end flow: select cards → enter comment → Reject → verify RejectResults."""

    # ── TC-REJ-001 ───────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """Login to QA site with buyeruser credentials."""
        print("\n[TC-REJ-001] Logging in to QA site...")
        driver.get(BASE_URL)
        wait_ready(driver)

        find(driver, By.ID, "UserName").send_keys(USERNAME)
        find(driver, By.ID, "Password").send_keys(PASSWORD)
        clickable(driver, By.ID, "login-button").click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "01_after_login", "reject")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert BASE_URL.lower() in current_url.lower() or "Home" in current_url, \
            f"Login failed. URL: {current_url}"
        print("  [PASS] Login successful.")

    # ── TC-REJ-002 ───────────────────────────────────────────────────────
    def test_02_navigate_to_actions(self, driver):
        """Navigate to the Actions page via left sidebar or direct URL."""
        print("\n[TC-REJ-002] Navigating to Actions page...")

        nav_clicked = False
        locators = [
            (By.XPATH, "//a[contains(@href,'/Action/Home')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Actions')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Actions')]"),
            (By.XPATH, "//li[contains(@class,'nav')]//a[contains(normalize-space(),'Action')]"),
        ]
        for locator in locators:
            try:
                link = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
                driver.execute_script("arguments[0].click()", link)
                wait_ready(driver)
                time.sleep(PAUSE)
                if "Action" in driver.current_url:
                    nav_clicked = True
                    break
            except Exception:
                continue

        if not nav_clicked:
            driver.get(f"{BASE_URL}/Action/Home")
            wait_ready(driver)
            time.sleep(PAUSE)

        take_screenshot(driver, "02_actions_page", "reject")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert "Action" in current_url, f"Expected Actions page. Got: {current_url}"
        print(f"  [PASS] Actions page loaded: {current_url}")

    # ── TC-REJ-003 ───────────────────────────────────────────────────────
    def test_03_click_approve_tile(self, driver):
        """Click the Approve tile in Buyer Actions to reach ApproveFilter."""
        print("\n[TC-REJ-003] Clicking Approve tile in Buyer Actions...")
        _navigate_to_approve_filter(driver)

        take_screenshot(driver, "03_approve_filter", "reject")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert "ApproveFilter" in current_url, f"Expected ApproveFilter. Got: {current_url}"
        print(f"  [PASS] Approve page loaded: {current_url}")

    # ── TC-REJ-004 ───────────────────────────────────────────────────────
    def test_04_apply_filter_load_items(self, driver):
        """Click Go button on Approve Filter page to load Approve Items List."""
        print("\n[TC-REJ-004] Applying filter — clicking Go button...")
        _click_go_load_items(driver)

        take_screenshot(driver, "04_approve_items_list", "reject")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert "ApproveItem" in current_url, f"Expected ApproveItems. Got: {current_url}"
        print(f"  [PASS] Approve Items List loaded: {current_url}")

    # ── TC-REJ-005 ───────────────────────────────────────────────────────
    def test_05_click_item_show_cards(self, driver):
        """Click first item from Approve Items List to reach Approve Cards list."""
        print("\n[TC-REJ-005] Selecting first item to open Approve Cards...")

        if "ApproveItem" not in driver.current_url:
            driver.get(f"{BASE_URL}/BuyerAction/ApproveItems")
            wait_ready(driver)
            time.sleep(PAUSE)

        item_links = _find_items(driver)
        if not item_links:
            pytest.skip("No items available in Approve Items List — test data may be depleted")

        first_item = item_links[0]
        print(f"  [INFO] First item found: '{first_item.text.strip()}'")
        driver.execute_script("arguments[0].click()", first_item)
        wait_ready(driver)
        time.sleep(PAUSE * 2)
        take_screenshot(driver, "05a_after_item_click", "reject")
        print(f"  [INFO] URL after item click: {driver.current_url}")

        if "ApproveCards" not in driver.current_url:
            print("  [INFO] Looking for Show Cards button...")
            locators = [
                (By.XPATH, "//button[contains(normalize-space(),'Show Cards')]"),
                (By.XPATH, "//a[contains(normalize-space(),'Show Cards')]"),
                (By.XPATH, "//input[@value='Show Cards']"),
            ]
            for locator in locators:
                try:
                    btn = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
                    driver.execute_script("arguments[0].click()", btn)
                    wait_ready(driver)
                    time.sleep(PAUSE * 2)
                    break
                except Exception:
                    continue

        take_screenshot(driver, "05b_approve_cards", "reject")
        current_url = driver.current_url
        print(f"  [INFO] URL on ApproveCards: {current_url}")
        assert "ApproveCard" in current_url or "approvecard" in current_url.lower(), \
            f"Expected ApproveCards page. Got: {current_url}"
        print("  [PASS] Approve Cards List loaded.")

    # ── TC-REJ-006 ───────────────────────────────────────────────────────
    def test_06_select_cards_reject_with_comment(self, driver):
        """Select cards, enter comment on page, click Reject, verify RejectResults."""
        print("\n[TC-REJ-006] Selecting cards → Reject with comment → verify results...")

        if "ApproveCard" not in driver.current_url:
            print("  [INFO] Navigating via ApproveItems → first item...")
            driver.get(f"{BASE_URL}/BuyerAction/ApproveItems")
            wait_ready(driver)
            time.sleep(PAUSE)
            links = _find_items(driver)
            if not links:
                pytest.skip("No items available in Approve Items List — test data may be depleted")
            driver.execute_script("arguments[0].click()", links[0])
            wait_ready(driver)
            time.sleep(PAUSE * 2)

        selected = _select_card_checkboxes(driver)
        assert selected > 0, "Could not select any card checkboxes"
        print(f"  [INFO] Total selected: {selected}")
        take_screenshot(driver, "06a_cards_selected", "reject")

        # Enter rejection comment on page BEFORE clicking Reject
        print("  [INFO] Looking for Notes textarea on Approve Cards page...")
        comment_entered = False
        notes_locators = [
            (By.XPATH, "//textarea[@id='Notes' or @name='Notes']"),
            (By.XPATH, "//textarea[contains(@id,'note') or contains(@name,'note') or contains(@id,'Note') or contains(@name,'Note')]"),
            (By.XPATH, "//textarea"),
            (By.XPATH, "//input[@type='text' and (contains(@id,'note') or contains(@id,'Note') or contains(@id,'comment') or contains(@id,'Comment'))]"),
        ]
        for notes_locator in notes_locators:
            try:
                notes_field = WebDriverWait(driver, 5).until(EC.visibility_of_element_located(notes_locator))
                scroll_to(driver, notes_field)
                notes_field.clear()
                notes_field.send_keys(REJECT_COMMENT)
                comment_entered = True
                print(f"  [INFO] Comment entered: '{REJECT_COMMENT}'")
                take_screenshot(driver, "06b_comment_entered", "reject")
                break
            except Exception:
                continue

        if not comment_entered:
            print("  [WARN] Notes textarea not found — continuing without pre-comment")

        # Click Reject button
        print("  [INFO] Clicking Reject button...")
        reject_btn = None
        reject_locators = [
            (By.ID, "btnRejectTop"), (By.ID, "btnRejectBot"),
            (By.XPATH, "//button[normalize-space(text())='Reject']"),
            (By.XPATH, "//a[normalize-space(text())='Reject']"),
            (By.XPATH, "//span[normalize-space(text())='Reject']"),
            (By.XPATH, "//input[@type='button' and contains(@value,'Reject')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Reject') and (self::button or self::a or self::span or self::input) and not(contains(normalize-space(),'Back'))]"),
        ]
        for locator in reject_locators:
            try:
                candidate = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
                btn_text = (candidate.text or candidate.get_attribute('value') or '').strip().lower()
                if btn_text not in ('back to items', 'back', ''):
                    reject_btn = candidate
                    break
            except Exception:
                continue

        assert reject_btn, "Reject button not found on Approve Cards List page"
        print(f"  [INFO] Found Reject button: '{reject_btn.text.strip() or reject_btn.get_attribute('value')}'")
        scroll_to(driver, reject_btn)
        driver.execute_script("arguments[0].click()", reject_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)
        take_screenshot(driver, "06c_after_reject_click", "reject")
        print(f"  [INFO] URL after Reject click: {driver.current_url}")

        # Verify RejectResults
        print("  [INFO] Waiting for RejectResults page...")
        try:
            WebDriverWait(driver, 15).until(lambda d: "RejectResult" in d.current_url)
            print(f"  [INFO] Landed on results page: {driver.current_url}")
        except Exception:
            print(f"  [INFO] Still on: {driver.current_url} — checking success text")

        take_screenshot(driver, "06d_reject_results", "reject")
        success_found = False
        res_locators = [
            (By.XPATH, "//*[contains(normalize-space(),'Following Cards were successful')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Card Successfully Rejected')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Reject Cards Results')]"),
            (By.XPATH, "//*[contains(normalize-space(),'successfully')]"),
        ]
        for locator in res_locators:
            try:
                el = WebDriverWait(driver, 8).until(EC.presence_of_element_located(locator))
                print(f"  [INFO] Success message: '{el.text.strip()[:120]}'")
                success_found = True
                break
            except Exception:
                continue

        assert "RejectResult" in driver.current_url or success_found, \
            f"Expected RejectResults with success message. URL: {driver.current_url} success_found={success_found}"
        print("  [PASS] Reject Cards Results page verified — cards successfully rejected.")

    # ── TC-REJ-007 ───────────────────────────────────────────────────────
    def test_07_back_to_items(self, driver):
        """Click Back to Items and verify return to Approve Items List."""
        print("\n[TC-REJ-007] Clicking Back to Items...")
        print(f"  [INFO] Currently on: {driver.current_url}")

        if not any(kw in driver.current_url for kw in ("ApproveCard", "ApproveResult", "RejectResult")):
            print("  [INFO] Re-navigating via ApproveItems → item click...")
            driver.get(f"{BASE_URL}/BuyerAction/ApproveItems")
            wait_ready(driver)
            time.sleep(PAUSE)
            links = _find_items(driver)
            if not links:
                pytest.skip("No items available in Approve Items List — test data may be depleted")
            driver.execute_script("arguments[0].click()", links[0])
            wait_ready(driver)
            time.sleep(PAUSE * 2)

        back_btn = _click_back_to_items(driver)
        assert back_btn, "Back to Items button not found"
        scroll_to(driver, back_btn)
        driver.execute_script("arguments[0].click()", back_btn)
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "07_back_to_items", "reject")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert any(kw in current_url for kw in ["ApproveItem", "Approve", "approve"]), \
            f"Expected Approve Items page after Back to Items. Got: {current_url}"
        print("  [PASS] Successfully returned to Approve Items List.")