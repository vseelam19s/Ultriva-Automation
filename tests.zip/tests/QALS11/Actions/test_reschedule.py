"""
QALS11 | Actions > Reschedule — End-to-End Reschedule Cards Flow
=================================================================
URL   : https://engineering.ultrivalms.com/QALS1011
User  : buyeruser / Ultriva!23

Test Flow
---------
  1.  Login as buyeruser
  2.  Navigate to Actions menu (left sidebar)
  3.  Click Reschedule from Buyer Actions page
  4.  On Reschedule Filter page — click Go to load Reschedule Items List
  5.  From Reschedule Items List — click first item → Show Cards
  6.  From Reschedule Cards List:
        a. Select first 2 cards via checkbox
        b. Enter New Required Receive Date
        c. Click Compute Ship Date
        d. Click Reschedule
  7.  Verify Reschedule Results page — "Following Cards were successful"
  8.  Click Back to Items — verify return to Reschedule Items List

Run (from qa_automation/):
    pytest tests/QALS11/Actions/test_reschedule.py -v -s
"""

import time
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os

# ============================================================================
# CONFIGURATION
# ============================================================================
BASE_URL = "https://engineering.ultrivalms.com/QALS1011"
USERNAME = "buyeruser"
PASSWORD = "Ultriva!23"
PAUSE = 1.5
NEW_RECEIVE_DATE = "07/01/2026"   # Future date for New Required Receive Date
TARGET_ITEM = "IT_Percent_292"  # Specific item to test

# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture(scope="class")
def driver():
    """Class-scoped Chrome driver — one browser session per test class."""
    options = webdriver.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-logging"])
    drv = webdriver.Chrome(options=options)
    drv.implicitly_wait(10)
    drv.set_page_load_timeout(30)
    drv.maximize_window()
    yield drv
    drv.quit()

# ============================================================================
# HELPERS
# ============================================================================

def wait_ready(driver, timeout=30):
    """Wait for document.readyState == complete."""
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )

def find(driver, by, locator, timeout=15):
    """Wait for presence and return element."""
    return WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((by, locator))
    )

def clickable(driver, by, locator, timeout=15):
    """Wait until clickable and return element."""
    return WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, locator))
    )

def scroll_to(driver, el):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'})", el)
    time.sleep(0.3)

def take_screenshot(driver, name):
    screenshots_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "..", "reports", "screenshots"
    )
    os.makedirs(screenshots_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(screenshots_dir, f"reschedule_{name}_{ts}.png")
    driver.save_screenshot(path)
    print(f"  [screenshot] {path}")
    return path

# ============================================================================
# TEST CLASS
# ============================================================================

@pytest.mark.usefixtures("driver")
class TestReschedule:
    
    # ── TC-RSC-001: Login ────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """Login to QA site with buyeruser credentials."""
        print("\n[TC-RSC-001] Logging in to QA site...")
        driver.get(BASE_URL)
        wait_ready(driver)

        username_field = find(driver, By.ID, "UserName")
        password_field = find(driver, By.ID, "Password")
        login_button = clickable(driver, By.ID, "login-button")

        username_field.clear()
        username_field.send_keys(USERNAME)
        password_field.clear()
        password_field.send_keys(PASSWORD)
        login_button.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "01_after_login")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert BASE_URL.lower() in current_url.lower() or "Home" in current_url, \
            f"Login may have failed. URL: {current_url}"
        print("  [PASS] Login successful.")

    # ── TC-RSC-002: Navigate to Actions ──────────────────────────────────
    def test_02_navigate_to_actions(self, driver):
        """Click Actions in the left sidebar to open the Buyer Actions page."""
        print("\n[TC-RSC-002] Navigating to Actions page...")

        actions_link = clickable(
            driver,
            By.XPATH,
            "//a[contains(@href, 'Action/Home') or "
            "(.//span[normalize-space()='Actions']) or "
            "normalize-space(.)='Actions']",
        )
        scroll_to(driver, actions_link)
        actions_link.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "02_actions_page")
        assert "Action/Home" in driver.current_url, \
            f"Expected Actions page. Got: {driver.current_url}"
        print(f"  [PASS] Actions page loaded: {driver.current_url}")

    # ── TC-RSC-003: Click Reschedule ─────────────────────────────────────
    def test_03_click_reschedule(self, driver):
        """Click the Reschedule tile from the Buyer Actions section."""
        print("\n[TC-RSC-003] Clicking Reschedule tile in Buyer Actions...")

        reschedule_link = None
        for locator in [
            (By.XPATH, "//a[contains(@href,'RescheduleFilter') and not(contains(@class,'toplinks'))]"),
            (By.XPATH, "//a[contains(@href,'Reschedule') and not(contains(@class,'toplinks')) "
                       "and not(contains(@href,'RescheduleItem')) "
                       "and not(contains(@href,'RescheduleCard'))]"),
            (By.XPATH, "//a[normalize-space(text())='Reschedule' and not(contains(@class,'toplinks'))]"),
            (By.XPATH, "//*[normalize-space(text())='Reschedule' and "
                       "(self::a or self::button or self::span) "
                       "and not(contains(@class,'toplinks'))]"),
        ]:
            try:
                reschedule_link = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert reschedule_link, "Reschedule link/tile not found on Actions page"
        scroll_to(driver, reschedule_link)
        driver.execute_script("arguments[0].click()", reschedule_link)
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "03_reschedule_filter")
        print(f"  [URL] {driver.current_url}")
        assert any(kw in driver.current_url for kw in ["Reschedule", "reschedule"]), \
            f"Expected Reschedule page. Got: {driver.current_url}"
        print(f"  [PASS] Reschedule filter/items page loaded: {driver.current_url}")

    # ── TC-RSC-004: Apply filter and load Reschedule Items List ──────────
    def test_04_apply_filter_and_load_items(self, driver):
        """Click Go on Reschedule Filter page to load the Reschedule Items List."""
        print("\n[TC-RSC-004] Applying filter — clicking Go button...")

        if "RescheduleItem" in driver.current_url:
            print("  [INFO] Already on Reschedule Items page, skipping Go click.")
        else:
            go_button = None
            for locator in [
                (By.XPATH, "//a[contains(@class,'btn-filter-submit-item') and contains(normalize-space(),'Go')]"),
                (By.XPATH, "//a[normalize-space(text())='Go' and contains(@class,'btn')]"),
                (By.XPATH, "//button[normalize-space(text())='Go']"),
                (By.XPATH, "//input[@type='submit' and @value='Go']"),
                (By.XPATH, "//*[@id='btnGo' or @id='go-button' or @id='goBtn']"),
                (By.XPATH, "//a[contains(normalize-space(),'Go')]"),
            ]:
                try:
                    go_button = WebDriverWait(driver, 5).until(
                        EC.element_to_be_clickable(locator)
                    )
                    break
                except Exception:
                    continue

            if go_button:
                scroll_to(driver, go_button)
                driver.execute_script("arguments[0].click()", go_button)
                wait_ready(driver)
                time.sleep(PAUSE * 2)
            else:
                print("  [WARN] Go button not found — attempting direct URL navigation...")
                driver.get(f"{BASE_URL}/BuyerAction/RescheduleItems")
                wait_ready(driver)
                time.sleep(PAUSE * 2)

        take_screenshot(driver, "04_reschedule_items_list")
        assert "Reschedule" in driver.current_url, \
            f"Expected Reschedule Items page. Got: {driver.current_url}"
        print(f"  [PASS] Reschedule Items List loaded: {driver.current_url}")

    # ── TC-RSC-005: Select item and click Show Cards ─────────────────────
    def test_05_select_item_show_cards(self, driver):
        """Find item IT_Percent_292 in the Reschedule Items List and click Show Cards."""
        print(f"\n[TC-RSC-005] Selecting item '{TARGET_ITEM}' and clicking Show Cards...")

        # Wait for all GridLink items to load
        item_links = WebDriverWait(driver, 20).until(
            EC.presence_of_all_elements_located((By.XPATH, "//a[contains(@class,'GridLink')]"))
        )
        assert item_links, "No items found in Reschedule Items List"

        # Search for the target item across all pages (try current page first)
        target_link = None
        for link in item_links:
            if link.text.strip() == TARGET_ITEM:
                target_link = link
                break

        # If not on current page, use Find Item search box
        if not target_link:
            print(f"  [INFO] '{TARGET_ITEM}' not on current page — using Find Item search...")
            try:
                find_box = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located(
                        (By.XPATH, "//input[@placeholder='Find Item' or contains(@id,'findItem') "
                                   "or contains(@id,'FindItem') or contains(@id,'search')]")
                    )
                )
                find_box.clear()
                find_box.send_keys(TARGET_ITEM)
                time.sleep(1)
                
                # Click search/find icon
                for loc in [
                    (By.XPATH, "//input[@placeholder='Find Item']/following-sibling::a"),
                    (By.XPATH, "//input[@placeholder='Find Item']/..//a"),
                    (By.XPATH, "//a[contains(@onclick,'findItem') or contains(@onclick,'FindItem')]"),
                ]:
                    try:
                        btn = driver.find_element(*loc)
                        driver.execute_script("arguments[0].click()", btn)
                        break
                    except Exception:
                        continue
                
                time.sleep(1.5)
                # Re-fetch links after search
                item_links = driver.find_elements(By.XPATH, "//a[contains(@class,'GridLink')]")
                for link in item_links:
                    if link.text.strip() == TARGET_ITEM:
                        target_link = link
                        break
            except Exception as e:
                print(f"  [WARN] Find Item search failed: {e}")

        assert target_link, f"Item '{TARGET_ITEM}' not found in Reschedule Items List"
        item_text = target_link.text.strip()
        print(f"  [INFO] Item found: '{item_text}'")

        scroll_to(driver, target_link)
        driver.execute_script("arguments[0].click()", target_link)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "05a_after_item_click")
        print(f"  [INFO] URL after item click: {driver.current_url}")

        # If navigated directly to RescheduleCards, done
        if "RescheduleCard" in driver.current_url:
            print("  [INFO] Navigated directly to Reschedule Cards page.")
            return

        # Fallback: look for Show Cards button on items page
        show_cards_btn = None
        for locator in [
            (By.XPATH, "//button[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//input[@value='Show Cards']"),
            (By.XPATH, "//*[contains(@id,'ShowCards') or contains(@id,'showCards')]"),
            (By.XPATH, "//*[normalize-space(text())='Show Cards']"),
        ]:
            try:
                show_cards_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert show_cards_btn, "Show Cards button not found and not on Reschedule Cards page"
        scroll_to(driver, show_cards_btn)
        driver.execute_script("arguments[0].click()", show_cards_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "05b_reschedule_cards_list")
        assert "RescheduleCard" in driver.current_url or "Reschedule" in driver.current_url, \
            f"Expected Reschedule Cards page. Got: {driver.current_url}"
        print(f"  [PASS] Reschedule Cards List loaded: {driver.current_url}")

    # ── TC-RSC-006: Select cards and enter New Reqd Receive Date ─────────
    def test_06_select_cards_and_enter_date(self, driver):
        """Select first 2 cards by checkbox and enter New Required Receive Date."""
        print("\n[TC-RSC-006] Selecting cards and entering New Required Receive Date...")

        # Wait for checkboxes in card rows
        checkboxes = WebDriverWait(driver, 20).until(
            EC.presence_of_all_elements_located(
                (By.XPATH, "//table//tr[td]//input[@type='checkbox'] | //input[@type='checkbox'][not(ancestor::th)]")
            )
        )
        assert checkboxes, "No checkboxes found in Reschedule Cards List"

        # Select up to 2 cards
        selected = 0
        for chk in checkboxes[:2]:
            try:
                scroll_to(driver, chk)
                if not chk.is_selected():
                    driver.execute_script("arguments[0].click()", chk)
                    time.sleep(0.4)
                    selected += 1
            except Exception as e:
                print(f"  [WARN] Could not click checkbox: {e}")

        assert selected > 0, "Could not select any cards"
        print(f"  [INFO] Selected {selected} card(s)")
        take_screenshot(driver, "06a_cards_selected")

        # Enter New Required Receive Date in the header date field
        date_field = None
        for locator in [
            (By.XPATH, "//input[contains(@id,'NewReqdReceiveDate') or contains(@name,'NewReqdReceiveDate')]"),
            (By.XPATH, "//input[contains(@id,'newReqdReceive') or contains(@name,'newReqdReceive')]"),
            (By.XPATH, "//input[contains(@placeholder,'Receive') or contains(@placeholder,'receive')]"),
            (By.XPATH, "//label[contains(normalize-space(),'New Required Receive')]/following-sibling::input | "
                       "//label[contains(normalize-space(),'New Required Receive')]/..//input[@type='text']"),
            (By.XPATH, "(//input[@type='text' and contains(@class,'date')])[1]"),
            (By.XPATH, "(//input[@type='text'])[1]"),
        ]:
            try:
                date_field = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located(locator)
                )
                break
            except Exception:
                continue

        if date_field:
            scroll_to(driver, date_field)
            driver.execute_script("arguments[0].value = '';", date_field)
            date_field.clear()
            date_field.send_keys(NEW_RECEIVE_DATE)
            time.sleep(0.5)
            # Close any datepicker popup by clicking elsewhere
            driver.execute_script("document.body.click()")
            time.sleep(0.5)
            print(f"  [INFO] New Required Receive Date entered: {NEW_RECEIVE_DATE}")
        else:
            print("  [WARN] Date input field not found — skipping date entry")

        take_screenshot(driver, "06b_date_entered")
        print("  [PASS] Cards selected and date entered.")

    # ── TC-RSC-007: Compute Ship Date ────────────────────────────────────
    def test_07_compute_ship_date(self, driver):
        """Click Compute Ship Date to calculate ship dates for selected cards."""
        print("\n[TC-RSC-007] Clicking Compute Ship Date...")

        compute_btn = None
        for locator in [
            (By.XPATH, "//button[contains(normalize-space(),'Compute Ship Date')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Compute Ship Date')]"),
            (By.XPATH, "//input[@value='Compute Ship Date']"),
            (By.XPATH, "//*[contains(@id,'ComputeShip') or contains(@id,'computeShip')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Compute Ship')]"),
        ]:
            try:
                compute_btn = WebDriverWait(driver, 8).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        if compute_btn:
            scroll_to(driver, compute_btn)
            driver.execute_script("arguments[0].click()", compute_btn)
            wait_ready(driver)
            time.sleep(PAUSE * 2)
            take_screenshot(driver, "07_after_compute_ship_date")
            print("  [PASS] Compute Ship Date clicked successfully.")
        else:
            print("  [WARN] Compute Ship Date button not found — skipping.")
            take_screenshot(driver, "07_compute_ship_date_not_found")

    # ── TC-RSC-008: Click Reschedule ─────────────────────────────────────
    def test_08_click_reschedule_button(self, driver):
        """Click the Reschedule button to submit the reschedule action."""
        print("\n[TC-RSC-008] Clicking Reschedule button...")

        reschedule_btn = None
        for locator in [
            (By.XPATH, "//button[normalize-space(text())='Reschedule']"),
            (By.XPATH, "//button[contains(@class,'reschedule') and contains(normalize-space(),'Reschedule')]"),
            (By.XPATH, "//a[normalize-space(text())='Reschedule']"),
            (By.XPATH, "//*[@id='btnReschedule' or contains(@id,'reschedule') or contains(@id,'Reschedule')]"),
            (By.XPATH, "//button[contains(normalize-space(),'Reschedule')]"),
            (By.XPATH, "//input[@value='Reschedule']"),
        ]:
            try:
                reschedule_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert reschedule_btn, "Reschedule button not found in cards list"
        scroll_to(driver, reschedule_btn)
        driver.execute_script("arguments[0].click()", reschedule_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "08_reschedule_submitted")
        print(f"  [URL] {driver.current_url}")
        print("  [PASS] Reschedule button clicked.")

    # ── TC-RSC-009: Verify Reschedule Results ────────────────────────────
    def test_09_verify_reschedule_results(self, driver):
        """Verify the Reschedule Results page shows cards successfully rescheduled."""
        print("\n[TC-RSC-009] Verifying Reschedule Results page...")

        current_url = driver.current_url
        print(f"  [URL] {current_url}")

        success_found = False
        for locator in [
            (By.XPATH, "//*[contains(normalize-space(),'Following Cards were successful')]"),
            (By.XPATH, "//*[contains(normalize-space(),'successful')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Successfully Rescheduled')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Rescheduled')]"),
            (By.XPATH, "//h1[contains(normalize-space(),'Result')] | //h2[contains(normalize-space(),'Result')]"),
        ]:
            try:
                el = WebDriverWait(driver, 8).until(
                    EC.presence_of_element_located(locator)
                )
                msg = el.text.strip()
                print(f"  [INFO] Result message found: '{msg[:120]}'")
                success_found = True
                break
            except Exception:
                continue

        take_screenshot(driver, "09_reschedule_results")

        assert "RescheduleResult" in current_url or "Reschedule" in current_url, \
            f"Not on expected Reschedule Results/Cards page. URL: {current_url}"

        if not success_found:
            print("  [WARN] Success message not found by text, but URL confirms Reschedule page.")

        print("  [PASS] Reschedule Results page verified.")

    # ── TC-RSC-010: Click Back to Items ──────────────────────────────────
    def test_10_back_to_items(self, driver):
        """Click Back to Items and verify return to Reschedule Items List."""
        print("\n[TC-RSC-010] Clicking Back to Items...")

        back_btn = None
        for locator in [
            (By.XPATH, "//button[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.XPATH, "//*[contains(@id,'btnBack') or contains(@id,'backToItems') or contains(@id,'BackToItems')]"),
            (By.ID, "btnBackPageTop"),
            (By.ID, "btnBackPageBot"),
        ]:
            try:
                back_btn = WebDriverWait(driver, 8).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        if not back_btn:
            print("  [INFO] Back to Items not found on results page — navigating to RescheduleItems...")
            driver.get(f"{BASE_URL}/BuyerAction/RescheduleItems")
            wait_ready(driver)
            time.sleep(PAUSE * 2)
        else:
            scroll_to(driver, back_btn)
            driver.execute_script("arguments[0].click()", back_btn)
            wait_ready(driver)
            time.sleep(PAUSE * 2)

        take_screenshot(driver, "10_back_to_items")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert "RescheduleItem" in current_url or "Reschedule" in current_url, \
            f"Expected Reschedule Items List. Got: {current_url}"
        print("  [PASS] Returned to Reschedule Items List.")