"""
QALS11 | Admin > Item — New Item Creation, Filter & Adjust Loop Size
=====================================================================
URL  : https://engineering.ultrivalms.com/QALS1011
User : buyeruser / Ultriva!23

Data source (Excel-driven classes)
-----------------------------------
  qa_automation/test_data/item_test_data_1.xlsx  (sheet: ItemData)
  Columns used: Item_No, Description, Category, Item_Coord, Landing_Time,
                Price_Per_UOM, Usage_Per_Day, Safety_Stock, Pallet_Qty,
                Ship_Tol, Receive_Tol, Supplier, Supplier_User,
                Supplier_Item_No, Supplier_Desc, Min_Order_Qty,
                Lead_Time, Transit_Time, Cards_To_Add, Run_Adjust_Loop

Test Classes
------------
  TestCreateItemsData1        — create items from item_test_data_1.xlsx
  TestFilterItemsData1        — clear filter, filter by each new item
  TestCreateItem              — create IT010426
  TestCreateItem2             — create IT020426
  TestCreateItem3             — create IT070426
  TestInitialLoopSize         — set initial loop size for IT020426
  TestAdjustLoopSize          — adjust loop size for IT020426
  TestExcelItemInitialLoop    — initial loop size for IT-A140426 (Excel)
  TestExcelItemAdjustLoop     — adjust loop size for IT-A140426 (Excel)
  TestITTest232Create         — create ITTest232 (Kanban)
  TestITTest232InitialLoop    — initial loop size for ITTest232
  TestITTest232AdjustLoop     — adjust loop size for ITTest232
  ─────────────────────────────────────────────────────────────────────
  TestCreateItemITDDDD        — NEW ▸ create ITDDDD + initial loop + adjust loop
  TestExcelCreateAndAdjustLoop— NEW ▸ Excel rows (Run_Adjust_Loop=Yes):
                                       create item + initial loop + adjust loop

━━━  FOCUSED RUN COMMANDS (don't run all classes)  ━━━━━━━━━━━━━━━━━━━

  # Create ITDDDD + adjust loop size only:
  cd qa_automation
  pytest tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestCreateItemITDDDD -v --html=reports/ITDDDD_report.html

  # Excel-driven create + adjust loop (Run_Adjust_Loop=Yes rows):
  pytest tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestExcelCreateAndAdjustLoop -v --html=reports/excel_loop_report.html

  # Both new classes together (single browser, faster):
  pytest tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestCreateItemITDDDD tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestExcelCreateAndAdjustLoop -v --html=reports/new_items_report.html

  # Run all classes (slow):
  pytest NewItemCreationandAdjustLoopSize.py -v
"""

import os
import time
import random
import pytest
from collections import namedtuple
from openpyxl import load_workbook
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select as SeleniumSelect


# ══════════════════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════

BASE_URL = "https://engineering.ultrivalms.com/QALS1011"
USERNAME = "buyeruser"
PASSWORD = "Ultriva!23"
PAUSE = 2

SUPPLIER = "supnew"
SUPPLIER_USER = "supnewuser"
LEAD_TIME = "3"
TRANSIT_TIME = "1"
MIN_ORDER_QTY = "1"

ITEM_COORD = "buyeruser"
LANDING_TIME = "5"
PRICE_PER_UOM = "10"
USAGE_PER_DAY = "2"
SAFETY_STOCK = "1"
PALLET_QTY = "50"
SHIP_TOL = "100"
RECEIVE_TOL = "100"

ITEMS = {
    "IT010426": {
        "desc": "Test Item April 2026",
        "supplier_code": "SUP-IT010426",
        "supplier_desc": "Test Supplier Item",
    },
    "IT020426": {
        "desc": "Test Item 02 April 2026",
        "supplier_code": "SUP-IT020426",
        "supplier_desc": "Test Supplier Item 02",
    },
    "IT070426": {
        "desc": "Test Item 07 April 2026",
        "supplier_code": "SUP-IT070426",
        "supplier_desc": "Test Supplier Item 07",
    },
    "IT140426-3": {
        "desc": "Test Item 14 April 2026 Kanban",
        "supplier_code": "SUP-IT140426-3",
        "supplier_desc": "Test Supplier Item 14",
        "category": "Kanban",
    },
    "ITTest232": {
        "desc": "Test Item ITTest232 Kanban",
        "supplier_code": "SUP-ITTest232",
        "supplier_desc": "Test Supplier ITTest232",
        "category": "Kanban",
    },
    "ITDDDD": {
        "desc": "Test Item ITDDDD",
        "supplier_code": "SUP-ITDDDD",
        "supplier_desc": "Test Supplier ITDDDD",
    },
    "IT190426": {
        "desc": "Test Item 19 April 2026",
        "supplier_code": "SUP-IT190426",
        "supplier_desc": "Test Supplier Item 19",
    },
}

LOOP_ITEM_NO = "IT020426"
CARDS_TO_ADD = "12"
EXCEL_LOOP_ITEM = "IT-A140426"   # Excel item with Run_Adjust_Loop = Yes
ITTEST232_ITEM = "ITTest232"
ITTEST232_CARDS = "12"

# ── ITDDDD constants ────────────────────────────────────────────────────
ITDDDD_ITEM = "ITDDDD"
ITDDDD_CARDS = "12"
ITDDDD_UNITS_HAND = "20"
ITDDDD_UNITS_ORD = "5"

EXCEL_PATH = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        "..", "..", "..", "..",
        "test_data",
        "item_test_data_1.xlsx",
    )
)


# ══════════════════════════════════════════════════════════════════════════════
#  EXCEL DATA LOADER
# ══════════════════════════════════════════════════════════════════════════════

def load_items():
    wb = load_workbook(EXCEL_PATH, read_only=True, data_only=True)
    ws = wb["ItemData"]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if len(rows) < 2:
        raise ValueError(f"No data rows in '{EXCEL_PATH}'")
    headers = [
        str(h).strip().replace(" ", "_").replace("/", "_")
        for h in rows[0]
    ]
    ItemRow = namedtuple("ItemRow", headers)
    return [ItemRow(*r) for r in rows[1:] if r[0]]


# ══════════════════════════════════════════════════════════════════════════════
#  SHARED HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def wait_ready(driver):
    WebDriverWait(driver, 30).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )


def wait_overlay(driver):
    try:
        WebDriverWait(driver, 10).until(
            EC.invisibility_of_element_located((By.ID, "fancy_overlay"))
        )
    except Exception:
        pass


def scroll_to(driver, el):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'})", el)
    time.sleep(0.3)


def click(driver, by, loc, timeout=15):
    wait_overlay(driver)
    el = WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, loc))
    )
    scroll_to(driver, el)
    try:
        el.click()
    except Exception:
        driver.execute_script("arguments[0].click()", el)
    time.sleep(0.5)


def js_click(driver, by, loc, timeout=15):
    wait_overlay(driver)
    el = WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((by, loc))
    )
    scroll_to(driver, el)
    driver.execute_script("arguments[0].click()", el)
    time.sleep(0.5)


def fill(driver, field_id, value):
    el = WebDriverWait(driver, 15).until(
        EC.visibility_of_element_located((By.ID, field_id))
    )
    scroll_to(driver, el)
    try:
        el.clear()
        el.send_keys(str(value))
    except Exception:
        driver.execute_script(
            "arguments[0].value = arguments[1]", el, str(value))


def autocomplete(driver, field_id, value):
    el = WebDriverWait(driver, 15).until(
        EC.visibility_of_element_located((By.ID, field_id))
    )
    scroll_to(driver, el)
    el.clear()
    el.send_keys(str(value))
    time.sleep(2)
    try:
        suggestion = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//ul[contains(@class,'ui-autocomplete')"
                "  and @style[not(contains(.,'display: none'))]]"
                f"//li[contains(normalize-space(.),'{value}')]"
            ))
        )
        scroll_to(driver, suggestion)
        suggestion.click()
        time.sleep(1)
        return
    except Exception:
        pass
    el.send_keys(Keys.DOWN)
    time.sleep(0.5)
    el.send_keys(Keys.ENTER)
    time.sleep(1)


def select_category(driver, category):
    cat = str(category).strip()
    if not cat:
        return
    try:
        sel_el = WebDriverWait(driver, 8).until(
            EC.presence_of_element_located((By.ID, "ITM_CategoryCode"))
        )
        scroll_to(driver, sel_el)
        sel = SeleniumSelect(sel_el)
        try:
            sel.select_by_visible_text(cat)
        except Exception:
            sel.select_by_value(cat.upper())
        time.sleep(0.5)
    except Exception:
        pass


def banner(title, char="═", width=70):
    bar = char * width
    print(f"\n{bar}\n  {title}\n{bar}")


def row_out(label, value, width=28):
    print(f"  {label:<{width}} : {value}")


# ══════════════════════════════════════════════════════════════════════════════
#  NAVIGATION / STEP HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def step_login(driver):
    driver.get(BASE_URL)
    wait_ready(driver)
    fill(driver, "UserName", USERNAME)
    fill(driver, "Password", PASSWORD)
    click(driver, By.ID, "login-button")
    wait_ready(driver)
    time.sleep(PAUSE)
    assert "ultrivalms" in driver.current_url, \
        f"Login failed — URL: {driver.current_url}"
    print(f"\n  Logged in as '{USERNAME}' → {driver.current_url}")


def step_open_admin(driver):
    click(driver, By.XPATH,
          "//a[contains(@href,'/Admin/Home') or normalize-space(.)='Admin']")
    wait_ready(driver)
    time.sleep(PAUSE)
    print(f"  Admin module → {driver.current_url}")


def step_open_item_list(driver):
    try:
        click(driver, By.XPATH,
              "//a[contains(@href,'KanbanItem') or normalize-space(.)='Item'"
              " or normalize-space(.)='Items']")
    except Exception:
        driver.get(f"{BASE_URL}/KanbanItem/List")
    wait_ready(driver)
    time.sleep(PAUSE)
    print(f"  Items list → {driver.current_url}")


def step_click_add(driver):
    try:
        click(
            driver,
            By.XPATH,
            "//a[normalize-space(.)='Add' or contains(@href,'KanbanItem/Create')]")
    except Exception:
        driver.get(f"{BASE_URL}/KanbanItem/Create")
    wait_ready(driver)
    time.sleep(PAUSE)
    assert "KanbanItem" in driver.current_url, \
        f"New Item form not reached — URL: {driver.current_url}"
    print(f"  New Item form → {driver.current_url}")


def step_fill_base_info(driver, item_no):
    data = ITEMS[item_no]
    fill(driver, "ITM_ItemNo", item_no)
    fill(driver, "ITM_Description", data["desc"])
    fill(driver, "MISC_PlantHandlingTime", LANDING_TIME)
    fill(driver, "ITM_PricePerUOM", PRICE_PER_UOM)
    autocomplete(driver, "MISC_BuyerUser", ITEM_COORD)
    fill(driver, "ITM_UsagePerDay", USAGE_PER_DAY)
    fill(driver, "ITM_SafetyStock", SAFETY_STOCK)
    fill(driver, "ITM_PalletQty", PALLET_QTY)
    fill(driver, "ITM_ShipQtyTol", SHIP_TOL)
    fill(driver, "ITM_ReceiveQtyTol", RECEIVE_TOL)
    time.sleep(PAUSE)
    print(f"  Base Information filled — Item No: {item_no}")


def step_fill_supplier_tab(
        driver,
        item_no,
        supplier_code=None,
        supplier_desc=None):
    data = ITEMS[item_no]
    click(
        driver,
        By.XPATH,
        "//div[contains(@class,'tab-control-item') and contains(.,'Supplier')]"
        " | //span[contains(@class,'tab-control-item-txt') and normalize-space(.)='Supplier']")
    time.sleep(PAUSE)

    autocomplete(driver, "MISC_Supplier", SUPPLIER)
    supplier_gid = driver.find_element(
        By.ID, "I2S_SupplierGID").get_attribute("value")
    assert supplier_gid, "Supplier GID not populated"

    fill(driver, "I2S_SupplierItemCode",
         supplier_code or data["supplier_code"])
    fill(driver, "I2S_SupplierItemDesc",
         supplier_desc or data["supplier_desc"])
    fill(driver, "I2S_MinOrderQty", MIN_ORDER_QTY)

    autocomplete(driver, "MISC_SupplierUser", SUPPLIER_USER)
    user_gid = driver.find_element(
        By.ID, "I2S_SupplierUserGID").get_attribute("value")
    assert user_gid, "Supplier User GID not populated"

    fill(driver, "MISC_LeadTime", LEAD_TIME)
    fill(driver, "MISC_TransitTime", TRANSIT_TIME)
    time.sleep(PAUSE)
    print(f"  Supplier tab filled — {SUPPLIER} (GID:{supplier_gid})")


def step_save_item(driver, item_no):
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight)")
    time.sleep(1)
    click(driver, By.ID, "entryPGSubmit")
    wait_ready(driver)
    time.sleep(3)
    url = driver.current_url
    saved = (
        "KanbanItem/List" in url or "KanbanItem/Edit" in url
        or "PageFlow/List" in url or item_no in driver.page_source
    )
    assert saved, f"Save may have failed for '{item_no}' — URL: {url}"
    print(f"  Item '{item_no}' saved → {url}")


def step_verify_in_list(driver, item_no):
    driver.get(f"{BASE_URL}/KanbanItem/List")
    wait_ready(driver)
    time.sleep(PAUSE)
    # Apply filter so the item is visible regardless of pagination
    try:
        filter_input = WebDriverWait(driver, 8).until(
            EC.presence_of_element_located((By.ID, "drp"))
        )
        driver.execute_script("arguments[0].value = ''", filter_input)
        filter_input.send_keys(item_no)
        time.sleep(0.4)
        try:
            go_btn = driver.find_element(
                By.XPATH, "//a[normalize-space(.)='Go']")
            driver.execute_script("arguments[0].click()", go_btn)
        except Exception:
            driver.execute_script("if(typeof sr === 'function') sr();")
        wait_ready(driver)
        time.sleep(PAUSE)
    except Exception:
        pass  # filter not available; proceed with full list
    assert item_no in driver.page_source, \
        f"Item '{item_no}' NOT found in Items list"

    item_cell = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((
            By.XPATH, f"//td[normalize-space(.)='{item_no}']"
        ))
    )
    all_tds = item_cell.find_element(
        By.XPATH, "..").find_elements(
        By.TAG_NAME, "td")
    start = next((i for i, td in enumerate(all_tds)
                 if td.text.strip() == item_no), 0)
    cells = all_tds[start: start + 10]
    col_labels = [
        "Item No",
        "Description",
        "Price Per UOM",
        "Supplier",
        "Supplier Item No",
        "Lead Time",
        "Cards",
        "Status",
        "Category",
        "Other",
    ]
    banner(f"CREATED ITEM — {item_no}")
    for i, cell in enumerate(cells):
        val = cell.text.strip()
        if val:
            row_out(col_labels[i] if i < len(col_labels) else f"Col {i}", val)
    print(f"  PASS — Item '{item_no}' verified in Items list")


def step_select_item_row(driver, item_no):
    wait_overlay(driver)
    # Apply filter so the item is visible regardless of pagination
    try:
        filter_input = WebDriverWait(driver, 8).until(
            EC.presence_of_element_located((By.ID, "drp"))
        )
        driver.execute_script("arguments[0].value = ''", filter_input)
        filter_input.send_keys(item_no)
        time.sleep(0.4)
        try:
            go_btn = driver.find_element(
                By.XPATH, "//a[normalize-space(.)='Go']")
            driver.execute_script("arguments[0].click()", go_btn)
        except Exception:
            driver.execute_script("if(typeof sr === 'function') sr();")
        wait_ready(driver)
        time.sleep(PAUSE)
    except Exception:
        pass  # filter not available; proceed with full list
    row = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((
            By.XPATH,
            f"//td[normalize-space(.)='{item_no}'] | //a[normalize-space(.)='{item_no}']"
        ))
    )
    scroll_to(driver, row)
    driver.execute_script("arguments[0].click()", row)
    time.sleep(PAUSE)
    print(f"  Item '{item_no}' selected")


def step_click_cards_button(driver):
    wait_overlay(driver)
    try:
        el = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "Item_tbrCards"))
        )
    except Exception:
        el = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                "//a[normalize-space(.)='Cards'] | //button[normalize-space(.)='Cards']"
            ))
        )
    scroll_to(driver, el)
    wait_overlay(driver)
    driver.execute_script("arguments[0].click()", el)
    wait_ready(driver)
    time.sleep(PAUSE)
    print(f"  Cards list → {driver.current_url}")


def step_set_initial_loop_size(driver, item_no, units_on_hand, units_on_order):
    """Click 'Add Cards' and complete the loop-size wizard (initial setup)."""
    wait_overlay(driver)
    el = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.XPATH, "//*[@title='Add Cards']"))
    )
    scroll_to(driver, el)
    driver.execute_script("arguments[0].click()", el)
    wait_ready(driver)
    time.sleep(1)
    fill(driver, "WIZARD_UnitsOnHand", units_on_hand)
    fill(driver, "WIZARD_UnitsOnOrder", units_on_order)
    time.sleep(0.5)
    js_click(driver, By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
    wait_ready(driver)
    time.sleep(1)
    banner(f"INITIAL LOOP SIZE — {item_no}")
    row_out("Units On Hand", units_on_hand)
    row_out("Units On Order", units_on_order)
    for _ in range(10):
        finish = driver.find_elements(
            By.XPATH, "//*[@id='wizFinishBtn' or @title='Finish' or @title='Done'"
            " or (self::button and normalize-space(.)='Finish')]")
        if finish:
            driver.execute_script("arguments[0].click()", finish[0])
            wait_ready(driver)
            time.sleep(1)
            print(f"  Finish clicked → {driver.current_url}")
            break
        nxt = driver.find_elements(
            By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
        if nxt:
            driver.execute_script("arguments[0].click()", nxt[0])
            wait_ready(driver)
            time.sleep(1)
        else:
            break
    assert "ultrivalms" in driver.current_url
    banner(f"PASS — Initial Loop Size set for {item_no}", char="─")


def step_adjust_loop_size(driver, item_no, cards_to_add):
    """Open 'Adjust LoopSize' wizard and add replenishment cards."""
    wait_overlay(driver)
    el = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "ItemCard_tbrAdd"))
    )
    scroll_to(driver, el)
    driver.execute_script("arguments[0].click()", el)
    wait_ready(driver)
    time.sleep(1)
    assert "EboLoopsizeWizard" in driver.current_url, \
        f"Adjust LoopSize wizard not reached — URL: {driver.current_url}"
    print(f"  Adjust LoopSize wizard → {driver.current_url}")

    radio = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.ID, "WIZARD$CardOperation1"))
    )
    driver.execute_script("arguments[0].click()", radio)
    time.sleep(0.5)
    assert radio.is_selected(), "'Add Replenishment Cards' radio was not selected"
    js_click(driver, By.ID, "wizNextBtn")
    wait_ready(driver)
    time.sleep(1)

    el = WebDriverWait(driver, 15).until(
        EC.visibility_of_element_located((By.ID, "WIZARD_RCardsToAdd"))
    )
    scroll_to(driver, el)
    driver.execute_script("arguments[0].removeAttribute('readonly')", el)
    driver.execute_script(f"arguments[0].value = '{cards_to_add}'", el)
    el.send_keys(" \b")
    time.sleep(0.5)

    release_radio = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.ID, "WIZARD$LoopsizeAction1"))
    )
    driver.execute_script("arguments[0].click()", release_radio)
    time.sleep(0.5)
    assert release_radio.is_selected(), "'Release to Supplier' radio was not selected"

    banner(f"ADJUST LOOP SIZE — {item_no}")
    row_out("Cards to Add", cards_to_add)
    row_out("Action", "Release to Supplier")

    finish = driver.find_elements(By.ID, "wizFinishBtn")
    if finish:
        driver.execute_script("arguments[0].click()", finish[0])
    else:
        js_click(driver, By.ID, "wizNextBtn")
    wait_ready(driver)
    time.sleep(1)
    for _ in range(5):
        fin = driver.find_elements(By.ID, "wizFinishBtn")
        if fin:
            driver.execute_script("arguments[0].click()", fin[0])
            wait_ready(driver)
            time.sleep(1)
            print(f"  Finish clicked → {driver.current_url}")
            break
        nxt = driver.find_elements(By.ID, "wizNextBtn")
        if nxt:
            driver.execute_script("arguments[0].click()", nxt[0])
            wait_ready(driver)
            time.sleep(1)
        else:
            break
    assert "ultrivalms" in driver.current_url
    banner(f"PASS — Loop Size adjusted for {item_no}", char="─")


# ══════════════════════════════════════════════════════════════════════════════
#  EXCEL-DRIVEN ITEM CREATE  (for item_test_data_1.xlsx rows)
# ══════════════════════════════════════════════════════════════════════════════

def create_item_from_row(driver, item):
    banner(f"Creating Item: {item.Item_No}  [{item.Category}]")
    row_out("Description", item.Description)
    row_out("Supplier", item.Supplier)

    fill(driver, "ITM_ItemNo", item.Item_No)
    fill(driver, "ITM_Description", item.Description)
    fill(driver, "MISC_PlantHandlingTime", item.Landing_Time)
    fill(driver, "ITM_PricePerUOM", item.Price_Per_UOM)
    autocomplete(driver, "MISC_BuyerUser", item.Item_Coord)
    select_category(driver, item.Category)
    fill(driver, "ITM_UsagePerDay", item.Usage_Per_Day)
    fill(driver, "ITM_SafetyStock", item.Safety_Stock)
    fill(driver, "ITM_PalletQty", item.Pallet_Qty)
    fill(driver, "ITM_ShipQtyTol", item.Ship_Tol)
    fill(driver, "ITM_ReceiveQtyTol", item.Receive_Tol)
    time.sleep(PAUSE)
    print(f"  Base Information filled")

    click(
        driver,
        By.XPATH,
        "//div[contains(@class,'tab-control-item') and contains(.,'Supplier')]"
        " | //span[contains(@class,'tab-control-item-txt') and normalize-space(.)='Supplier']")
    time.sleep(PAUSE)

    autocomplete(driver, "MISC_Supplier", item.Supplier)
    supplier_gid = driver.find_element(
        By.ID, "I2S_SupplierGID").get_attribute("value")
    assert supplier_gid, f"Supplier GID missing for '{item.Item_No}'"

    fill(driver, "I2S_SupplierItemCode", item.Supplier_Item_No)
    fill(driver, "I2S_SupplierItemDesc", item.Supplier_Desc)
    fill(driver, "I2S_MinOrderQty", item.Min_Order_Qty)

    autocomplete(driver, "MISC_SupplierUser", item.Supplier_User)
    user_gid = driver.find_element(
        By.ID, "I2S_SupplierUserGID").get_attribute("value")
    assert user_gid, f"Supplier User GID missing for '{item.Item_No}'"

    fill(driver, "MISC_LeadTime", item.Lead_Time)
    fill(driver, "MISC_TransitTime", item.Transit_Time)
    time.sleep(PAUSE)
    print(f"  Supplier tab filled — GID:{supplier_gid}")

    step_save_item(driver, item.Item_No)


# ══════════════════════════════════════════════════════════════════════════════
#  FILTER HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def clear_items_list_filter(driver):
    driver.get(f"{BASE_URL}/KanbanItem/List")
    wait_ready(driver)
    time.sleep(PAUSE)

    cleared = False
    for locator in [
        (By.XPATH, "//a[normalize-space(.)='Clear Filter' or normalize-space(.)='Clear'"
                   " or normalize-space(.)='Reset' or normalize-space(.)='Show All']"),
        (By.XPATH, "//button[normalize-space(.)='Clear Filter' or normalize-space(.)='Reset']"),
        (By.XPATH, "//*[@title='Clear Filter' or @title='Reset' or @title='Show All']"),
        (By.ID, "btnClearFilter"),
        (By.ID, "btnReset"),
    ]:
        btns = driver.find_elements(*locator)
        if btns:
            scroll_to(driver, btns[0])
            driver.execute_script("arguments[0].click()", btns[0])
            wait_ready(driver)
            time.sleep(PAUSE)
            cleared = True
            print(f"  Filter cleared via button")
            break

    if not cleared:
        driver.get(f"{BASE_URL}/KanbanItem/List")
        wait_ready(driver)
        time.sleep(PAUSE)
        print(f"  Filter cleared via URL reload")


def filter_items_by_item_no(driver, item_no):
    banner(f"FILTER — Item No: {item_no}")

    filter_input = None
    for locator in [
        (By.XPATH, "//input[@placeholder='Item No' or @placeholder='Search Item No'"
                   " or @placeholder='Filter']"),
        (By.XPATH, "//input[contains(@id,'ITM_ItemNo') or contains(@id,'ItemNo')]"),
        (By.XPATH, "//th[contains(normalize-space(.),'Item No')]//input"),
        (By.XPATH, "//input[contains(@class,'filter-input') or contains(@class,'grid-filter')]"),
    ]:
        els = driver.find_elements(*locator)
        if els:
            filter_input = els[0]
            break

    if filter_input:
        scroll_to(driver, filter_input)
        filter_input.clear()
        filter_input.send_keys(item_no)
        time.sleep(1)
        filter_input.send_keys(Keys.ENTER)
        wait_ready(driver)
        time.sleep(PAUSE)
        print(f"  Typed '{item_no}' into filter input")
    else:
        driver.get(f"{BASE_URL}/KanbanItem/List?s={item_no}")
        wait_ready(driver)
        time.sleep(PAUSE)
        print(f"  Filtered via URL — s={item_no}")

    # Print matching rows
    try:
        rows = driver.find_elements(
            By.XPATH, f"//tr[td[normalize-space(.)='{item_no}']]"
        ) or driver.find_elements(By.XPATH, f"//tr[contains(., '{item_no}')]")

        col_labels = [
            "Item No",
            "Description",
            "Price Per UOM",
            "Supplier",
            "Supplier Item No",
            "Lead Time",
            "Cards",
            "Status",
            "Category"]
        if rows:
            print(f"\n  Found {len(rows)} row(s) matching '{item_no}':")
            for idx, row in enumerate(rows[:5], 1):
                cells = row.find_elements(By.TAG_NAME, "td")
                print(f"\n  --- Row {idx} ---")
                for i, cell in enumerate(cells[:len(col_labels)]):
                    val = cell.text.strip()
                    if val:
                        row_out(col_labels[i] if i < len(
                            col_labels) else f"Col {i}", val)
        else:
            if item_no in driver.page_source:
                print(f"  '{item_no}' found in page source")
            else:
                print(f"  WARNING: '{item_no}' not visible in current view")
    except Exception as exc:
        print(f"  Row search error: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 1 — Create Items from item_test_data_1.xlsx
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateItemsData1:
    """Read item_test_data_1.xlsx and create each item via the Admin > Item form."""

    def test_01_load_excel(self, driver):
        assert os.path.isfile(EXCEL_PATH), f"Excel not found: {EXCEL_PATH}"
        items = load_items()
        assert items, "No data rows in Excel"
        banner("EXCEL DATA — item_test_data_1.xlsx")
        row_out("Path", EXCEL_PATH)
        row_out("Rows", len(items))
        print(f"\n  {'#':<4} {'Item No':<20} {'Category':<12} {'Description'}")
        print(f"  {'-' * 4} {'-' * 20} {'-' * 12} {'-' * 35}")
        for i, item in enumerate(items, 1):
            print(
                f"  {
                    i:<4} {
                    item.Item_No:<20} {
                    item.Category:<12} {
                    item.Description}")

    def test_02_login(self, driver):
        step_login(driver)

    def test_03_create_all_items(self, driver):
        items = load_items()
        results = []
        for item in items:
            try:
                step_open_admin(driver)
                step_open_item_list(driver)
                step_click_add(driver)
                create_item_from_row(driver, item)
                results.append(
                    (item.Item_No, item.Category, "PASS", driver.current_url))
            except AssertionError as exc:
                results.append((item.Item_No, item.Category, "FAIL", str(exc)))
                raise

        banner("CREATE ITEMS — RESULTS")
        print(
            f"  {
                '#':<4} {
                'Item No':<20} {
                'Category':<12} {
                    'Status':<8} {'Detail'}")
        print(f"  {'-' * 4} {'-' * 20} {'-' * 12} {'-' * 8} {'-' * 40}")
        for i, (no, cat, status, detail) in enumerate(results, 1):
            print(f"  {i:<4} {no:<20} {cat:<12} {status:<8} {detail[-50:]}")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 2 — Clear filter & filter by each Excel item
# ══════════════════════════════════════════════════════════════════════════════

class TestFilterItemsData1:
    """Login → open Items list → clear filter → filter by each new item."""

    def test_01_login(self, driver):
        step_login(driver)

    def test_02_clear_filter(self, driver):
        banner("STEP — Open Items List & Clear Filter")
        step_open_admin(driver)
        clear_items_list_filter(driver)
        print(f"  Items list (no filter) → {driver.current_url}")

    def test_03_filter_by_each_item(self, driver):
        items = load_items()
        all_results = []
        for item in items:
            clear_items_list_filter(driver)
            filter_items_by_item_no(driver, item.Item_No)
            status = "FOUND" if item.Item_No in driver.page_source else "NOT FOUND"
            all_results.append((item.Item_No, item.Category, status))

        banner("FILTER RESULTS — SUMMARY")
        print(f"  {'#':<4} {'Item No':<20} {'Category':<12} {'Status'}")
        print(f"  {'-' * 4} {'-' * 20} {'-' * 12} {'-' * 10}")
        for i, (no, cat, status) in enumerate(all_results, 1):
            print(f"  {i:<4} {no:<20} {cat:<12} {status}")

        not_found = [r[0] for r in all_results if r[2] == "NOT FOUND"]
        assert not not_found, f"Items not found after filtering: {not_found}"


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 3 — Create Item IT010426
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateItem:
    """Create item IT010426 and verify it in the Items list."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)
    def test_04_click_add(self, driver): step_click_add(driver)

    def test_05_fill_base_info(self, driver):
        step_fill_base_info(driver, "IT010426")

    def test_06_fill_supplier_tab(self, driver):
        step_fill_supplier_tab(driver, "IT010426")

    def test_07_save(self, driver):
        step_save_item(driver, "IT010426")

    def test_08_verify_in_list(self, driver):
        step_verify_in_list(driver, "IT010426")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 4 — Create Item IT020426
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateItem2:
    """Create item IT020426 and verify it in the Items list."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)
    def test_04_click_add(self, driver): step_click_add(driver)

    def test_05_fill_base_info(self, driver):
        step_fill_base_info(driver, "IT020426")

    def test_06_fill_supplier_tab(self, driver):
        step_fill_supplier_tab(driver, "IT020426")

    def test_07_save(self, driver):
        step_save_item(driver, "IT020426")

    def test_08_verify_in_list(self, driver):
        step_verify_in_list(driver, "IT020426")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 5 — Create Item IT070426
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateItem3:
    """Create item IT070426 and verify it in the Items list."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)
    def test_04_click_add(self, driver): step_click_add(driver)

    def test_05_fill_base_info(self, driver):
        step_fill_base_info(driver, "IT070426")

    def test_06_fill_supplier_tab(self, driver):
        step_fill_supplier_tab(driver, "IT070426")

    def test_07_save(self, driver):
        step_save_item(driver, "IT070426")

    def test_08_verify_in_list(self, driver):
        step_verify_in_list(driver, "IT070426")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 5b — Create Item IT140426-3  (Kanban)
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateItem4:
    """Create item IT140426-3 with Kanban category and verify it in the Items list."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)
    def test_04_click_add(self, driver): step_click_add(driver)

    def test_05_fill_base_info(self, driver):
        step_fill_base_info(driver, "IT140426-3")
        select_category(driver, ITEMS["IT140426-3"]["category"])

    def test_06_fill_supplier_tab(self, driver):
        step_fill_supplier_tab(driver, "IT140426-3")

    def test_07_save(self, driver):
        step_save_item(driver, "IT140426-3")

    def test_08_verify_in_list(self, driver):
        step_verify_in_list(driver, "IT140426-3")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 6 — Set Initial Loop Size for IT020426
# ══════════════════════════════════════════════════════════════════════════════

class TestInitialLoopSize:
    """Set the initial loop size for IT020426 via the Add Cards wizard."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)

    def test_04_select_item(self, driver):
        step_select_item_row(driver, LOOP_ITEM_NO)

    def test_05_click_cards(self, driver):
        step_click_cards_button(driver)

    def test_06_click_add_cards(self, driver):
        wait_overlay(driver)
        el = WebDriverWait(
            driver, 15).until(
            EC.presence_of_element_located(
                (By.XPATH, "//*[@title='Add Cards']")))
        scroll_to(driver, el)
        driver.execute_script("arguments[0].click()", el)
        wait_ready(driver)
        time.sleep(PAUSE)
        print(f"  Loop size wizard → {driver.current_url}")

    def test_07_fill_units_and_next(self, driver):
        units_on_hand = random.randint(10, 100)
        units_on_order = random.randint(1, 50)
        fill(driver, "WIZARD_UnitsOnHand", units_on_hand)
        fill(driver, "WIZARD_UnitsOnOrder", units_on_order)
        time.sleep(0.5)
        js_click(driver, By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
        wait_ready(driver)
        time.sleep(PAUSE)
        banner(f"INITIAL LOOP SIZE — {LOOP_ITEM_NO}")
        row_out("Units On Hand", units_on_hand)
        row_out("Units On Order", units_on_order)

    def test_08_complete_wizard(self, driver):
        for step in range(10):
            finish = driver.find_elements(
                By.XPATH,
                "//*[@id='wizFinishBtn' or @title='Finish' or @title='Done'"
                " or (self::button and normalize-space(.)='Finish')]"
            )
            if finish:
                driver.execute_script("arguments[0].click()", finish[0])
                wait_ready(driver)
                time.sleep(PAUSE)
                print(f"  Finish clicked → {driver.current_url}")
                break
            nxt = driver.find_elements(
                By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
            if nxt:
                driver.execute_script("arguments[0].click()", nxt[0])
                wait_ready(driver)
                time.sleep(PAUSE)
            else:
                break
        assert "ultrivalms" in driver.current_url
        banner(f"PASS — Initial Loop Size set for {LOOP_ITEM_NO}", char="─")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS 7 — Adjust Loop Size for IT020426
# ══════════════════════════════════════════════════════════════════════════════

class TestAdjustLoopSize:
    """Adjust loop size for IT020426 by adding replenishment cards."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)

    def test_04_select_item(self, driver):
        step_select_item_row(driver, LOOP_ITEM_NO)

    def test_05_click_cards(self, driver):
        step_click_cards_button(driver)

    def test_06_open_adjust_wizard(self, driver):
        wait_overlay(driver)
        el = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "ItemCard_tbrAdd"))
        )
        scroll_to(driver, el)
        driver.execute_script("arguments[0].click()", el)
        wait_ready(driver)
        time.sleep(PAUSE)
        assert "EboLoopsizeWizard" in driver.current_url, \
            f"Adjust LoopSize wizard not reached — URL: {driver.current_url}"
        print(f"  Adjust LoopSize wizard → {driver.current_url}")

    def test_07_select_add_replenishment(self, driver):
        radio = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "WIZARD$CardOperation1"))
        )
        driver.execute_script("arguments[0].click()", radio)
        time.sleep(0.5)
        assert radio.is_selected(), "'Add Replenishment Cards' radio was not selected"
        js_click(driver, By.ID, "wizNextBtn")
        wait_ready(driver)
        time.sleep(PAUSE)
        print(f"  'Add Replenishment Cards' selected → {driver.current_url}")

    def test_08_enter_cards_and_finish(self, driver):
        el = WebDriverWait(driver, 15).until(
            EC.visibility_of_element_located((By.ID, "WIZARD_RCardsToAdd"))
        )
        scroll_to(driver, el)
        driver.execute_script("arguments[0].removeAttribute('readonly')", el)
        driver.execute_script(f"arguments[0].value = '{CARDS_TO_ADD}'", el)
        el.send_keys(" \b")
        time.sleep(0.5)

        release_radio = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "WIZARD$LoopsizeAction1"))
        )
        driver.execute_script("arguments[0].click()", release_radio)
        time.sleep(0.5)
        assert release_radio.is_selected(), "'Release to Supplier' radio was not selected"

        banner(f"ADJUST LOOP SIZE — {LOOP_ITEM_NO}")
        row_out("Cards to Add", CARDS_TO_ADD)
        row_out("Action", "Release to Supplier")

        finish = driver.find_elements(By.ID, "wizFinishBtn")
        if finish:
            driver.execute_script("arguments[0].click()", finish[0])
        else:
            js_click(driver, By.ID, "wizNextBtn")

        wait_ready(driver)
        time.sleep(PAUSE)

        for _ in range(5):
            fin = driver.find_elements(By.ID, "wizFinishBtn")
            if fin:
                driver.execute_script("arguments[0].click()", fin[0])
                wait_ready(driver)
                time.sleep(PAUSE)
                print(f"  Finish clicked → {driver.current_url}")
                break
            nxt = driver.find_elements(By.ID, "wizNextBtn")
            if nxt:
                driver.execute_script("arguments[0].click()", nxt[0])
                wait_ready(driver)
                time.sleep(PAUSE)
            else:
                break

        assert "ultrivalms" in driver.current_url
        banner(f"PASS — Loop Size adjusted for {LOOP_ITEM_NO}", char="─")


# ══════════════════════════════════════════════════════════════════════════════
#  FOCUSED CLASSES — Excel items loop size + ITTest232 (run without full suite)
# ══════════════════════════════════════════════════════════════════════════════

class TestExcelItemInitialLoop:
    """Set initial loop size for IT-A140426 (Run_Adjust_Loop=Yes from Excel)."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)

    def test_04_select_item(self, driver):
        step_select_item_row(driver, EXCEL_LOOP_ITEM)

    def test_05_click_cards(self, driver):
        step_click_cards_button(driver)

    def test_06_click_add_cards(self, driver):
        wait_overlay(driver)
        el = WebDriverWait(
            driver, 15).until(
            EC.presence_of_element_located(
                (By.XPATH, "//*[@title='Add Cards']")))
        scroll_to(driver, el)
        driver.execute_script("arguments[0].click()", el)
        wait_ready(driver)
        time.sleep(PAUSE)
        print(f"  Loop size wizard → {driver.current_url}")

    def test_07_fill_units_and_next(self, driver):
        units_on_hand = random.randint(10, 100)
        units_on_order = random.randint(1, 50)
        fill(driver, "WIZARD_UnitsOnHand", units_on_hand)
        fill(driver, "WIZARD_UnitsOnOrder", units_on_order)
        time.sleep(0.5)
        js_click(driver, By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
        wait_ready(driver)
        time.sleep(PAUSE)
        banner(f"INITIAL LOOP SIZE — {EXCEL_LOOP_ITEM}")
        row_out("Units On Hand", units_on_hand)
        row_out("Units On Order", units_on_order)

    def test_08_complete_wizard(self, driver):
        for step in range(10):
            finish = driver.find_elements(
                By.XPATH,
                "//*[@id='wizFinishBtn' or @title='Finish' or @title='Done'"
                " or (self::button and normalize-space(.)='Finish')]"
            )
            if finish:
                driver.execute_script("arguments[0].click()", finish[0])
                wait_ready(driver)
                time.sleep(PAUSE)
                break
            nxt = driver.find_elements(
                By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
            if nxt:
                driver.execute_script("arguments[0].click()", nxt[0])
                wait_ready(driver)
                time.sleep(PAUSE)
            else:
                break
        assert "ultrivalms" in driver.current_url
        banner(f"PASS — Initial Loop Size set for {EXCEL_LOOP_ITEM}", char="─")


class TestExcelItemAdjustLoop:
    """Adjust loop size (add replenishment) for IT-A140426."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)

    def test_04_select_item(self, driver):
        step_select_item_row(driver, EXCEL_LOOP_ITEM)

    def test_05_click_cards(self, driver):
        step_click_cards_button(driver)

    def test_06_open_adjust_wizard(self, driver):
        wait_overlay(driver)
        el = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "ItemCard_tbrAdd"))
        )
        scroll_to(driver, el)
        driver.execute_script("arguments[0].click()", el)
        wait_ready(driver)
        time.sleep(PAUSE)
        assert "EboLoopsizeWizard" in driver.current_url, \
            f"Adjust LoopSize wizard not reached — URL: {driver.current_url}"
        print(f"  Adjust LoopSize wizard → {driver.current_url}")

    def test_07_select_add_replenishment(self, driver):
        radio = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "WIZARD$CardOperation1"))
        )
        driver.execute_script("arguments[0].click()", radio)
        time.sleep(0.5)
        assert radio.is_selected(), "'Add Replenishment Cards' radio was not selected"
        js_click(driver, By.ID, "wizNextBtn")
        wait_ready(driver)
        time.sleep(PAUSE)

    def test_08_enter_cards_and_finish(self, driver):
        cards = "12"
        el = WebDriverWait(driver, 15).until(
            EC.visibility_of_element_located((By.ID, "WIZARD_RCardsToAdd"))
        )
        scroll_to(driver, el)
        driver.execute_script("arguments[0].removeAttribute('readonly')", el)
        driver.execute_script(f"arguments[0].value = '{cards}'", el)
        el.send_keys(" \b")
        time.sleep(0.5)
        release_radio = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "WIZARD$LoopsizeAction1"))
        )
        driver.execute_script("arguments[0].click()", release_radio)
        time.sleep(0.5)
        banner(f"ADJUST LOOP SIZE — {EXCEL_LOOP_ITEM}")
        row_out("Cards to Add", cards)
        finish = driver.find_elements(By.ID, "wizFinishBtn")
        if finish:
            driver.execute_script("arguments[0].click()", finish[0])
        else:
            js_click(driver, By.ID, "wizNextBtn")
        wait_ready(driver)
        time.sleep(PAUSE)
        for _ in range(5):
            fin = driver.find_elements(By.ID, "wizFinishBtn")
            if fin:
                driver.execute_script("arguments[0].click()", fin[0])
                wait_ready(driver)
                time.sleep(PAUSE)
                break
            nxt = driver.find_elements(By.ID, "wizNextBtn")
            if nxt:
                driver.execute_script("arguments[0].click()", nxt[0])
                wait_ready(driver)
                time.sleep(PAUSE)
            else:
                break
        assert "ultrivalms" in driver.current_url
        banner(f"PASS — Loop Size adjusted for {EXCEL_LOOP_ITEM}", char="─")


class TestITTest232Create:
    """Create item ITTest232 with Kanban category."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)
    def test_04_click_add(self, driver): step_click_add(driver)

    def test_05_fill_base_info(self, driver):
        step_fill_base_info(driver, ITTEST232_ITEM)
        select_category(driver, ITEMS[ITTEST232_ITEM]["category"])

    def test_06_fill_supplier_tab(self, driver):
        step_fill_supplier_tab(driver, ITTEST232_ITEM)

    def test_07_save(self, driver):
        step_save_item(driver, ITTEST232_ITEM)

    def test_08_verify_in_list(self, driver):
        step_verify_in_list(driver, ITTEST232_ITEM)


class TestITTest232InitialLoop:
    """Set initial loop size for ITTest232."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)

    def test_04_select_item(self, driver):
        step_select_item_row(driver, ITTEST232_ITEM)

    def test_05_click_cards(self, driver):
        step_click_cards_button(driver)

    def test_06_click_add_cards(self, driver):
        wait_overlay(driver)
        el = WebDriverWait(
            driver, 15).until(
            EC.presence_of_element_located(
                (By.XPATH, "//*[@title='Add Cards']")))
        scroll_to(driver, el)
        driver.execute_script("arguments[0].click()", el)
        wait_ready(driver)
        time.sleep(PAUSE)
        print(f"  Loop size wizard → {driver.current_url}")

    def test_07_fill_units_and_next(self, driver):
        units_on_hand = random.randint(10, 100)
        units_on_order = random.randint(1, 50)
        fill(driver, "WIZARD_UnitsOnHand", units_on_hand)
        fill(driver, "WIZARD_UnitsOnOrder", units_on_order)
        time.sleep(0.5)
        js_click(driver, By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
        wait_ready(driver)
        time.sleep(PAUSE)
        banner(f"INITIAL LOOP SIZE — {ITTEST232_ITEM}")
        row_out("Units On Hand", units_on_hand)
        row_out("Units On Order", units_on_order)

    def test_08_complete_wizard(self, driver):
        for step in range(10):
            finish = driver.find_elements(
                By.XPATH,
                "//*[@id='wizFinishBtn' or @title='Finish' or @title='Done'"
                " or (self::button and normalize-space(.)='Finish')]"
            )
            if finish:
                driver.execute_script("arguments[0].click()", finish[0])
                wait_ready(driver)
                time.sleep(PAUSE)
                break
            nxt = driver.find_elements(
                By.XPATH, "//*[@id='wizNextBtn' or @title='Next']")
            if nxt:
                driver.execute_script("arguments[0].click()", nxt[0])
                wait_ready(driver)
                time.sleep(PAUSE)
            else:
                break
        assert "ultrivalms" in driver.current_url
        banner(f"PASS — Initial Loop Size set for {ITTEST232_ITEM}", char="─")


class TestITTest232AdjustLoop:
    """Adjust loop size (add replenishment) for ITTest232."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)

    def test_04_select_item(self, driver):
        step_select_item_row(driver, ITTEST232_ITEM)

    def test_05_click_cards(self, driver):
        step_click_cards_button(driver)

    def test_06_open_adjust_wizard(self, driver):
        wait_overlay(driver)
        el = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "ItemCard_tbrAdd"))
        )
        scroll_to(driver, el)
        driver.execute_script("arguments[0].click()", el)
        wait_ready(driver)
        time.sleep(PAUSE)
        assert "EboLoopsizeWizard" in driver.current_url, \
            f"Adjust LoopSize wizard not reached — URL: {driver.current_url}"
        print(f"  Adjust LoopSize wizard → {driver.current_url}")

    def test_07_select_add_replenishment(self, driver):
        radio = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "WIZARD$CardOperation1"))
        )
        driver.execute_script("arguments[0].click()", radio)
        time.sleep(0.5)
        assert radio.is_selected(), "'Add Replenishment Cards' radio was not selected"
        js_click(driver, By.ID, "wizNextBtn")
        wait_ready(driver)
        time.sleep(PAUSE)

    def test_08_enter_cards_and_finish(self, driver):
        el = WebDriverWait(driver, 15).until(
            EC.visibility_of_element_located((By.ID, "WIZARD_RCardsToAdd"))
        )
        scroll_to(driver, el)
        driver.execute_script("arguments[0].removeAttribute('readonly')", el)
        driver.execute_script(f"arguments[0].value = '{ITTEST232_CARDS}'", el)
        el.send_keys(" \b")
        time.sleep(0.5)
        release_radio = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "WIZARD$LoopsizeAction1"))
        )
        driver.execute_script("arguments[0].click()", release_radio)
        time.sleep(0.5)
        banner(f"ADJUST LOOP SIZE — {ITTEST232_ITEM}")
        row_out("Cards to Add", ITTEST232_CARDS)
        finish = driver.find_elements(By.ID, "wizFinishBtn")
        if finish:
            driver.execute_script("arguments[0].click()", finish[0])
        else:
            js_click(driver, By.ID, "wizNextBtn")
        wait_ready(driver)
        time.sleep(PAUSE)
        for _ in range(5):
            fin = driver.find_elements(By.ID, "wizFinishBtn")
            if fin:
                driver.execute_script("arguments[0].click()", fin[0])
                wait_ready(driver)
                time.sleep(PAUSE)
                break
            nxt = driver.find_elements(By.ID, "wizNextBtn")
            if nxt:
                driver.execute_script("arguments[0].click()", nxt[0])
                wait_ready(driver)
                time.sleep(PAUSE)
            else:
                break
        assert "ultrivalms" in driver.current_url
        banner(f"PASS — Loop Size adjusted for {ITTEST232_ITEM}", char="─")


# ══════════════════════════════════════════════════════════════════════════════
#  NEW  ▸ Create ITDDDD  +  Set Initial Loop Size  +  Adjust Loop Size
#
#  Run ONLY this class (fast, single browser session):
#    cd qa_automation
#    pytest tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestCreateItemITDDDD -v --html=reports/ITDDDD_report.html
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateItemITDDDD:
    """
    Creates item ITDDDD, sets its initial loop size, then adjusts loop size.
    All steps share one browser session (module-scoped driver) — no re-login.
    """

    def test_01_login(self, driver):
        step_login(driver)

    def test_02_open_admin(self, driver):
        step_open_admin(driver)

    def test_03_open_item_list(self, driver):
        step_open_item_list(driver)

    def test_04_click_add(self, driver):
        step_click_add(driver)

    def test_05_fill_base_info(self, driver):
        step_fill_base_info(driver, ITDDDD_ITEM)

    def test_06_fill_supplier_tab(self, driver):
        step_fill_supplier_tab(driver, ITDDDD_ITEM)

    def test_07_save(self, driver):
        step_save_item(driver, ITDDDD_ITEM)

    def test_08_verify_in_list(self, driver):
        step_verify_in_list(driver, ITDDDD_ITEM)

    # ── Initial loop size ────────────────────────────────────────────────────
    def test_09_select_item_for_loop(self, driver):
        step_open_admin(driver)
        step_open_item_list(driver)
        step_select_item_row(driver, ITDDDD_ITEM)

    def test_10_click_cards(self, driver):
        step_click_cards_button(driver)

    def test_11_set_initial_loop_size(self, driver):
        step_set_initial_loop_size(
            driver, ITDDDD_ITEM, ITDDDD_UNITS_HAND, ITDDDD_UNITS_ORD
        )

    # ── Adjust loop size ─────────────────────────────────────────────────────
    def test_12_navigate_back_to_item(self, driver):
        step_open_admin(driver)
        step_open_item_list(driver)
        step_select_item_row(driver, ITDDDD_ITEM)

    def test_13_click_cards_for_adjust(self, driver):
        step_click_cards_button(driver)

    def test_14_adjust_loop_size(self, driver):
        step_adjust_loop_size(driver, ITDDDD_ITEM, ITDDDD_CARDS)


# ══════════════════════════════════════════════════════════════════════════════
#  NEW  ▸ Excel-Driven: Create Items + Initial Loop + Adjust Loop
#         (only rows where Run_Adjust_Loop = Yes)
#
#  Run ONLY this class:
#    cd qa_automation
#    pytest tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestExcelCreateAndAdjustLoop -v --html=reports/excel_loop_report.html
#
#  Run BOTH new classes together (recommended — single browser, no re-login):
#    pytest tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestCreateItemITDDDD tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestExcelCreateAndAdjustLoop -v --html=reports/new_items_report.html
# ══════════════════════════════════════════════════════════════════════════════

class TestExcelCreateAndAdjustLoop:
    """
    Reads item_test_data_1.xlsx (sheet: ItemData).
    For every row where Run_Adjust_Loop = Yes:
      1. Creates the item via Admin > Item form
      2. Sets the initial loop size (Add Cards wizard)
      3. Adjusts loop size using Cards_To_Add from the Excel row
    """

    def test_01_login(self, driver):
        step_login(driver)

    def test_02_preview_excel_data(self, driver):
        assert os.path.isfile(EXCEL_PATH), f"Excel not found: {EXCEL_PATH}"
        items = [i for i in load_items()
                 if str(i.Run_Adjust_Loop).strip().lower() == "yes"]
        assert items, "No rows with Run_Adjust_Loop=Yes in Excel"
        banner("EXCEL — Rows queued for Create + Adjust Loop")
        print(f"  {'#':<4} {'Item No':<20} {'Category':<12} {'Cards_To_Add'}")
        print(f"  {'-' * 4} {'-' * 20} {'-' * 12} {'-' * 12}")
        for i, item in enumerate(items, 1):
            print(
                f"  {
                    i:<4} {
                    item.Item_No:<20} {
                    item.Category:<12} {
                    item.Cards_To_Add}")

    def test_03_create_excel_items(self, driver):
        items = [i for i in load_items()
                 if str(i.Run_Adjust_Loop).strip().lower() == "yes"]
        results = []
        for item in items:
            try:
                step_open_admin(driver)
                step_open_item_list(driver)
                step_click_add(driver)
                create_item_from_row(driver, item)
                results.append(
                    (item.Item_No, "PASS", driver.current_url[-60:]))
            except Exception as exc:
                results.append((item.Item_No, "FAIL", str(exc)[:80]))
                raise

        banner("EXCEL CREATE — RESULTS")
        print(f"  {'Item No':<20} {'Status':<8} {'Detail'}")
        print(f"  {'-' * 20} {'-' * 8} {'-' * 60}")
        for no, status, detail in results:
            print(f"  {no:<20} {status:<8} {detail}")

    def test_04_set_initial_loop_size(self, driver):
        items = [i for i in load_items()
                 if str(i.Run_Adjust_Loop).strip().lower() == "yes"]
        for item in items:
            step_open_admin(driver)
            step_open_item_list(driver)
            step_select_item_row(driver, item.Item_No)
            step_click_cards_button(driver)
            step_set_initial_loop_size(
                driver,
                item.Item_No,
                random.randint(10, 50),
                random.randint(1, 10),
            )

    def test_05_adjust_loop_size(self, driver):
        items = [i for i in load_items()
                 if str(i.Run_Adjust_Loop).strip().lower() == "yes"]
        results = []
        for item in items:
            cards = str(int(item.Cards_To_Add)) if item.Cards_To_Add else "12"
            try:
                step_open_admin(driver)
                step_open_item_list(driver)
                step_select_item_row(driver, item.Item_No)
                step_click_cards_button(driver)
                step_adjust_loop_size(driver, item.Item_No, cards)
                results.append((item.Item_No, cards, "PASS",
                               driver.current_url[-60:]))
            except Exception as exc:
                results.append((item.Item_No, cards, "FAIL", str(exc)[:80]))
                raise

        banner("EXCEL ADJUST LOOP — FINAL RESULTS")
        print(f"  {'Item No':<20} {'Cards':<8} {'Status':<8} {'Detail'}")
        print(f"  {'-' * 20} {'-' * 8} {'-' * 8} {'-' * 60}")
        for no, cards, status, detail in results:
            print(f"  {no:<20} {cards:<8} {status:<8} {detail}")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST CLASS — Create Item IT190426
#
#  Run command:
#    cd qa_automation
#    pytest tests/QALS11/Admin/Item/NewItemCreationandAdjustLoopSize.py::TestCreateItemIT190426 -v -s --html=reports/IT190426_report.html --self-contained-html
# ══════════════════════════════════════════════════════════════════════════════

class TestCreateItemIT190426:
    """Create item IT190426 and verify it in the Items list."""

    def test_01_login(self, driver): step_login(driver)
    def test_02_open_admin(self, driver): step_open_admin(driver)
    def test_03_open_item_list(self, driver): step_open_item_list(driver)
    def test_04_click_add(self, driver): step_click_add(driver)

    def test_05_fill_base_info(self, driver):
        step_fill_base_info(driver, "IT190426")

    def test_06_fill_supplier_tab(self, driver):
        step_fill_supplier_tab(driver, "IT190426")

    def test_07_save(self, driver):
        step_save_item(driver, "IT190426")

    def test_08_verify_in_list(self, driver):
        step_verify_in_list(driver, "IT190426")
