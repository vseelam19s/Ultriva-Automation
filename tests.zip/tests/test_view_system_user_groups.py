import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

# Test: View system user groups (System tab, view group, click cancel)
# Only for new test cases, QA site

import pytest
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium import webdriver

from qa_automation.admin.UserGroup import view_system_user_groups, log
from config.config import USERNAME, PASSWORD, BASE_URL, IMPLICIT_WAIT
from pages.login_page import LoginPage


@pytest.mark.smoke
class TestViewSystemUserGroups:

    def test_view_system_user_groups(self):  # Added 'self' here
        """Test: View system user groups (System tab, view group, click cancel)"""
        
        chrome_options = Options()
        # chrome_options.add_argument('--headless')  # Disable headless for debugging
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        
        driver = webdriver.Chrome(options=chrome_options)
        driver.implicitly_wait(IMPLICIT_WAIT)
        wait = WebDriverWait(driver, 10)
        
        try:
            # Use explicit login URL for reliability
            login_page = LoginPage(driver)
            login_page.open()  # Ensures login page is loaded
            
            # Take screenshot before login for debugging
            # Ensure the 'reports/screenshots/' directory exists, or this might throw an error
            os.makedirs('reports/screenshots', exist_ok=True) 
            driver.save_screenshot('reports/screenshots/before_login_debug.png')
            
            login_page.login(USERNAME, PASSWORD)
            
            # Use a known group title from System tab (update as needed)
            group_title = "App Admin"
            view_system_user_groups(driver, wait, group_title)
            
            log("Test completed: View system user groups.")
            
        finally:
            driver.quit()