"""
QALS11 | Actions > Move Location - End-to-End Move Location Flow
"""

import os
import time

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# ============================================================================
# CONFIGURATION
# ============================================================================

BASE_URL = "https://engineering.ultrivalms.com/QALS1011"
USERNAME = "buyeruser"
PASSWORD = "Ultriva!23"
PAUSE = 1.5

CURRENT_LOCATION = "1234"
NEW_LOCATION_1 = "5001"
NEW_LOCATION_2 = "5002"


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture(scope="class")
def driver():
    """Class-scoped Chrome driver - one browser session per test class."""
    options = webdriver.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-logging"])

    drv = webdriver.Chrome(options=options)
    drv.implicitly_wait(10)
    drv.set_page_load_timeout(30)
    drv.maximize_window()

    yield drv
    drv.quit()


# ============================================================================
# HELPERS
# ============================================================================

def wait_ready(driver, timeout=30):
    """Wait for document.readyState == complete."""
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )


def find(driver, by, locator, timeout=15):
    """Wait for presence and return element."""
    return WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((by, locator))
    )


def clickable(driver, by, locator, timeout=15):
    """Wait until clickable and return element."""
    return WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, locator))
    )


def scroll_to(driver, el):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'})", el)
    time.sleep(0.3)


def take_screenshot(driver, name):
    screenshots_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "..", "reports", "screenshots"
    )
    os.makedirs(screenshots_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(screenshots_dir, f"movelocation_{name}_{ts}.png")
    driver.save_screenshot(path)
    print(f"  [screenshot] {path}")
    return path


# ============================================================================
# TEST CLASS
# ============================================================================

@pytest.mark.usefixtures("driver")
class TestMoveLocation:
    def test_01_login(self, driver):
        """Login to QA site with buyeruser credentials."""
        print("\n[TC-ML-001] Logging in to QA site...")
        driver.get(BASE_URL)
        wait_ready(driver)

        username_field = find(driver, By.ID, "UserName")
        password_field = find(driver, By.ID, "Password")
        login_button = clickable(driver, By.ID, "login-button")

        username_field.clear()
        username_field.send_keys(USERNAME)
        password_field.clear()
        password_field.send_keys(PASSWORD)
        login_button.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "01_after_login")
        current_url = driver.current_url
        print(f"  [URL after login] {current_url}")
        assert BASE_URL.lower() in current_url.lower() or "Home" in current_url, (
            f"Login may have failed. URL: {current_url}"
        )
        print("  [PASS] Login successful.")

    def test_02_navigate_to_actions(self, driver):
        """Click Actions in the left sidebar to open the Actions page."""
        print("\n[TC-ML-002] Navigating to Actions page...")

        actions_link = clickable(
            driver,
            By.XPATH,
            "//a[contains(@href, 'Action/Home') or "
            "(.//span[normalize-space()='Actions']) or "
            "normalize-space(.)='Actions']",
        )
        scroll_to(driver, actions_link)
        actions_link.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "02_actions_page")
        assert "Action/Home" in driver.current_url, (
            f"Expected Actions page. Got: {driver.current_url}"
        )
        print(f"  [PASS] Actions page loaded: {driver.current_url}")

    def test_03_click_move_location(self, driver):
        """Click the Move Location tile from the Buyer Actions section."""
        print("\n[TC-ML-003] Clicking Move Location tile...")

        move_location_link = None
        for locator in [
            (By.XPATH, "//a[contains(@href,'MoveLocation') and not(contains(@class,'toplinks'))]"),
            (By.XPATH, "//a[contains(normalize-space(),'Move Location') and not(contains(@class,'toplinks'))]"),
            (By.XPATH, "//a[contains(@href,'MoveLocation')]"),
        ]:
            try:
                move_location_link = WebDriverWait(driver, 8).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert move_location_link, "Move Location link not found on Actions page"
        scroll_to(driver, move_location_link)
        driver.execute_script("arguments[0].click()", move_location_link)
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "03_move_location_items")
        assert "MoveLocation" in driver.current_url, (
            f"Expected Move Location page. Got: {driver.current_url}"
        )
        print(f"  [PASS] Move Location Items page loaded: {driver.current_url}")

    def test_04_select_item_show_cards(self, driver):
        """Click first item in Move Location Items list, then click Show Cards."""
        print("\n[TC-ML-004] Selecting first item and clicking Show Cards...")

        if "MoveLocationItems" not in driver.current_url:
            driver.get(f"{BASE_URL}/BuyerAction/MoveLocationItems")
            wait_ready(driver)
            time.sleep(PAUSE)

        item_links = WebDriverWait(driver, 20).until(
            EC.presence_of_all_elements_located((By.XPATH, "//a[contains(@class,'GridLink')]"))
        )
        assert item_links, "No items found in Move Location Items List"

        first_item = item_links[0]
        for lnk in item_links:
            if "00kantest" in lnk.text.lower():
                first_item = lnk
                break

        item_text = first_item.text.strip()
        print(f"  [INFO] Selected item: '{item_text}'")

        scroll_to(driver, first_item)
        driver.execute_script("arguments[0].click()", first_item)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "04a_after_item_click")
        print(f"  [INFO] URL after item click: {driver.current_url}")

        if "MoveLocationCard" in driver.current_url:
            print("  [INFO] Navigated directly to Move Location Cards page.")
            return

        show_cards_btn = None
        for locator in [
            (By.XPATH, "//button[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//*[contains(@id,'ShowCards') or contains(@id,'showCards')]"),
        ]:
            try:
                show_cards_btn = WebDriverWait(driver, 6).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert show_cards_btn, "Show Cards button not found and not on Move Location Cards page"
        scroll_to(driver, show_cards_btn)
        driver.execute_script("arguments[0].click()", show_cards_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "04b_move_location_cards")
        assert "MoveLocationCard" in driver.current_url or "MoveLocation" in driver.current_url, (
            f"Expected Move Location Cards page. Got: {driver.current_url}"
        )
        print(f"  [PASS] Move Location Cards List loaded: {driver.current_url}")

    def test_05_enter_locations_and_select_cards(self, driver):
        """Select 2 cards, set current/new locations, then click Move Location."""
        print("\n[TC-ML-005] Entering locations and selecting cards...")

        if "MoveLocationCard" not in driver.current_url:
            driver.get(f"{BASE_URL}/BuyerAction/MoveLocationCards")
            wait_ready(driver)
            time.sleep(PAUSE)

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//input[contains(@id,'$TextboxCurrentLocation')]"))
        )

        selected = 0
        new_locations = [NEW_LOCATION_1, NEW_LOCATION_2]

        for n in range(1, 3):
            card_idx = n
            try:
                chk_name = f"MoveLocationCards_{card_idx}_$CheckboxCardGID"
                curr_id = f"MoveLocationCards_{card_idx}_$TextboxCurrentLocation"
                new_id = f"MoveLocationCards_{card_idx}_$TextboxNewLocation"

                chk = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, f"//input[@name='{chk_name}']"))
                )
                scroll_to(driver, chk)
                if not chk.is_selected():
                    driver.execute_script("arguments[0].click()", chk)
                    time.sleep(0.3)
                if chk.is_selected():
                    selected += 1
                print(f"  [INFO] Card {card_idx}: checkbox selected (name={chk_name})")

                curr_inp = driver.find_element(By.ID, curr_id)
                scroll_to(driver, curr_inp)
                curr_val = curr_inp.get_attribute("value") or ""
                if not curr_val:
                    curr_inp.clear()
                    curr_inp.send_keys(CURRENT_LOCATION)
                    print(f"  [INFO] Card {card_idx}: set Current Location = '{CURRENT_LOCATION}'")
                else:
                    print(f"  [INFO] Card {card_idx}: Current Location already = '{curr_val}' (keeping)")

                new_inp = driver.find_element(By.ID, new_id)
                scroll_to(driver, new_inp)
                new_inp.clear()
                new_inp.send_keys(new_locations[n - 1])
                time.sleep(0.2)
                print(f"  [INFO] Card {card_idx}: set New Location = '{new_locations[n - 1]}'")

            except Exception as e:
                print(f"  [WARN] Could not process card {card_idx}: {e}")

        assert selected > 0, "Could not select any cards"
        print(f"  [INFO] Selected and filled {selected} card(s)")

        take_screenshot(driver, "05_cards_selected_with_locations")

        move_btn = None
        for locator in [
            (By.XPATH, "//button[normalize-space(text())='Move Location']"),
            (By.XPATH, "//button[contains(normalize-space(),'Move Location')]"),
            (By.XPATH, "//a[normalize-space(text())='Move Location' and not(contains(@class,'toplinks'))]"),
            (By.XPATH, "//a[contains(normalize-space(),'Move Location') and not(contains(@href,'MoveLocationItems'))]"),
            (By.XPATH, "//*[@id='btnMoveLocation' or contains(@id,'MoveLocation')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Move Location') and contains(@class,'btn')]"),
        ]:
            try:
                move_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert move_btn, "Move Location button not found on cards page"
        scroll_to(driver, move_btn)
        driver.execute_script("arguments[0].click()", move_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "05b_after_move_location_click")
        print(f"  [URL after Move Location] {driver.current_url}")

    def test_06_verify_move_location_results(self, driver):
        """Verify Move Location Results page shows success message."""
        print("\n[TC-ML-006] Verifying Move Location Results page...")

        current_url = driver.current_url
        print(f"  [URL] {current_url}")

        success_found = False
        for locator in [
            (By.XPATH, "//*[contains(normalize-space(),'Following Cards were successful')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Card Successfully Moved')]"),
            (By.XPATH, "//*[contains(normalize-space(),'successfully')]"),
            (By.XPATH, "//*[contains(normalize-space(),'Move Location') and contains(normalize-space(),'Result')]"),
            (By.XPATH, "//h1[contains(normalize-space(),'Result')] | //h2[contains(normalize-space(),'Result')]"),
        ]:
            try:
                el = WebDriverWait(driver, 8).until(
                    EC.presence_of_element_located(locator)
                )
                msg = el.text.strip()
                print(f"  [INFO] Result message found: '{msg[:100]}'")
                success_found = True
                break
            except Exception:
                continue

        take_screenshot(driver, "06_move_location_results")
        assert (
            "MoveLocationResult" in current_url
            or "MoveLocation" in current_url
            or "BuyerAction" in current_url
        ), f"Not on expected Move Location Results page. URL: {current_url}"

        if not success_found:
            print("  [WARN] Success message not found by text, but URL confirms Move Location page.")

        print("  [PASS] Move Location Results page verified.")

    def test_07_back_to_items(self, driver):
        """Click Back to Items and verify return to Move Location Items list."""
        print("\n[TC-ML-007] Clicking Back to Items...")
        print(f"  [INFO] Currently on: {driver.current_url}")

        back_btn = None
        for locator in [
            (By.XPATH, "//button[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.ID, "btnBackPageTop"),
            (By.ID, "btnBackPageBot"),
            (By.XPATH, "//*[contains(@onclick,'BackToItems') or contains(@href,'MoveLocationItems')]"),
        ]:
            try:
                back_btn = WebDriverWait(driver, 6).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        if back_btn is None:
            print("  [INFO] Back to Items button not visible - navigating directly to MoveLocationItems.")
            driver.get(f"{BASE_URL}/BuyerAction/MoveLocationItems")
            wait_ready(driver)
            time.sleep(PAUSE)
        else:
            scroll_to(driver, back_btn)
            driver.execute_script("arguments[0].click()", back_btn)
            wait_ready(driver)
            time.sleep(PAUSE * 2)

        take_screenshot(driver, "07_back_to_items")
        current_url = driver.current_url
        print(f"  [URL after Back to Items] {current_url}")

        assert "MoveLocation" in current_url, (
            f"Expected Move Location Items page. Got: {current_url}"
        )
        print(f"  [PASS] Returned to Move Location Items page: {current_url}")
