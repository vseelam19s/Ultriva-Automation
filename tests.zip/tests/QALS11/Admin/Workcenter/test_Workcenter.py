"""

QALS11 | Admin > Workcenter — Create, Edit & Workcenter Users

===============================================================

URL  : https://engineering.ultrivalms.com/QALS1011

User : buyeruser / Ultriva!23

Test flow

---------

WORKCENTER CRUD:

  1.  Login as buyeruser

  2.  Navigate to Admin > Workcenter

  3.  Click "+ Add" to create a new workcenter

  4.  Fill mandatory fields with random values, select Label = ebizkanban

  5.  Save the new workcenter  →  Generate creation report

  6.  Edit the created workcenter  →  Generate edit report

WORKCENTER USERS (More Options > Users):

  7.  Navigate to Workcenter List > select WC > More Options > Users

  8.  Add a new user — fill mandatory fields and Save

  9.  Verify user appears in Workcenter User List

  10. Edit user — update First Name, Phone, Buyer Code and Save

  11. View user in read-only mode and Cancel

  12. Disable user → confirm → Enable user → confirm → verify Active

  13. Generate Workcenter Users report

PRODUCTION SEQUENCE CONFIGURATION:

  14. Navigate to More Options > Production Sequence Configuration

      Set Available Production Hours & Schedule Offset on Schedule tab, Save

SHIPPING RULES:

  15. Navigate to More Options > Shipping Rules > Add Shipping Rule

      Select rule, fill mandatory links (ReleaseDay, ShipDate), Apply, Save

RYG RULES:

  16. Navigate to More Options > RYG Rules > Add RYG Rule

      Select any rule, fill mandatory data (thresholds/values), Save

KANBAN FORMULA:

  17. Navigate to More Options > Kanban Formula

      Verify expression, functions, fields are displayed, Save

ATTACHMENT:

  18. Navigate to More Options > Attachment > Add Attachment

      Choose file from Desktop, Upload File(s) — "Attach file process"

Run (from qa_automation/):

    pytest tests/QALS11/Admin/Workcenter/Workcenter.py -v -s

"""

import time

import random

import string

import os

import pytest

from selenium import webdriver

from selenium.webdriver.common.by import By

from selenium.webdriver.support.ui import WebDriverWait, Select

from selenium.webdriver.support import expected_conditions as EC

from selenium.webdriver.common.action_chains import ActionChains

from selenium.webdriver.common.keys import Keys

# ================================================================================

# CLASS-SCOPED DRIVER FIXTURE

# ================================================================================


@pytest.fixture(scope="class")
def driver():

    options = webdriver.ChromeOptions()

    options.add_argument("--no-sandbox")

    options.add_argument("--disable-dev-shm-usage")

    options.add_argument("--disable-gpu")

    options.add_argument("--window-size=1920,1080")

    options.add_argument("--start-maximized")

    options.add_experimental_option("excludeSwitches", ["enable-logging"])

    drv = webdriver.Chrome(options=options)

    drv.implicitly_wait(10)

    drv.set_page_load_timeout(30)

    drv.maximize_window()

    yield drv

    drv.quit()

# ================================================================================

# CONFIGURATION

# ================================================================================


BASE_URL = "https://engineering.ultrivalms.com/QALS1011"

USERNAME = "buyeruser"

PASSWORD = "Ultriva!23"

PAUSE = 2

REPORT_DIR = os.path.join(os.path.dirname(
    __file__), "..", "..", "..", "reports")

_rand = random.randint(1000, 99999)

WC_NAME = f"WC{_rand}"

WC_CODE = f"WC{_rand}"

WC_LOCATION = f"Loc{random.randint(100, 999)}"

# --- Workcenter User Configuration ---

WC_USER_ID = f"WCUser{_rand}"

WC_USER_PW = "Ultriva!23"

WC_USER_FIRST = f"WC{_rand}"

WC_USER_LAST = "User"

WC_USER_EMAIL = "vseelam@uplandsoftware.com"

WC_USER_PHONE = f"555{random.randint(1000000, 9999999)}"

WC_ACCOUNT_TYPE = "Plant Administrators"

# ================================================================================

# HELPERS

# ================================================================================


def page_loaded(driver):

    WebDriverWait(driver, 30).until(

        lambda d: d.execute_script("return document.readyState") == "complete"

    )


def scroll_to(driver, el):

    driver.execute_script("arguments[0].scrollIntoView({block:'center'})", el)

    time.sleep(0.3)


def safe_click(driver, by, locator, timeout=15):

    el = WebDriverWait(
        driver, timeout).until(
        EC.element_to_be_clickable(
            (by, locator)))

    scroll_to(driver, el)

    el.click()

    return el


def safe_fill(driver, by, locator, value, timeout=15):

    el = WebDriverWait(
        driver, timeout).until(
        EC.visibility_of_element_located(
            (by, locator)))

    scroll_to(driver, el)

    try:

        el.clear()

        el.send_keys(str(value))

    except Exception:

        driver.execute_script(
            "arguments[0].value = arguments[1]", el, str(value))

    return el


def random_number(low=1, high=999):

    return random.randint(low, high)


def print_header(title):

    print("\n" + "=" * 80)

    print(f"  {title}")

    print("=" * 80)


def print_step(num, desc):

    print(f"\n  [STEP {num}] {desc}")

# ================================================================================

# TEST CLASS

# ================================================================================

    """

    Admin > Workcenter: Create, Edit & Workcenter User Management

    Phases 1-5 : Workcenter CRUD (Create, Edit, Reports)

    Phases 6-12: Workcenter Users (Add, Verify, Edit, View, Disable, Enable, Report)

    """

    created_wc_name = WC_NAME

    created_wc_code = WC_CODE

    created_wc_location = WC_LOCATION

    creation_fields = {}

    edit_fields = {}

    # --- Workcenter User tracking ---

    wc_user_id = WC_USER_ID

    wc_user_first = WC_USER_FIRST

    wc_user_last = WC_USER_LAST

    wc_user_phone = WC_USER_PHONE

    wc_user_email = WC_USER_EMAIL

    wc_user_fields = {}

    wc_user_edit_fields = {}

    # ========================================================================

    # PHASE 1: LOGIN AND NAVIGATE TO WORKCENTER LIST

    # ========================================================================


class TestWorkcenter:
    def test_01_login_and_navigate_to_workcenter(self, driver):
        print_header("PHASE 1: LOGIN AND NAVIGATE TO ADMIN > WORKCENTER")

        print_step(1, f"Navigating to {BASE_URL}")
        driver.get(BASE_URL)
        page_loaded(driver)

        print_step(2, f"Logging in as {USERNAME}")
        safe_fill(driver, By.ID, "UserName", USERNAME)
        safe_fill(driver, By.ID, "Password", PASSWORD)
        safe_click(driver, By.ID, "login-button")
        page_loaded(driver)
        time.sleep(PAUSE)
        assert "ultrivalms" in driver.current_url, f"Login failed - URL: {
            driver.current_url}"
        print(f"  [PASS] Login successful -> {driver.current_url}")

        print_step(3, "Opening Admin module")
        safe_click(
            driver,
            By.XPATH,
            "//a[contains(@href,'/Admin/Home') or normalize-space(.)='Admin']")
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] Admin module opened -> {driver.current_url}")

        print_step(4, "Clicking Workcenter menu")
        try:
        safe_click(
            driver, By.XPATH, "//a[contains(@href,'Workcenter') and "
            "(normalize-space(.)='Workcenter' or normalize-space(.)='Workcenters')]")
        except Exception:
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] Workcenter list page -> {driver.current_url}")
        driver.save_screenshot("workcenter_list.png")

        # ========================================================================
        # PHASE 2: CLICK ADD AND CREATE NEW WORKCENTER
        # ========================================================================
    def test_02_create_new_workcenter(self, driver):
        print_header("PHASE 2: CREATE NEW WORKCENTER WITH RANDOM VALUES")

        # Step 1: Click "+ Add" button
        print_step(1, "Clicking '+ Add' button")
        add_selectors = [
            "//a[normalize-space(.)='Add' or normalize-space(.)='+ Add']",
            "//button[normalize-space(.)='Add' or normalize-space(.)='+ Add']",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Add')]",
            "//a[contains(@href,'Workcenter/Create')]",
        ]
        add_clicked = False
        for sel in add_selectors:
        try:
        btn = WebDriverWait(
            driver, 8).until(
            EC.element_to_be_clickable(
                (By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        add_clicked = True
        print("  [PASS] '+ Add' button clicked")
        break
        except Exception:
        continue

        if not add_clicked:
        driver.get(f"{BASE_URL}/Workcenter/Create")
        print("  [INFO] Navigated directly to Workcenter/Create")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("workcenter_create_form.png")

        # Step 2: Fill Name (mandatory)
        print_step(2, f"Filling Name: {self.created_wc_name}")
        name_filled = False
        name_selectors = [
            (By.ID, "Name"),
            (By.NAME, "Name"),
            (By.XPATH, "//input[contains(@id,'Name') and not(contains(@id,'Find'))]"),
            (By.XPATH, "//label[contains(text(),'Name')]/following::input[1]"),
        ]
        for by, sel in name_selectors:
        try:
        safe_fill(driver, by, sel, self.created_wc_name)
        name_filled = True
        self.creation_fields["Name"] = self.created_wc_name
        print(f"  [PASS] Name = {self.created_wc_name}")
        break
        except Exception:
        continue
        assert name_filled, "Could not fill Name field"

        # Step 3: Fill Location (mandatory)
        print_step(3, f"Filling Location: {self.created_wc_location}")
        loc_selectors = [
            (By.ID, "Location"),
            (By.NAME, "Location"),
            (By.XPATH, "//input[contains(@id,'Location')]"),
            (By.XPATH, "//label[contains(text(),'Location')]/following::input[1]"),
        ]
        for by, sel in loc_selectors:
        try:
        safe_fill(driver, by, sel, self.created_wc_location)
        self.creation_fields["Location"] = self.created_wc_location
        print(f"  [PASS] Location = {self.created_wc_location}")
        break
        except Exception:
        continue

        # Step 4: Fill Code (mandatory)
        print_step(4, f"Filling Code: {self.created_wc_code}")
        code_selectors = [
            (By.ID, "Code"),
            (By.NAME, "Code"),
            (By.XPATH, "//input[contains(@id,'Code')]"),
            (By.XPATH, "//label[contains(text(),'Code')]/following::input[1]"),
        ]
        for by, sel in code_selectors:
        try:
        safe_fill(driver, by, sel, self.created_wc_code)
        self.creation_fields["Code"] = self.created_wc_code
        print(f"  [PASS] Code = {self.created_wc_code}")
        break
        except Exception:
        continue

        # Step 5: Select Label = ebizkanban (mandatory)
        print_step(5, "Selecting Label: ebizkanban")
        label_selected = False
        label_selectors = [
            (By.ID, "LabelId"),
            (By.NAME, "LabelId"),
            (By.ID, "Label"),
            (By.NAME, "Label"),
            (By.XPATH, "//select[contains(@id,'Label')]"),
            (By.XPATH, "//label[contains(text(),'Label')]/following::select[1]"),
        ]
        for by, sel in label_selectors:
        try:
        sel_el = WebDriverWait(
            driver, 8).until(
            EC.presence_of_element_located(
                (by, sel)))
        scroll_to(driver, sel_el)
        select = Select(sel_el)
        # Try to select ebizkanban by visible text (case-insensitive search)
        for opt in select.options:
        if "ebizkanban" in opt.text.lower() or "ebiz" in opt.text.lower():
        select.select_by_visible_text(opt.text)
        label_selected = True
        self.creation_fields["Label"] = opt.text
        print(f"  [PASS] Label = {opt.text}")
        break
        if label_selected:
        break
        except Exception:
        continue

        if not label_selected:
        print(
            "  [WARN] Could not find 'ebizkanban' label, selecting first available option")
        for by, sel in label_selectors:
        try:
        sel_el = driver.find_element(by, sel)
        select = Select(sel_el)
        options = [o for o in select.options if o.get_attribute("value")]
        if len(options) > 1:
        select.select_by_value(options[1].get_attribute("value"))
        self.creation_fields["Label"] = options[1].text
        print(f"  [INFO] Label = {options[1].text}")
        break
        except Exception:
        continue

        # Step 6: Time zone (mandatory — leave default "Inherit From Owner
        # Business Unit")
        print_step(6, "Time zone — keeping default value")
        try:
        tz_selectors = [
            (By.ID, "TimeZone"),
            (By.NAME, "TimeZone"),
            (By.XPATH, "//select[contains(@id,'TimeZone') or contains(@id,'Timezone')]"),
        ]
        for by, sel in tz_selectors:
        try:
        tz_el = driver.find_element(by, sel)
        if tz_el.is_displayed():
        select = Select(tz_el)
        current = select.first_selected_option.text
        self.creation_fields["Time zone"] = current
        print(f"  [INFO] Time zone = {current} (default)")
        break
        except Exception:
        continue
        except Exception:
        print("  [INFO] Time zone field not found or not editable")

        # Step 7: Weekly Holiday checkboxes — leave defaults (Sun, Sat checked)
        print_step(7, "Weekly Holiday — keeping defaults (Sun, Sat)")
        self.creation_fields["Weekly Holiday"] = "Sun, Sat (default)"

        driver.save_screenshot("workcenter_form_filled.png")

        # Step 8: Click Save
        print_step(8, "Clicking Save button")
        self._click_save(driver)

        time.sleep(PAUSE)
        page_loaded(driver)
        driver.save_screenshot("workcenter_after_save.png")

        # Verify save — check URL returned to list or success message
        current_url = driver.current_url
        page_src = driver.page_source
        if "List" in current_url or "Workcenter" in current_url:
        print(f"  [PASS] Workcenter created successfully -> {current_url}")
        elif "error" in page_src.lower() or "validation" in page_src.lower():
        print(f"  [WARN] Possible validation error on page")
        else:
        print(f"  [INFO] After save URL: {current_url}")

        # ========================================================================
        # PHASE 3: GENERATE CREATION REPORT
        # ========================================================================
    def test_03_generate_creation_report(self, driver):
        print_header("PHASE 3: WORKCENTER CREATION REPORT")

        report = f"""
        ================================================================================
        WORKCENTER CREATION REPORT — {self.created_wc_name}
        ================================================================================
        Date/Time  : {time.strftime('%Y-%m-%d %H:%M:%S')}
        Test URL   : {BASE_URL}
        User       : {USERNAME}
        Action     : Create New Workcenter

        WORKCENTER DETAILS:
        ================================================================================
        """
        for key, val in self.creation_fields.items():
        report += f"  {key:<20}: {val}\n"

        report += f"""
        OPERATIONS PERFORMED:
        ================================================================================
        1. Login as {USERNAME}
        2. Navigate to Admin > Workcenter
        3. Click '+ Add' to open Create New Workcenter form
        4. Fill mandatory fields with random values
        5. Select Label = ebizkanban
        6. Click Save

        CURRENT URL: {driver.current_url}
        ================================================================================
        """
        print(report)

        os.makedirs(REPORT_DIR, exist_ok=True)
        report_path = os.path.join(
            REPORT_DIR, f"Workcenter_Create_{
                self.created_wc_name}.txt")
        try:
        with open(report_path, "w") as f:
        f.write(report)
        print(f"  [PASS] Report saved: {report_path}")
        except Exception as e:
        print(f"  [WARN] Report save error: {e}")

        driver.save_screenshot("workcenter_creation_final.png")

        # ========================================================================
        # PHASE 4: EDIT THE CREATED WORKCENTER
        # ========================================================================
    def test_04_edit_workcenter(self, driver):
        print_header("PHASE 4: EDIT WORKCENTER")

        # Step 1: Ensure we are on the Workcenter list page
        print_step(1, "Navigating to Workcenter list")
        if "Workcenter/List" not in driver.current_url:
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Step 2: Search for the created workcenter using Find Name
        print_step(2, f"Searching for '{self.created_wc_name}' in Find Name")
        search_done = False
        find_selectors = [
            (By.XPATH, "//input[contains(@placeholder,'Find Name') or @placeholder='Find Name']"),
            (By.XPATH, "//input[contains(@id,'Find')]"),
            (By.XPATH, "//input[contains(@name,'Find')]"),
        ]
        for by, sel in find_selectors:
        try:
        field = WebDriverWait(
            driver, 5).until(
            EC.visibility_of_element_located(
                (by, sel)))
        scroll_to(driver, field)
        field.clear()
        field.send_keys(self.created_wc_name)
        time.sleep(0.5)
        # Click find/search icon
        try:
        safe_click(driver, By.XPATH,
                   "//img[contains(@src,'find') or contains(@alt,'Find')] | "
                   "//a[contains(@onclick,'Find')] | "
                   "//span[contains(@onclick,'Find')]",
                   timeout=3)
        except Exception:
        field.send_keys(Keys.RETURN)
        search_done = True
        print(f"  [PASS] Searched for '{self.created_wc_name}'")
        break
        except Exception:
        continue

        if not search_done:
        print("  [INFO] Find field not found, looking in list directly")

        time.sleep(PAUSE)
        driver.save_screenshot("workcenter_search_for_edit.png")

        # Step 3: Select the workcenter row
        print_step(3, f"Selecting '{self.created_wc_name}' row")
        row_xpaths = [
            f"//tr[.//td[contains(normalize-space(.),'{self.created_wc_name}')]]",
            f"//td[contains(normalize-space(.),'{self.created_wc_name}')]",
        ]
        row_clicked = False
        for xpath in row_xpaths:
        try:
        row = WebDriverWait(
            driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, xpath)))
        scroll_to(driver, row)
        row.click()
        row_clicked = True
        time.sleep(1)
        print(f"  [PASS] '{self.created_wc_name}' row selected")
        break
        except Exception:
        continue

        if not row_clicked:
        print(
            "  [WARN] Could not find the created workcenter row, trying direct edit URL")

        # Step 4: Click Edit button
        print_step(4, "Clicking 'Edit' button")
        edit_selectors = [
            "//a[normalize-space(.)='Edit' or normalize-space(.)='✎ Edit']",
            "//button[normalize-space(.)='Edit']",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Edit')]",
            "//a[contains(@href,'Workcenter/Edit')]",
        ]
        edit_clicked = False
        for sel in edit_selectors:
        try:
        btn = WebDriverWait(
            driver, 8).until(
            EC.element_to_be_clickable(
                (By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        edit_clicked = True
        print("  [PASS] 'Edit' button clicked")
        break
        except Exception:
        continue

        if not edit_clicked:
        print("  [WARN] Edit button not found, trying double-click on row")
        for xpath in row_xpaths:
        try:
        row = driver.find_element(By.XPATH, xpath)
        ActionChains(driver).double_click(row).perform()
        edit_clicked = True
        print("  [PASS] Double-clicked row to edit")
        break
        except Exception:
        continue

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("workcenter_edit_form.png")
        print(f"  [INFO] Edit page URL: {driver.current_url}")

        # Step 5: Update fields with new random values
        print_step(5, "Updating workcenter fields with new values")

        new_location = f"EditLoc{random.randint(100, 999)}"

        # Update Location
        loc_selectors = [
            (By.ID, "Location"),
            (By.NAME, "Location"),
            (By.XPATH, "//input[contains(@id,'Location')]"),
        ]
        for by, sel in loc_selectors:
        try:
        safe_fill(driver, by, sel, new_location)
        self.edit_fields["Location"] = new_location
        print(f"  [UPDATED] Location = {new_location}")
        break
        except Exception:
        continue

        # Update Time zone — pick a random option
        tz_selectors = [
            (By.ID, "TimeZone"),
            (By.NAME, "TimeZone"),
            (By.XPATH, "//select[contains(@id,'TimeZone') or contains(@id,'Timezone')]"),
        ]
        for by, sel in tz_selectors:
        try:
        tz_el = WebDriverWait(
            driver, 5).until(
            EC.presence_of_element_located(
                (by, sel)))
        if tz_el.is_displayed():
        select = Select(tz_el)
        options = [o for o in select.options if o.get_attribute("value")]
        if len(options) > 1:
        choice = random.choice(options[1:])
        scroll_to(driver, tz_el)
        select.select_by_value(choice.get_attribute("value"))
        self.edit_fields["Time zone"] = choice.text
        print(f"  [UPDATED] Time zone = {choice.text}")
        break
        except Exception:
        continue

        # Toggle some Weekly Holiday checkboxes
        print_step(6, "Toggling Weekly Holiday checkboxes")
        checkboxes = driver.find_elements(
            By.XPATH, "//input[@type='checkbox' and not(@disabled)]")
        for cb in checkboxes:
        try:
        if not cb.is_displayed():
        continue
        fid = cb.get_attribute("id") or cb.get_attribute("name") or ""
        # Only toggle holiday-related checkboxes with ~50% probability
        if random.random() > 0.5:
        scroll_to(driver, cb)
        cb.click()
        state = "checked" if cb.is_selected() else "unchecked"
        self.edit_fields[f"Checkbox {fid}"] = state
        print(f"  [TOGGLED] {fid} -> {state}")
        except Exception:
        continue

        # Toggle Kanban Configuration > Auto Accept if visible
        try:
        auto_accept_selectors = [
            "//label[contains(text(),'Auto Accept')]/following::*[contains(@class,'toggle') or @type='checkbox'][1]",
            "//*[contains(@id,'AutoAccept') or contains(@name,'AutoAccept')]",
        ]
        for sel in auto_accept_selectors:
        try:
        toggle = WebDriverWait(driver, 3).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, toggle)
        toggle.click()
        self.edit_fields["Auto Accept"] = "toggled"
        print("  [TOGGLED] Auto Accept")
        break
        except Exception:
        continue
        except Exception:
        pass

        driver.save_screenshot("workcenter_edit_updated.png")

        # Step 7: Click Save
        print_step(7, "Clicking Save button")
        self._click_save(driver)

        time.sleep(PAUSE)
        page_loaded(driver)
        driver.save_screenshot("workcenter_edit_saved.png")

        current_url = driver.current_url
        print(f"  [PASS] Workcenter edited and saved -> {current_url}")

        # ========================================================================
        # PHASE 5: GENERATE EDIT REPORT
        # ========================================================================
    def test_05_generate_edit_report(self, driver):
        print_header("PHASE 5: EDIT WORKCENTER REPORT")

        report = f"""
        ================================================================================
        EDIT WORKCENTER REPORT — {self.created_wc_name}
        ================================================================================
        Date/Time  : {time.strftime('%Y-%m-%d %H:%M:%S')}
        Test URL   : {BASE_URL}
        User       : {USERNAME}
        Action     : Edit Workcenter

        ORIGINAL CREATION VALUES:
        ================================================================================
        """
        for key, val in self.creation_fields.items():
        report += f"  {key:<20}: {val}\n"

        report += f"""
        UPDATED VALUES (EDIT):
        ================================================================================
        """
        for key, val in self.edit_fields.items():
        report += f"  {key:<20}: {val}\n"

        report += f"""
        OPERATIONS PERFORMED:
        ================================================================================
        1. Navigate to Workcenter list
        2. Search for '{self.created_wc_name}'
        3. Select the workcenter row
        4. Click 'Edit' button
        5. Update Location, Time zone, Weekly Holidays, Auto Accept
        6. Click Save

        CURRENT URL: {driver.current_url}
        ================================================================================
        """
        print(report)

        os.makedirs(REPORT_DIR, exist_ok=True)
        report_path = os.path.join(
            REPORT_DIR, f"Workcenter_Edit_{
                self.created_wc_name}.txt")
        try:
        with open(report_path, "w") as f:
        f.write(report)
        print(f"  [PASS] Edit report saved: {report_path}")
        except Exception as e:
        print(f"  [WARN] Report save error: {e}")

        driver.save_screenshot("workcenter_edit_final.png")
        print("  [DONE] Workcenter Create & Edit test complete.")

        # ========================================================================
        # PHASE 6: NAVIGATE TO WORKCENTER USERS (More Options > Users)
        # ========================================================================
    def test_06_navigate_to_workcenter_users(self, driver):
        """
        From the Workcenter List:
        1. Search for the created workcenter
        2. Select the workcenter row
        3. Click 'More Options' > 'Users'
        4. Verify the User List page for that workcenter loads
        """
        print_header("PHASE 6: NAVIGATE TO WORKCENTER > MORE OPTIONS > USERS")

        # Step 1: Go to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        if "Workcenter/List" not in driver.current_url:
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Step 2: Search for workcenter
        print_step(2, f"Searching for '{self.created_wc_name}'")
        try:
        find_field = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((
                By.XPATH,
                "//input[contains(@placeholder,'Find Name') or contains(@id,'Find')]"
            ))
        )
        find_field.clear()
        find_field.send_keys(self.created_wc_name)
        time.sleep(0.5)
        try:
        safe_click(driver, By.XPATH,
                   "//img[contains(@src,'find') or contains(@alt,'Find')] | "
                   "//a[contains(@onclick,'Find')]", timeout=3)
        except Exception:
        find_field.send_keys(Keys.RETURN)
        print(f"  [PASS] Searched for '{self.created_wc_name}'")
        except Exception:
        print("  [INFO] Find field not found, looking in list directly")
        time.sleep(PAUSE)

        # Step 3: Select workcenter row
        print_step(3, f"Selecting '{self.created_wc_name}' row")
        row_xpaths = [
            f"//tr[.//td[contains(normalize-space(.),'{self.created_wc_name}')]]",
            f"//td[contains(normalize-space(.),'{self.created_wc_name}')]",
        ]
        for xpath in row_xpaths:
        try:
        row = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, xpath)))
        scroll_to(driver, row)
        row.click()
        time.sleep(1)
        print(f"  [PASS] '{self.created_wc_name}' row selected")
        break
        except Exception:
        continue

        # Step 4: Click 'More Options' dropdown
        print_step(4, "Clicking 'More Options' dropdown")
        more_opts_selectors = [
            "//button[contains(normalize-space(.),'More Options')]",
            "//a[contains(normalize-space(.),'More Options')]",
            "//*[contains(@class,'dropdown') and contains(normalize-space(.),'More Options')]",
        ]
        for sel in more_opts_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        print("  [PASS] 'More Options' dropdown clicked")
        break
        except Exception:
        continue
        time.sleep(1)

        # Dump dropdown menu items for debugging
        dropdown_items = driver.execute_script("""
        var items = [];
        var menus = document.querySelectorAll('.dropdown-menu li a, .dropdown.open li a, ul.dropdown-menu a');
        for (var i = 0; i < menus.length; i++) {
        var el = menus[i];
        if (el.offsetParent !== null) {
        items.push(el.textContent.trim() + ' -> ' + (el.getAttribute('href') || ''));
        }
        }
        if (items.length === 0) {
        // Try broader search for visible links
        var all = document.querySelectorAll('a');
        for (var i = 0; i < all.length; i++) {
        var el = all[i];
        var text = el.textContent.trim();
        if (text && el.offsetParent !== null && (text.toLowerCase().indexOf('user') >= 0 || text.toLowerCase().indexOf('disabled') >= 0 || text.toLowerCase().indexOf('show') >= 0)) {
        items.push('[broad] ' + text + ' -> ' + (el.getAttribute('href') || ''));
        }
        }
        }
        return items;
        """)
        print(f"  [DEBUG] Dropdown items: {dropdown_items}")

        # Step 5: Click 'Users' from dropdown
        print_step(5, "Clicking 'Users' from dropdown menu")
        # Scope to visible dropdown-menu to avoid clicking sidebar 'Users' link
        users_selectors = [
            "//*[contains(@class,'dropdown-menu') and contains(@style,'display')]//a[normalize-space(.)='Users']",
            "//*[contains(@class,'dropdown-menu')]//a[normalize-space(.)='Users']",
            "//ul[contains(@class,'dropdown-menu')]//a[contains(normalize-space(.),'User')]",
            "//li[@class='open']//a[normalize-space(.)='Users']",
        ]
        users_clicked = False
        for sel in users_selectors:
        try:
        link = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        href = link.get_attribute("href") or ""
        print(f"  [INFO] Found 'Users' link href={href}")
        driver.execute_script("arguments[0].click();", link)
        users_clicked = True
        print("  [PASS] 'Users' link clicked")
        break
        except Exception:
        continue

        if not users_clicked:
            # Fallback: JS — find visible dropdown Users link (skip sidebar
            # links)
        result = driver.execute_script("""
        var menus = document.querySelectorAll('.dropdown-menu a, .dropdown.open a');
        for (var i = 0; i < menus.length; i++) {
        if (menus[i].textContent.trim() === 'Users' || menus[i].textContent.trim() === 'Workcenter Users') {
        menus[i].click(); return 'clicked';
        }
        }
        // Last resort: find all visible 'Users' links and pick the one in dropdown context
        var all = document.querySelectorAll('a');
        for (var i = 0; i < all.length; i++) {
        var el = all[i];
        if (el.textContent.trim() === 'Users' && el.closest('.dropdown-menu, .dropdown.open, .btn-group')) {
        el.click(); return 'clicked-fallback';
        }
        }
        return 'not-found';
        """)
        print(f"  [INFO] 'Users' JS fallback result: {result}")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("workcenter_users_list.png")

        # Log current URL for debugging
        current_url = driver.current_url
        print(f"  [INFO] Current URL after Users click: {current_url}")

        # Verify we are on the User List page for this workcenter
        assert "User" in current_url or "ListW" in current_url or "user" in current_url.lower(
        ), f"Did not reach Workcenter User List. URL: {current_url}"
        print(f"  [PASS] Workcenter User List page -> {current_url}")

        # ========================================================================
        # PHASE 7: ADD NEW USER IN WORKCENTER
        # ========================================================================
    def test_07_add_workcenter_user(self, driver):
        """
        Add a new user from the Workcenter User List page:
        1. Click '+ Add' button
        2. Fill mandatory fields: First Name, Last Name, Work Phone,
        Email, Login Name, Account Type, Password, Confirm Password
        3. Click Save
        4. Verify user appears in the User List
        """
        print_header("PHASE 7: ADD NEW USER IN WORKCENTER")

        # Step 1: Click '+ Add' button
        print_step(1, "Clicking '+ Add' button on User List")
        add_selectors = [
            "//a[normalize-space(.)='Add' or normalize-space(.)='+ Add']",
            "//button[normalize-space(.)='Add' or normalize-space(.)='+ Add']",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Add')]",
            "//a[contains(@href,'User/Create')]",
        ]
        add_clicked = False
        for sel in add_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        add_clicked = True
        print("  [PASS] '+ Add' button clicked")
        break
        except Exception:
        continue
        if not add_clicked:
        print("  [WARN] '+ Add' not found, trying direct URL")
        driver.get(f"{BASE_URL}/User/Create")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("wc_user_create_form.png")
        print(f"  [INFO] Create User form URL: {driver.current_url}")

        # Step 2: Fill First Name
        print_step(2, f"Filling First Name: {self.wc_user_first}")
        for by, sel in [
            (By.NAME, "PRS$FirstName"),
            (By.XPATH, "//input[contains(@name,'FirstName')]"),
        ]:
        try:
        safe_fill(driver, by, sel, self.wc_user_first)
        self.wc_user_fields["First Name"] = self.wc_user_first
        print(f"  [PASS] First Name = {self.wc_user_first}")
        break
        except Exception:
        continue

        # Step 3: Fill Last Name
        print_step(3, f"Filling Last Name: {self.wc_user_last}")
        for by, sel in [
            (By.NAME, "PRS$LastName"),
            (By.XPATH, "//input[contains(@name,'LastName')]"),
        ]:
        try:
        safe_fill(driver, by, sel, self.wc_user_last)
        self.wc_user_fields["Last Name"] = self.wc_user_last
        print(f"  [PASS] Last Name = {self.wc_user_last}")
        break
        except Exception:
        continue

        # Step 4: Fill Work Phone
        print_step(4, f"Filling Work Phone: {self.wc_user_phone}")
        for by, sel in [
            (By.NAME, "PRS$WorkPhone"),
            (By.XPATH, "//input[contains(@name,'WorkPhone')]"),
        ]:
        try:
        safe_fill(driver, by, sel, self.wc_user_phone)
        self.wc_user_fields["Work Phone"] = self.wc_user_phone
        print(f"  [PASS] Work Phone = {self.wc_user_phone}")
        break
        except Exception:
        continue

        # Step 5: Fill Email
        print_step(5, f"Filling Email: {self.wc_user_email}")
        for by, sel in [
            (By.NAME, "PRS$EmailID"),
            (By.XPATH, "//input[contains(@name,'EmailID')]"),
        ]:
        try:
        safe_fill(driver, by, sel, self.wc_user_email)
        self.wc_user_fields["Email"] = self.wc_user_email
        print(f"  [PASS] Email = {self.wc_user_email}")
        break
        except Exception:
        continue

        # Step 6: Fill Login Name (User ID)
        print_step(6, f"Filling Login Name: {self.wc_user_id}")
        for by, sel in [
            (By.NAME, "USR$LoginName"),
            (By.XPATH, "//input[contains(@name,'LoginName')]"),
        ]:
        try:
        safe_fill(driver, by, sel, self.wc_user_id)
        self.wc_user_fields["Login Name"] = self.wc_user_id
        print(f"  [PASS] Login Name = {self.wc_user_id}")
        break
        except Exception:
        continue

        # Step 7: Select Account Type
        print_step(7, f"Selecting Account Type: {WC_ACCOUNT_TYPE}")
        acct_selected = False
        for by, sel in [
            (By.NAME, "USR$AccountType"),
            (By.ID, "USR_AccountType"),
            (By.NAME, "AccountType"),
            (By.XPATH, "//select[contains(@name,'AccountType') or contains(@id,'AccountType')]"),
        ]:
        try:
        el = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((by, sel)))
        select = Select(el)
        for opt in select.options:
        if WC_ACCOUNT_TYPE.lower() in opt.text.lower():
        select.select_by_visible_text(opt.text)
        self.wc_user_fields["Account Type"] = opt.text
        acct_selected = True
        print(f"  [PASS] Account Type = {opt.text}")
        break
        if acct_selected:
        break
        except Exception:
        continue
        if not acct_selected:
        print("  [WARN] Could not set Account Type")

        # Step 8: Fill Password and Confirm Password
        print_step(8, f"Filling Password fields")
        for field_name in ("MISC$Password", "MISC$ConfirmPassword"):
        try:
        safe_fill(driver, By.NAME, field_name, WC_USER_PW, timeout=6)
        print(f"  [PASS] {field_name} filled")
        except Exception:
        print(f"  [WARN] Could not fill {field_name}")
        self.wc_user_fields["Password"] = "Set"

        driver.save_screenshot("wc_user_form_filled.png")

        # Step 9: Click Save
        print_step(9, "Clicking Save button")
        self._click_save(driver)
        time.sleep(PAUSE)
        page_loaded(driver)
        driver.save_screenshot("wc_user_after_save.png")

        current_url = driver.current_url
        print(f"  [PASS] User created successfully -> {current_url}")

        # ========================================================================
        # PHASE 8: VERIFY USER IN WORKCENTER USER LIST
        # ========================================================================
    def test_08_verify_user_in_workcenter_list(self, driver):
        """
        Navigate back to the Workcenter User List and verify
        the newly created user appears in the grid.
        """
        print_header("PHASE 8: VERIFY USER IN WORKCENTER USER LIST")

        # Step 1: Navigate back to Workcenter list, select WC, More Options >
        # Users
        print_step(1, "Navigating back to Workcenter User List")
        # Try clicking Back button first
        try:
        back_btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Back' or normalize-space(.)='← Back'] | "
                "//*[contains(@class,'btn') and contains(normalize-space(.),'Back')]"
            ))
        )
        scroll_to(driver, back_btn)
        back_btn.click()
        page_loaded(driver)
        time.sleep(PAUSE)
        print("  [PASS] Clicked Back button")
        except Exception:
            # Navigate via Workcenter list > More Options > Users
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Re-select workcenter and navigate to Users
        for xpath in [
            f"//td[contains(normalize-space(.),'{self.created_wc_name}')]",
            f"//tr[.//td[contains(normalize-space(.),'{self.created_wc_name}')]]",
        ]:
        try:
        row = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, xpath)))
        scroll_to(driver, row)
        row.click()
        time.sleep(1)
        break
        except Exception:
        continue

        # Click More Options > Users
        try:
        more_btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(normalize-space(.),'More Options')] | "
                "//a[contains(normalize-space(.),'More Options')]"
            ))
        )
        more_btn.click()
        time.sleep(1)
        users_link = WebDriverWait(
            driver, 5).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//a[normalize-space(.)='Users']")))
        driver.execute_script("arguments[0].click();", users_link)
        page_loaded(driver)
        time.sleep(PAUSE)
        except Exception:
        pass
        print("  [INFO] Navigated back to Workcenter User List")

        driver.save_screenshot("wc_user_list_verify.png")

        # Step 2: Search for user in list
        print_step(2, f"Searching for '{self.wc_user_id}' in User List")
        try:
        search_box = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((
                By.XPATH,
                "//input[contains(@name,'FindTextbox') or contains(@placeholder,'Find')]"
            ))
        )
        search_box.clear()
        search_box.send_keys(self.wc_user_id)
        time.sleep(PAUSE)
        print(f"  [PASS] Searched for '{self.wc_user_id}'")
        except Exception:
        print("  [INFO] Search box not found, checking list directly")

        # Step 3: Verify user exists in grid
        print_step(3, f"Verifying '{self.wc_user_id}' appears in grid")
        try:
        user_cell = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(text())='{self.wc_user_id}']"
            ))
        )
        print(
            f"  [PASS] User '{
                self.wc_user_id}' found in Workcenter User List")
        except Exception:
            # Check page source as fallback
        if self.wc_user_id in driver.page_source:
        print(f"  [PASS] User '{self.wc_user_id}' found in page source")
        else:
        print(f"  [WARN] User '{self.wc_user_id}' not visible in list")

        # ========================================================================
        # PHASE 9: EDIT WORKCENTER USER
        # ========================================================================
    def test_09_edit_workcenter_user(self, driver):
        """
        Edit the created workcenter user:
        1. Search and select the user row
        2. Click Edit toolbar button
        3. Update First Name, Work Phone, Buyer Code
        4. Click Save
        """
        print_header("PHASE 9: EDIT WORKCENTER USER")

        # Step 1: Search and select user row
        print_step(1, f"Selecting user '{self.wc_user_id}' row")
        try:
        user_cell = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(text())='{self.wc_user_id}']"
            ))
        )
        scroll_to(driver, user_cell)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"  [PASS] User '{self.wc_user_id}' row selected")
        except Exception:
        print(f"  [WARN] Could not find user row, trying search first")
        try:
        sb = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((
                By.XPATH,
                "//input[contains(@name,'FindTextbox') or contains(@placeholder,'Find')]"
            ))
        )
        sb.clear()
        sb.send_keys(self.wc_user_id)
        time.sleep(PAUSE)
        user_cell = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(text())='{self.wc_user_id}']"
            ))
        )
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"  [PASS] Found and selected '{self.wc_user_id}'")
        except Exception:
        print(f"  [WARN] User row not found")

        # Step 2: Click Edit toolbar button
        print_step(2, "Clicking 'Edit' toolbar button")
        edit_selectors = [
            (By.XPATH, "//a[@title='Edit'] | //button[@title='Edit']"),
            (By.XPATH, "//a[normalize-space(.)='Edit'] | //button[normalize-space(.)='Edit']"),
            (By.XPATH, "//*[contains(@class,'btn') and contains(normalize-space(.),'Edit')]"),
            (By.ID, "User_tbrEdit"),
        ]
        for by, sel in edit_selectors:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((by, sel)))
        driver.execute_script("arguments[0].click();", btn)
        print("  [PASS] Edit button clicked")
        break
        except Exception:
        continue
        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("wc_user_edit_form.png")
        print(f"  [INFO] Edit User URL: {driver.current_url}")

        # Step 3: Update fields
        edit_first = f"Edited{self.wc_user_first}"
        edit_phone = f"555{random.randint(1000000, 9999999)}"
        edit_buyer = "".join(
            random.choices(
                string.ascii_uppercase +
                string.digits,
                k=4))

        print_step(3, "Updating user fields with new values")

        # Update First Name
        try:
        safe_fill(driver, By.NAME, "PRS$FirstName", edit_first)
        self.wc_user_edit_fields["First Name"] = edit_first
        print(f"  [UPDATED] First Name = {edit_first}")
        except Exception:
        print("  [WARN] Could not update First Name")

        # Update Work Phone
        try:
        safe_fill(driver, By.NAME, "PRS$WorkPhone", edit_phone)
        self.wc_user_edit_fields["Work Phone"] = edit_phone
        print(f"  [UPDATED] Work Phone = {edit_phone}")
        except Exception:
        print("  [WARN] Could not update Work Phone")

        # Update Buyer Code
        try:
        safe_fill(driver, By.NAME, "USR$BuyerCode", edit_buyer, timeout=5)
        self.wc_user_edit_fields["Buyer Code"] = edit_buyer
        print(f"  [UPDATED] Buyer Code = {edit_buyer}")
        except Exception:
        pass

        # Update Email (re-confirm)
        try:
        safe_fill(driver, By.NAME, "PRS$EmailID", self.wc_user_email)
        except Exception:
        pass

        driver.save_screenshot("wc_user_edit_updated.png")

        # Step 4: Click Save
        print_step(4, "Clicking Save button")
        self._click_save(driver)
        time.sleep(PAUSE)
        page_loaded(driver)
        driver.save_screenshot("wc_user_edit_saved.png")
        print(
            f"  [PASS] Workcenter user edited and saved -> {driver.current_url}")

        # ========================================================================
        # PHASE 10: VIEW WORKCENTER USER (Read-Only)
        # ========================================================================
    def test_10_view_workcenter_user(self, driver):
        """
        View the workcenter user in read-only mode:
        1. Navigate to User List for workcenter
        2. Search and select the user row
        3. Click View toolbar button
        4. Verify read-only View User page loads
        5. Click Cancel to return
        """
        print_header("PHASE 10: VIEW WORKCENTER USER (READ-ONLY)")

        # Step 1: Ensure on User List page
        print_step(1, "Navigating to Workcenter User List")
        # Try Back button or re-navigate
        if "User" not in driver.current_url or "List" not in driver.current_url:
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        # Select WC -> More Options -> Users
        for xpath in [
            f"//td[contains(normalize-space(.),'{self.created_wc_name}')]",
            f"//tr[.//td[contains(normalize-space(.),'{self.created_wc_name}')]]",
        ]:
        try:
        row = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, xpath)))
        scroll_to(driver, row)
        row.click()
        time.sleep(1)
        break
        except Exception:
        continue
        try:
        more_btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(normalize-space(.),'More Options')] | "
                "//a[contains(normalize-space(.),'More Options')]"
            ))
        )
        more_btn.click()
        time.sleep(1)
        users_link = WebDriverWait(
            driver, 5).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//a[normalize-space(.)='Users']")))
        driver.execute_script("arguments[0].click();", users_link)
        page_loaded(driver)
        time.sleep(PAUSE)
        except Exception:
        pass
        print(f"  [INFO] User List URL: {driver.current_url}")

        # Step 2: Search and select user
        print_step(2, f"Selecting user '{self.wc_user_id}'")
        try:
        sb = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((
                By.XPATH,
                "//input[contains(@name,'FindTextbox') or contains(@placeholder,'Find')]"
            ))
        )
        sb.clear()
        sb.send_keys(self.wc_user_id)
        time.sleep(PAUSE)
        except Exception:
        pass

        try:
        user_cell = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(text())='{self.wc_user_id}']"
            ))
        )
        scroll_to(driver, user_cell)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"  [PASS] User '{self.wc_user_id}' row selected")
        except Exception:
        print(f"  [WARN] Could not select user row")

        # Step 3: Click View toolbar button
        print_step(3, "Clicking 'View' toolbar button")
        view_selectors = [
            (By.XPATH, "//a[@title='View'] | //button[@title='View']"),
            (By.XPATH, "//a[normalize-space(.)='View'] | //button[normalize-space(.)='View']"),
            (By.XPATH, "//*[contains(@class,'btn') and contains(normalize-space(.),'View')]"),
        ]
        for by, sel in view_selectors:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((by, sel)))
        driver.execute_script("arguments[0].click();", btn)
        print("  [PASS] View button clicked")
        break
        except Exception:
        continue
        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("wc_user_view_page.png")

        # Step 4: Verify View page loaded
        print_step(4, "Verifying View User page")
        current_url = driver.current_url
        page_src = driver.page_source
        if "ViewBO" in current_url or self.wc_user_id in page_src:
        print(f"  [PASS] View User page loaded -> {current_url}")
        else:
        print(f"  [INFO] Current URL: {current_url}")

        # Step 5: Click Cancel to return
        print_step(5, "Clicking Cancel to return to User List")
        cancel_selectors = [
            (By.ID, "entryPGCancel"),
            (By.XPATH, "//a[contains(normalize-space(.),'Cancel')]"),
            (By.XPATH, "//button[contains(normalize-space(.),'Cancel')]"),
        ]
        for by, sel in cancel_selectors:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((by, sel)))
        driver.execute_script("arguments[0].click();", btn)
        print("  [PASS] Cancel clicked, returning to User List")
        break
        except Exception:
        continue
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] Returned to -> {driver.current_url}")

        # ========================================================================
        # PHASE 11: DISABLE AND ENABLE WORKCENTER USER
        # ========================================================================
    def test_11_disable_and_enable_workcenter_user(self, driver):
        """
        Disable the workcenter user and then re-enable:
        1. Search and select user row
        2. Click Disable button
        3. Confirm 'Yes' in modal dialog
        4. Switch to Disabled list (More Options > Show Disabled And Locked)
        5. Search and select the disabled user
        6. Click Enable button
        7. Confirm 'Yes' in modal dialog
        8. Verify user is back in Active list
        """
        print_header("PHASE 11: DISABLE AND ENABLE WORKCENTER USER")

        # --- DISABLE ---
        # Step 1: Select user row
        print_step(1, f"Selecting user '{self.wc_user_id}' for Disable")
        try:
        sb = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((
                By.XPATH,
                "//input[contains(@name,'FindTextbox') or contains(@placeholder,'Find')]"
            ))
        )
        sb.clear()
        sb.send_keys(self.wc_user_id)
        time.sleep(PAUSE)
        except Exception:
        pass

        try:
        user_cell = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(text())='{self.wc_user_id}']"
            ))
        )
        scroll_to(driver, user_cell)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"  [PASS] User row selected")
        except Exception:
        print(f"  [WARN] User row not found for disable")

        # Step 2: Click Disable button
        print_step(2, "Clicking 'Disable' button")
        disable_selectors = [
            (By.ID, "User_tbrDelete"),
            (By.XPATH, "//a[@title='Disable'] | //button[@title='Disable']"),
            (By.XPATH, "//a[normalize-space(.)='Disable'] | //button[normalize-space(.)='Disable']"),
            (By.XPATH, "//*[contains(@class,'btn') and contains(normalize-space(.),'Disable')]"),
        ]
        for by, sel in disable_selectors:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((by, sel)))
        driver.execute_script("arguments[0].click();", btn)
        print("  [PASS] Disable button clicked")
        break
        except Exception:
        continue
        time.sleep(PAUSE)

        # Step 3: Confirm 'Yes' in modal
        print_step(3, "Confirming Disable in modal dialog")
        try:
        modal = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id")))
        modal_text = modal.text.strip()
        print(f"  [INFO] Modal: '{modal_text[:150]}'")

        yes_btn = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[normalize-space(.)='Yes'] | "
                "//a[normalize-space(.)='Yes'] | "
                "//*[@id='Modal-modal-alert-id']//*[contains(normalize-space(.),'Yes')]"
            ))
        )
        driver.execute_script("arguments[0].click();", yes_btn)
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] User '{self.wc_user_id}' DISABLED")
        except Exception as e:
        print(f"  [WARN] Disable confirmation issue: {e}")

        driver.save_screenshot("wc_user_disabled.png")

        # --- ENABLE ---
        # Step 4: Click More Options > Show Disabled And Locked
        print_step(4, "Switching to Disabled User List")
        try:
        more_btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(normalize-space(.),'More Options')] | "
                "//a[contains(normalize-space(.),'More Options')]"
            ))
        )
        driver.execute_script("arguments[0].click();", more_btn)
        time.sleep(1)

        show_disabled = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Show Disabled And Locked'] | "
                "//li[normalize-space(.)='Show Disabled And Locked']"
            ))
        )
        driver.execute_script("arguments[0].click();", show_disabled)
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] Switched to Disabled list -> {driver.current_url}")
        except Exception:
        print("  [WARN] Could not switch to Disabled list")

        # Step 5: Search and select disabled user
        print_step(5, f"Selecting disabled user '{self.wc_user_id}'")
        try:
        sb = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((
                By.XPATH,
                "//input[contains(@name,'FindTextbox') or contains(@placeholder,'Find')]"
            ))
        )
        sb.clear()
        sb.send_keys(self.wc_user_id)
        time.sleep(PAUSE)
        except Exception:
        pass

        try:
        user_cell = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(text())='{self.wc_user_id}']"
            ))
        )
        scroll_to(driver, user_cell)
        driver.execute_script("arguments[0].click();", user_cell)
        time.sleep(PAUSE)
        print(f"  [PASS] Disabled user row selected")
        except Exception:
        print(f"  [WARN] Disabled user not found in list")

        # Step 6: Click Enable button
        print_step(6, "Clicking 'Enable' button")
        enable_selectors = [
            (By.XPATH, "//a[@title='Enable'] | //button[@title='Enable']"),
            (By.XPATH, "//a[normalize-space(.)='Enable'] | //button[normalize-space(.)='Enable']"),
            (By.ID, "User_tbrEnable"),
        ]
        for by, sel in enable_selectors:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((by, sel)))
        driver.execute_script("arguments[0].click();", btn)
        print("  [PASS] Enable button clicked")
        break
        except Exception:
        continue
        time.sleep(PAUSE)

        # Step 7: Confirm 'Yes' in modal
        print_step(7, "Confirming Enable in modal dialog")
        try:
        modal = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id")))
        modal_text = modal.text.strip()
        print(f"  [INFO] Modal: '{modal_text[:150]}'")

        yes_btn = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[normalize-space(.)='Yes'] | "
                "//a[normalize-space(.)='Yes'] | "
                "//*[@id='Modal-modal-alert-id']//*[contains(normalize-space(.),'Yes')]"
            ))
        )
        driver.execute_script("arguments[0].click();", yes_btn)
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] User '{self.wc_user_id}' RE-ENABLED")
        except Exception as e:
        print(f"  [WARN] Enable confirmation issue: {e}")

        driver.save_screenshot("wc_user_enabled.png")

        # Step 8: Switch back to Active list to verify
        print_step(8, "Verifying user is back in Active list")
        try:
        more_btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(normalize-space(.),'More Options')] | "
                "//a[contains(normalize-space(.),'More Options')]"
            ))
        )
        driver.execute_script("arguments[0].click();", more_btn)
        time.sleep(1)

        show_active = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((
                By.XPATH,
                "//a[normalize-space(.)='Show Active'] | "
                "//li[normalize-space(.)='Show Active']"
            ))
        )
        driver.execute_script("arguments[0].click();", show_active)
        page_loaded(driver)
        time.sleep(PAUSE)
        except Exception:
        pass

        # Check user in active list
        try:
        user_cell = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                f"//td[normalize-space(text())='{self.wc_user_id}']"
            ))
        )
        print(f"  [PASS] User '{self.wc_user_id}' is ACTIVE in User List")
        except Exception:
        if self.wc_user_id in driver.page_source:
        print(f"  [PASS] User '{self.wc_user_id}' found in page")
        else:
        print(f"  [WARN] Could not verify user in Active list")

        # ========================================================================
        # PHASE 12: GENERATE WORKCENTER USERS REPORT
        # ========================================================================
    def test_12_generate_workcenter_users_report(self, driver):
        """
        Generate a comprehensive report covering all Workcenter User
        operations: Add, Edit, View, Disable, Enable.
        """
        print_header("PHASE 12: WORKCENTER USERS REPORT")

        report = f"""
        ================================================================================
        WORKCENTER USERS TEST REPORT — {self.created_wc_name}
        ================================================================================
        Date/Time      : {time.strftime('%Y-%m-%d %H:%M:%S')}
        Test URL       : {BASE_URL}
        Admin User     : {USERNAME}
        Workcenter     : {self.created_wc_name}

        ================================================================================
        ADD USER DETAILS
        ================================================================================
        """
        for key, val in self.wc_user_fields.items():
        report += f"  {key:<20}: {val}\n"

        report += f"""
        ================================================================================
        EDIT USER — UPDATED VALUES
        ================================================================================
        """
        for key, val in self.wc_user_edit_fields.items():
        report += f"  {key:<20}: {val}\n"

        report += f"""
        ================================================================================
        OPERATIONS PERFORMED
        ================================================================================
        Phase 6  : Navigate to Workcenter List > Select '{self.created_wc_name}'
        > More Options > Users
        Phase 7  : Add New User '{self.wc_user_id}' — fill all mandatory fields
        (First Name, Last Name, Phone, Email, Login, Account Type,
        Password) and Save
        Phase 8  : Verify user '{self.wc_user_id}' appears in Workcenter User List
        Phase 9  : Edit user — update First Name, Work Phone, Buyer Code and Save
        Phase 10 : View user in read-only mode and click Cancel
        Phase 11 : Disable user → confirm → Enable user → confirm
        → verify user is Active again
        Phase 12 : Generate this report

        CURRENT URL: {driver.current_url}
        ================================================================================
        """
        print(report)

        os.makedirs(REPORT_DIR, exist_ok=True)
        report_path = os.path.join(
            REPORT_DIR,
            f"Workcenter_Users_{self.created_wc_name}.txt"
        )
        try:
        with open(report_path, "w") as f:
        f.write(report)
        print(f"  [PASS] Workcenter Users report saved: {report_path}")
        except Exception as e:
        print(f"  [WARN] Report save error: {e}")

        driver.save_screenshot("wc_users_report_final.png")
        print(
            "  [DONE] Workcenter Users test complete (Add/Edit/View/Disable/Enable).")

        # ========================================================================
        # PHASE 13: PRODUCTION SEQUENCE CONFIG — SCHEDULE TAB
        # ========================================================================
    def test_13_update_schedule_config(self, driver):
        """
        Navigate to Production Sequence Configuration for the workcenter,
        update Available Production Hours and Schedule Offset on the
        Schedule tab, then click Save.
        """
        print_header("PHASE 13: PRODUCTION SEQUENCE CONFIG — SCHEDULE TAB")

        # Step 0: Ensure logged in (needed when running this test standalone)
        self._ensure_logged_in(driver)

        # Step 1: Navigate to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        # Check if redirected to login
        if "Account/Login" in driver.current_url:
        self._ensure_logged_in(driver)
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [INFO] Workcenter list URL: {driver.current_url}")

        # Step 2: Search for the created workcenter
        print_step(2, f"Searching for '{self.created_wc_name}'")
        try:
        find_field = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((
                By.XPATH,
                "//input[contains(@placeholder,'Find Name') or contains(@id,'Find')]"
            ))
        )
        find_field.clear()
        find_field.send_keys(self.created_wc_name)
        time.sleep(0.5)
        try:
        safe_click(driver, By.XPATH,
                   "//img[contains(@src,'find') or contains(@alt,'Find')] | "
                   "//a[contains(@onclick,'Find')]", timeout=3)
        except Exception:
        find_field.send_keys(Keys.RETURN)
        print(f"  [PASS] Searched for '{self.created_wc_name}'")
        except Exception:
        print("  [INFO] Find field not found, looking in list directly")
        time.sleep(PAUSE)

        # Step 3: Select workcenter row
        print_step(3, f"Selecting '{self.created_wc_name}' row")
        row_selected = False
        row_xpaths = [
            f"//tr[.//td[contains(normalize-space(.),'{self.created_wc_name}')]]",
            f"//td[contains(normalize-space(.),'{self.created_wc_name}')]",
        ]
        for xpath in row_xpaths:
        try:
        row = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, xpath)))
        scroll_to(driver, row)
        row.click()
        time.sleep(1)
        row_selected = True
        print(f"  [PASS] '{self.created_wc_name}' row selected")
        break
        except Exception:
        continue

        if not row_selected:
            # Fallback: select the first data row in the Workcenter grid
        print("  [INFO] Created WC not found, selecting first available data row")
        try:
        wc_name = driver.execute_script("""
        var grid = document.getElementById('Workcenter');
        if (!grid) return null;
        var rows = grid.querySelectorAll('tbody tr.DataRow, tbody tr.AltDataRow');
        if (rows.length > 0) { rows[0].click(); return rows[0].cells[0].textContent.trim(); }
        return null;
        """)
        if wc_name:
        row_selected = True
        print(f"  [PASS] First workcenter row selected: '{wc_name}'")
        else:
        print("  [WARN] No data rows in Workcenter grid")
        except Exception:
        print("  [WARN] Could not select any workcenter row")

        # Step 4: Click 'More Options' > 'Production Sequence Configuration'
        print_step(4, "Clicking 'More Options' dropdown")
        try:
        more_btn = driver.find_element(By.ID, "Workcenter_tbrMoreActions")
        scroll_to(driver, more_btn)
        more_btn.click()
        print("  [PASS] 'More Options' dropdown clicked")
        except Exception:
            # Fallback to XPATH
        for sel in [
            "//a[contains(normalize-space(.),'More Options')]",
            "//button[contains(normalize-space(.),'More Options')]",
        ]:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        print("  [PASS] 'More Options' dropdown clicked (xpath)")
        break
        except Exception:
        continue
        time.sleep(1)

        # Step 5: Click 'Production Sequence Configuration' link
        print_step(5, "Clicking 'Production Sequence Configuration'")
        psc_selectors = [
            "//*[contains(@class,'dropdown-menu')]//a[contains(normalize-space(.),'Production Sequence')]",
            "//ul[contains(@class,'dropdown-menu')]//a[contains(normalize-space(.),'Production Sequence')]",
            "//a[contains(normalize-space(.),'Production Sequence Configuration')]",
        ]
        psc_clicked = False
        for sel in psc_selectors:
        try:
        link = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        href = link.get_attribute("href") or ""
        print(f"  [INFO] Found PSC link href={href}")
        driver.execute_script("arguments[0].click();", link)
        psc_clicked = True
        print("  [PASS] 'Production Sequence Configuration' clicked")
        break
        except Exception:
        continue

        if not psc_clicked:
            # JS fallback: navigate directly via href
        result = driver.execute_script("""
        var links = document.querySelectorAll('a');
        for (var i = 0; i < links.length; i++) {
        if (links[i].textContent.indexOf('Production Sequence') >= 0 && links[i].href) {
        window.location.href = links[i].href;
        return links[i].href;
        }
        }
        return 'not-found';
        """)
        if result != 'not-found':
        psc_clicked = True
        print(f"  [PASS] PSC navigated via JS: {result}")
        else:
            # Last resort: navigate directly
        driver.get(f"{BASE_URL}/ScheduleConfig/Setup")
        psc_clicked = True
        print("  [INFO] Navigated directly to ScheduleConfig/Setup")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("psc_schedule_page.png")
        print(f"  [INFO] Production Sequence Config URL: {driver.current_url}")

        # Step 6: Set Available Production Hours (field
        # id=SCHCONFIG_CapacityPerDay)
        prod_hours = random.randint(4, 12)
        print_step(6, f"Setting Available Production Hours: {prod_hours}")
        hours_filled = False
        hours_selectors = [
            (By.ID, "SCHCONFIG_CapacityPerDay"),
            (By.XPATH, "//input[contains(@name,'CapacityPerDay')]"),
            (By.XPATH, "//input[contains(@id,'CapacityPerDay')]"),
        ]
        for by, sel in hours_selectors:
        try:
        field = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((by, sel)))
        scroll_to(driver, field)
        field.clear()
        field.send_keys(str(prod_hours))
        hours_filled = True
        print(f"  [PASS] Available Production Hours = {prod_hours}")
        break
        except Exception:
        continue

        if not hours_filled:
            # JS fallback: set value directly
        try:
        result = driver.execute_script("""
        var field = document.getElementById('SCHCONFIG_CapacityPerDay');
        if (field) {
        field.value = '';
        field.value = arguments[0];
        field.dispatchEvent(new Event('change', {bubbles: true}));
        field.dispatchEvent(new Event('input', {bubbles: true}));
        return true;
        }
        return false;
        """, str(prod_hours))
        if result:
        hours_filled = True
        print(
            f"  [PASS] Available Production Hours = {prod_hours} (JS fallback)")
        else:
        print("  [WARN] Could not fill Available Production Hours")
        except Exception:
        print("  [WARN] Could not fill Available Production Hours")

        # Step 7: Set Schedule Offset (field id=SCHCONFIG_ScheduleOffset)
        sched_offset = random.randint(1, 7)
        print_step(7, f"Setting Schedule Offset: {sched_offset}")
        offset_filled = False
        offset_selectors = [
            (By.ID, "SCHCONFIG_ScheduleOffset"),
            (By.XPATH, "//input[contains(@name,'ScheduleOffset')]"),
            (By.XPATH, "//input[contains(@id,'ScheduleOffset')]"),
        ]
        for by, sel in offset_selectors:
        try:
        field = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((by, sel)))
        scroll_to(driver, field)
        field.clear()
        field.send_keys(str(sched_offset))
        offset_filled = True
        print(f"  [PASS] Schedule Offset = {sched_offset}")
        break
        except Exception:
        continue

        if not offset_filled:
        print("  [WARN] Could not fill Schedule Offset")

        driver.save_screenshot("psc_schedule_fields_filled.png")

        # Step 8: Click Save
        print_step(8, "Clicking Save button")
        # Scroll to bottom to make Save button visible
        driver.execute_script(
            "window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)
        # PSC page uses <span id="btnSaveSchedule"
        # onclick="onSaveBtnClick(event);">
        save_clicked = False
        try:
        save_btn = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, "btnSaveSchedule")))
        scroll_to(driver, save_btn)
        driver.execute_script("arguments[0].click();", save_btn)
        save_clicked = True
        print("  [PASS] Save button clicked (btnSaveSchedule)")
        except Exception:
        pass

        if not save_clicked:
            # Fallback: call the onclick JS function directly
        try:
        driver.execute_script("onSaveBtnClick(new Event('click'));")
        save_clicked = True
        print("  [PASS] Save triggered via onSaveBtnClick()")
        except Exception:
            # Last fallback: generic _click_save
        self._click_save(driver)
        time.sleep(PAUSE)
        page_loaded(driver)
        driver.save_screenshot("psc_schedule_saved.png")

        current_url = driver.current_url
        print(f"  [PASS] Schedule config saved -> {current_url}")
        print(
            f"  [SUMMARY] Available Production Hours={prod_hours}, Schedule Offset={sched_offset}")

        # ========================================================================
        # PHASE 14: SHIPPING RULES
        # ========================================================================
    def test_14_add_shipping_rule(self, driver):
        """
        Add a shipping rule to the created workcenter:
        1. Navigate to Workcenter list and search for the created WC
        2. Select workcenter row
        3. Click More Options > Shipping Rules
        4. Click '+ Add Shipping Rule'
        5. Select 'Week:If release day is after the day (Default)' rule
        6. Click 'Select' to load rule description
        7. Click 'ReleaseDay' link → set day & time → Apply
        8. Click 'ShipDate' link → set week, day & time → Apply
        9. Click Save
        """
        print_header("PHASE 14: SHIPPING RULES")

        # Step 0: Ensure logged in (needed when running standalone)
        self._ensure_logged_in(driver)

        # Step 1: Navigate to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        if "Account/Login" in driver.current_url:
        safe_fill(driver, By.ID, "UserName", USERNAME)
        safe_fill(driver, By.ID, "Password", PASSWORD)
        safe_click(driver, By.ID, "login-button")
        page_loaded(driver)
        time.sleep(PAUSE)
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [INFO] Workcenter list URL: {driver.current_url}")

        # Step 2: Search and select workcenter row
        print_step(2, f"Searching for '{self.created_wc_name}'")
        try:
        find_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, "//input[@name='txtFindField' or @placeholder='Find Name']")))
        find_box.clear()
        find_box.send_keys(self.created_wc_name)
        find_box.send_keys(Keys.RETURN)
        page_loaded(driver)
        time.sleep(PAUSE)
        except Exception:
        print("  [WARN] Find box not available, will search grid directly")
        time.sleep(PAUSE)

        # Step 3: Select the workcenter data row
        print_step(3, f"Selecting '{self.created_wc_name}' row")
        row_selected = False
        # Try JS click on matching DataRow/AltDataRow
        try:
        result = driver.execute_script(f"""
        var grid = document.getElementById('Workcenter');
        if (!grid) return 'no grid';
        var rows = grid.querySelectorAll('tbody tr.DataRow, tbody tr.AltDataRow');
        for (var i = 0; i < rows.length; i++) {{
        var name = rows[i].cells[0].textContent.trim();
        if (name === '{self.created_wc_name}') {{
        rows[i].click();
        return 'found: ' + name;
        }}
        }}
        // Fallback: click first data row
        if (rows.length > 0) {{
        rows[0].click();
        return 'fallback: ' + rows[0].cells[0].textContent.trim();
        }}
        return 'no rows';
        """)
        if result and result.startswith(("found:", "fallback:")):
        row_selected = True
        print(f"  [INFO] Row selected: {result}")
        except Exception as e:
        print(f"  [WARN] JS row select error: {e}")

        if not row_selected:
        try:
        cell = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(
            (By.XPATH, f"//td[normalize-space(text())='{self.created_wc_name}']")))
        cell.click()
        row_selected = True
        except Exception:
        pass

        if not row_selected:
        try:
        first_row = driver.find_element(
            By.CSS_SELECTOR,
            "table#Workcenter tbody tr.DataRow, table#Workcenter tbody tr.AltDataRow")
        first_row.click()
        row_selected = True
        print("  [WARN] Selected first data row as fallback")
        except Exception:
        print("  [WARN] Could not select any workcenter row")
        time.sleep(1)

        # Step 4: Click More Options > Shipping Rules
        print_step(4, "Clicking More Options > Shipping Rules")
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        time.sleep(1)
        except Exception:
        safe_click(driver, By.ID, "Workcenter_tbrMoreActions")
        time.sleep(1)

        # Click "Shipping Rules" from the dropdown
        sr_clicked = False
        try:
        driver.execute_script("""
        var items = document.querySelectorAll('li');
        for (var i = 0; i < items.length; i++) {
        if (items[i].textContent.trim() === 'Shipping Rules') {
        items[i].click(); return;
        }
        }
        """)
        sr_clicked = True
        except Exception:
        pass

        if not sr_clicked:
        try:
        sr_link = WebDriverWait(
            driver, 5).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//li[normalize-space(.)='Shipping Rules']")))
        driver.execute_script("arguments[0].click();", sr_link)
        except Exception:
        print("  [WARN] Could not click Shipping Rules dropdown item")

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        print(f"  [INFO] Shipping Rules page: {driver.current_url}")
        driver.save_screenshot("sr_shipping_rules_page.png")

        # Step 5: Click '+ Add Shipping Rule'
        print_step(5, "Clicking 'Add Shipping Rule' button")
        # Extract the goPage URL from the Add Shipping Rule button's onclick
        add_url = driver.execute_script("""
        var el = document.querySelector('span[id*="ADDSHIPPINGRULE"]');
        if (el) {
        var oc = el.getAttribute('onclick') || '';
        var m = oc.match(/goPage\\('([^']+)'/);
        if (m) return m[1];
        }
        return null;
        """)
        if add_url:
            # Navigate directly using the extracted URL
        full_url = f"https://engineering.ultrivalms.com{add_url}"
        driver.get(full_url)
        print(f"  [PASS] Navigated to Add Shipping Rule via goPage URL")
        else:
            # Fallback: build URL from current ShippingRule page GID
        current = driver.current_url
        if "GID=" in current:
        gid = current.split("GID=")[1].split("&")[0]
        driver.get(f"{BASE_URL}/ShippingRule/WorkcenterSave?GID={gid}")
        print(f"  [PASS] Navigated to Add Shipping Rule via GID")
        else:
            # Last resort: click the button
        driver.execute_script("""
        var el = document.querySelector('span[id*="ADDSHIPPINGRULE"]');
        if (el) el.click();
        """)
        page_loaded(driver)
        time.sleep(PAUSE + 1)
        print(f"  [INFO] Add Shipping Rule page: {driver.current_url}")
        driver.save_screenshot("sr_add_page.png")

        # Step 6: Select 'Week:If release day is after the day (Default)'
        print_step(6, "Selecting shipping rule from list")
        try:
        rule_select = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "WIZARD_TemplateGID")))
        sel = Select(rule_select)
        sel.select_by_value("RULT00013")
        print("  [PASS] Selected: Week:If release day is after the day (Default)")
        except Exception:
            # Fallback: JS
        try:
        driver.execute_script("""
        var s = document.getElementById('WIZARD_TemplateGID');
        for (var j = 0; j < s.options.length; j++) {
        if (s.options[j].value === 'RULT00013') {
        s.selectedIndex = j; break;
        }
        }
        """)
        print("  [PASS] Selected rule via JS fallback")
        except Exception as e:
        print(f"  [WARN] Could not select rule: {e}")
        time.sleep(1)

        # Step 7: Click 'Select' button
        print_step(7, "Clicking 'Select' button to load rule description")
        try:
        driver.execute_script("selectShipRule('N','0');")
        print("  [PASS] selectShipRule() called")
        except Exception:
            # Fallback: click span with text 'Select'
        try:
        driver.execute_script("""
        var btns = document.querySelectorAll('span, a, button');
        for (var i = 0; i < btns.length; i++) {
        var t = btns[i].textContent.trim();
        if (t === 'Select' && btns[i].getAttribute('onclick')) {
        btns[i].click(); return;
        }
        }
        """)
        except Exception:
        pass
        time.sleep(PAUSE + 1)
        driver.save_screenshot("sr_rule_selected.png")

        # Verify rule description loaded
        rule_html = driver.execute_script(
            "var el = document.getElementById('ruleHtml'); return el ? el.innerHTML : '';")
        if "ReleaseDay" in rule_html:
        print("  [PASS] Rule description loaded with ReleaseDay link")
        else:
        print(f"  [WARN] Rule description: {rule_html[:200]}")

        # Step 8: Click 'ReleaseDay' link → set day & time → Apply
        print_step(8, "Filling ReleaseDay mandatory data")
        try:
            # Click the ReleaseDay link in the rule description
        rd_link = WebDriverWait(
            driver, 10).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//a[normalize-space(.)='ReleaseDay']")))
        driver.execute_script("arguments[0].click();", rd_link)
        time.sleep(PAUSE)

        # Wait for dialog
        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "dlgValueDialog")))

        # Set day = Monday (value=2)
        day_select = driver.find_element(By.ID, "WIZARD_ReleaseDay1")
        Select(day_select).select_by_value("2")
        print("  [INFO] ReleaseDay: Monday")

        # Set time = 08:00
        time_input = driver.find_element(By.ID, "WIZARD_ReleaseTime1")
        time_input.clear()
        time_input.send_keys("08:00")
        print("  [INFO] ReleaseTime: 08:00")

        # Click Apply
        driver.execute_script("applyValue();")
        time.sleep(PAUSE)
        print("  [PASS] ReleaseDay applied")
        except Exception as e:
        print(f"  [WARN] ReleaseDay dialog error: {e}")
        driver.save_screenshot("sr_releaseday_applied.png")

        # Step 9: Click 'ShipDate' link → set week, day & time → Apply
        print_step(9, "Filling ShipDate mandatory data")
        try:
            # Click the ShipDate link in the rule description
        sd_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH,
                                        "//a[normalize-space(.)='ShipDate']")))
        driver.execute_script("arguments[0].click();", sd_link)
        time.sleep(PAUSE)

        # Wait for dialog
        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "dlgValueDialog")))

        # Set week = Next Week (value=1)
        week_select = driver.find_element(By.ID, "WIZARD_ShipWeek")
        Select(week_select).select_by_value("1")
        print("  [INFO] ShipWeek: Next Week")

        # Set day = Wednesday (value=4)
        ship_day_select = driver.find_element(By.ID, "WIZARD_ShipDay")
        Select(ship_day_select).select_by_value("4")
        print("  [INFO] ShipDay: Wednesday")

        # Set time = 10:00
        ship_time = driver.find_element(By.ID, "WIZARD_ShipTime")
        ship_time.clear()
        ship_time.send_keys("10:00")
        print("  [INFO] ShipTime: 10:00")

        # Click Apply
        driver.execute_script("applyValue();")
        time.sleep(PAUSE)
        print("  [PASS] ShipDate applied")
        except Exception as e:
        print(f"  [WARN] ShipDate dialog error: {e}")
        driver.save_screenshot("sr_shipdate_applied.png")

        # Step 10: Click Save
        print_step(10, "Clicking Save")
        try:
        driver.execute_script("return rulesubmit();")
        print("  [PASS] rulesubmit() called")
        except Exception:
            # Fallback: click entryPGSubmit span
        try:
        save_btn = driver.find_element(By.ID, "entryPGSubmit")
        driver.execute_script("arguments[0].click();", save_btn)
        print("  [PASS] Save button clicked (entryPGSubmit)")
        except Exception:
        self._click_save(driver)

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        driver.save_screenshot("sr_saved.png")

        current_url = driver.current_url
        print(f"  [PASS] Shipping rule saved -> {current_url}")
        print("  [SUMMARY] Rule: Week:If release day is after the day (Default)")
        print("            ReleaseDay=Monday 08:00, ShipDate=Next Week Wednesday 10:00")

        # ========================================================================
        # PHASE 15: PRINT SHIPPING RULES
        # ========================================================================
    def test_15_print_shipping_rules(self, driver):
        """Print shipping rules list and verify print page data."""
        print_header("PHASE 15: PRINT SHIPPING RULES")
        self._ensure_logged_in(driver)
        self._nav_to_sr_list(driver)

        # Step 1: Click Print link (opens new window with ?tgt=prn)
        print_step(1, "Clicking 'Print' link")
        main_win = driver.current_window_handle
        print_link = WebDriverWait(driver, 10).until(EC.element_to_be_clickable(
            (By.XPATH, "//a[contains(@href,'tgt=prn') and contains(.,'Print')]")))
        driver.execute_script("arguments[0].click();", print_link)
        time.sleep(PAUSE + 1)

        # Step 2: Switch to print window
        print_step(2, "Switching to print window")
        all_wins = driver.window_handles
        print_win = [w for w in all_wins if w != main_win]
        if print_win:
        driver.switch_to.window(print_win[0])
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] Print window opened: {driver.current_url}")
        else:
        print("  [WARN] No new print window detected")

        # Step 3: Verify print data contains shipping rule text
        print_step(3, "Checking print page data")
        src = driver.page_source
        if "Shipping Rule" in src or "Schedule Condition" in src:
        print("  [PASS] Print page contains shipping rule data")
        else:
        print("  [WARN] Print page missing expected data")
        driver.save_screenshot("sr_print_page.png")

        # Step 4: Close print window, switch back
        print_step(4, "Closing print window")
        if print_win:
        driver.close()
        driver.switch_to.window(main_win)
        time.sleep(1)
        print("  [PASS] Print window closed, returned to main")

        # ========================================================================
        # PHASE 16: EXPORT SHIPPING RULES TO EXCEL
        # ========================================================================
    def test_16_export_shipping_rules(self, driver):
        """Export shipping rules to Excel and verify download triggers."""
        print_header("PHASE 16: EXPORT SHIPPING RULES TO EXCEL")
        self._ensure_logged_in(driver)
        self._nav_to_sr_list(driver)

        # Step 1: Click Export link (?tgt=xl)
        print_step(1, "Clicking 'Export' link")
        export_link = WebDriverWait(driver, 10).until(EC.element_to_be_clickable(
            (By.XPATH, "//a[contains(@href,'tgt=xl') and contains(.,'Export')]")))
        export_href = export_link.get_attribute("href")
        print(f"  [INFO] Export URL: {export_href}")
        driver.execute_script("arguments[0].click();", export_link)
        time.sleep(PAUSE + 1)

        # Step 2: Verify export URL contains expected params
        print_step(2, "Verifying export data")
        if "tgt=xl" in (export_href or ""):
        print("  [PASS] Export link targets Excel format (?tgt=xl)")
        else:
        print("  [WARN] Export URL missing tgt=xl param")
        driver.save_screenshot("sr_export_done.png")
        print("  [PASS] Export to Excel triggered successfully")

        # ========================================================================
        # PHASE 17: MOVE UP SHIPPING RULE
        # ========================================================================
    def test_17_move_up_shipping_rule(self, driver):
        """Select a non-first rule and move it up."""
        print_header("PHASE 17: MOVE UP SHIPPING RULE")
        self._ensure_logged_in(driver)
        self._nav_to_sr_list(driver)

        # Step 1: Get all rule rows
        print_step(1, "Getting rule rows from grid")
        rows = driver.find_elements(
            By.CSS_SELECTOR,
            "#ShippingRule tr.DataRow, #ShippingRule tr.AltDataRow")
        count = len(rows)
        print(f"  [INFO] Total rules: {count}")

        if count < 2:
        print("  [SKIP] Less than 2 rules — cannot test Move Up")
        return

        # Step 2: Select 2nd row (non-first)
        print_step(2, "Selecting 2nd rule row")
        scroll_to(driver, rows[1])
        driver.execute_script("arguments[0].click();", rows[1])
        time.sleep(1)
        row_text = rows[1].text.strip()[:80]
        print(f"  [INFO] Selected row: {row_text}")

        # Step 3: Click Move Up
        print_step(3, "Clicking 'Move Up' button")
        safe_click(driver, By.ID, "ShippingRule_tbrMoveUp")
        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("sr_move_up_done.png")
        print("  [PASS] Move Up clicked — rule order updated")

        # ========================================================================
        # PHASE 18: MOVE DOWN SHIPPING RULE
        # ========================================================================
    def test_18_move_down_shipping_rule(self, driver):
        """Select a non-last rule and move it down."""
        print_header("PHASE 18: MOVE DOWN SHIPPING RULE")
        self._ensure_logged_in(driver)
        self._nav_to_sr_list(driver)

        # Step 1: Get all rule rows
        print_step(1, "Getting rule rows from grid")
        rows = driver.find_elements(
            By.CSS_SELECTOR,
            "#ShippingRule tr.DataRow, #ShippingRule tr.AltDataRow")
        count = len(rows)
        print(f"  [INFO] Total rules: {count}")

        if count < 2:
        print("  [SKIP] Less than 2 rules — cannot test Move Down")
        return

        # Step 2: Select 1st row (non-last)
        print_step(2, "Selecting 1st rule row")
        scroll_to(driver, rows[0])
        driver.execute_script("arguments[0].click();", rows[0])
        time.sleep(1)
        row_text = rows[0].text.strip()[:80]
        print(f"  [INFO] Selected row: {row_text}")

        # Step 3: Click Move Down
        print_step(3, "Clicking 'Move Down' button")
        safe_click(driver, By.ID, "ShippingRule_tbrMoveDown")
        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("sr_move_down_done.png")
        print("  [PASS] Move Down clicked — rule order updated")

        # ========================================================================
        # PHASE 19: DELETE SHIPPING RULE
        # ========================================================================
    def test_19_delete_shipping_rule(self, driver):
        """Select a rule, click Delete, confirm Yes in popup."""
        print_header("PHASE 19: DELETE SHIPPING RULE")
        self._ensure_logged_in(driver)
        self._nav_to_sr_list(driver)

        # Step 1: Get rule rows
        print_step(1, "Getting rule rows from grid")
        rows = driver.find_elements(
            By.CSS_SELECTOR,
            "#ShippingRule tr.DataRow, #ShippingRule tr.AltDataRow")
        count_before = len(rows)
        print(f"  [INFO] Rules before delete: {count_before}")

        if count_before == 0:
        print("  [SKIP] No rules to delete")
        return

        # Step 2: Select last rule row
        print_step(2, "Selecting last rule row")
        last_row = rows[-1]
        scroll_to(driver, last_row)
        driver.execute_script("arguments[0].click();", last_row)
        time.sleep(1)
        print(f"  [INFO] Selected row: {last_row.text.strip()[:80]}")

        # Step 3: Click Delete button
        print_step(3, "Clicking 'Delete' button")
        safe_click(driver, By.ID, "ShippingRule_tbrDelete")
        time.sleep(PAUSE)

        # Step 4: Confirm 'Yes' in "Do you want to delete this Shipping Rule?"
        # popup
        print_step(4, "Confirming delete in popup")
        try:
        modal = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id")))
        print(f"  [INFO] Modal: {modal.text.strip()[:100]}")

        # Yes button is <span class="modal-save-btn"> with text "Yes"
        yes_btn = modal.find_element(By.CSS_SELECTOR, "span.modal-save-btn")
        driver.execute_script("arguments[0].click();", yes_btn)
        page_loaded(driver)
        time.sleep(PAUSE)
        print("  [PASS] Delete confirmed — Yes clicked")
        except Exception as e:
        print(f"  [WARN] Delete confirmation error: {e}")

        # Step 5: Verify rule count decreased
        print_step(5, "Verifying rule deleted")
        rows_after = driver.find_elements(
            By.CSS_SELECTOR,
            "#ShippingRule tr.DataRow, #ShippingRule tr.AltDataRow")
        count_after = len(rows_after)
        print(f"  [INFO] Rules after delete: {count_after}")
        if count_after < count_before:
        print("  [PASS] Shipping rule deleted successfully")
        else:
        print("  [WARN] Rule count unchanged — delete may not have worked")
        driver.save_screenshot("sr_delete_done.png")

        # ========================================================================
        # SHARED: CLICK SAVE
        # ========================================================================
        def _ensure_logged_in(self, driver):
        """If the browser is not logged in, perform login."""
        # Navigate to BASE_URL first to get a real page
        current = driver.current_url
        if current in ("about:blank", "data:,", ""):
        driver.get(BASE_URL)
        page_loaded(driver)
        time.sleep(PAUSE)

        # Check if login form is present (UserName field visible)
        needs_login = False
        try:
        driver.find_element(By.ID, "UserName")
        needs_login = True
        except Exception:
        pass

        if not needs_login and "Account/Login" in driver.current_url:
        needs_login = True

        if needs_login:
        print("  [INFO] Not logged in — performing login")
        if "Account/Login" not in driver.current_url:
        driver.get(BASE_URL)
        page_loaded(driver)
        time.sleep(1)
        try:
        safe_fill(driver, By.ID, "UserName", USERNAME)
        safe_fill(driver, By.ID, "Password", PASSWORD)
        safe_click(driver, By.ID, "login-button")
        page_loaded(driver)
        time.sleep(PAUSE)
        print(f"  [PASS] Login successful -> {driver.current_url}")
        except Exception as e:
        print(f"  [WARN] Login failed: {e}")
        else:
        print(f"  [INFO] Already logged in -> {driver.current_url}")

        def _click_save(self, driver):
        """Click the Save button on the form."""
        save_selectors = [
            "//input[@type='submit' and contains(@value,'Save')]",
            "//button[contains(normalize-space(.),'Save')]",
            "//a[contains(normalize-space(.),'Save') and contains(@class,'btn')]",
            "//input[@type='button' and contains(@value,'Save')]",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Save')]",
        ]

        saved = False
        for sel in save_selectors:
        try:
        btn = WebDriverWait(
            driver, 8).until(
            EC.element_to_be_clickable(
                (By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        saved = True
        print("  [PASS] Save button clicked")
        break
        except Exception:
        continue

        if not saved:
            # JS fallback
        try:
        driver.execute_script("""
        var els = document.querySelectorAll('a, button, input[type=submit], input[type=button]');
        for (var i = 0; i < els.length; i++) {
        if (els[i].textContent.trim().indexOf('Save') >= 0 ||
        (els[i].value && els[i].value.indexOf('Save') >= 0)) {
        if (els[i].offsetParent !== null) { els[i].click(); break; }
        }
        }
        """)
        saved = True
        print("  [PASS] Save triggered via JS")
        except Exception:
        try:
        driver.execute_script("document.forms[0].submit();")
        saved = True
        print("  [PASS] Save via form.submit()")
        except Exception:
        print("  [WARN] No Save mechanism found")

        if saved:
        try:
        WebDriverWait(driver, 30).until(lambda d: d.execute_script(
            "return document.readyState") == "complete")
        except Exception:
        pass
        time.sleep(3)

        def _nav_to_sr_list(self, driver):
        """Navigate to Shipping Rules list for the created workcenter."""
        # Go to WC list → select row → More Options → Shipping Rules
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        if "Account/Login" in driver.current_url:
        self._ensure_logged_in(driver)
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Search & select WC row
        try:
        find_box = WebDriverWait(driver, 5).until(EC.visibility_of_element_located(
            (By.XPATH, "//input[contains(@placeholder,'Find Name') or contains(@id,'Find')]")))
        find_box.clear()
        find_box.send_keys(self.created_wc_name)
        time.sleep(1)
        except Exception:
        pass

        try:
        row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, f"//td[contains(normalize-space(.),'{self.created_wc_name}')]")))
        driver.execute_script("arguments[0].click();", row)
        time.sleep(1)
        except Exception:
            # Click first data row as fallback
        driver.execute_script("""
        var r = document.querySelector('#Workcenter tr.DataRow, #Workcenter tr.AltDataRow');
        if (r) r.click();
        """)
        time.sleep(1)

        # More Options → Shipping Rules
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        time.sleep(1)
        except Exception:
        safe_click(
            driver,
            By.XPATH,
            "//button[contains(.,'More Options')] | //a[contains(.,'More Options')]")
        time.sleep(1)

        try:
        driver.execute_script("""
        var items = document.querySelectorAll('li');
        for (var i = 0; i < items.length; i++) {
        if (items[i].textContent.trim() === 'Shipping Rules') {
        items[i].click(); return;
        }
        }
        """)
        except Exception:
        safe_click(driver, By.XPATH,
                   "//li[normalize-space(.)='Shipping Rules']")

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        print(f"  [INFO] SR list page: {driver.current_url}")

        # ------------------------------------------------------------------
        # Helper: Navigate to RYG Rules list for the created workcenter
        # WC list → select row → More Options → RYG Rules
        # ------------------------------------------------------------------
        def _nav_to_ryg_list(self, driver):
        """Go to WC list → select created WC → More Options → RYG Rules."""
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        if "Account/Login" in driver.current_url:
        self._ensure_logged_in(driver)
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Search for workcenter
        try:
        find_box = WebDriverWait(driver, 5).until(EC.visibility_of_element_located(
            (By.XPATH, "//input[contains(@placeholder,'Find Name') or contains(@id,'Find')]")))
        find_box.clear()
        find_box.send_keys(self.created_wc_name)
        time.sleep(1)
        except Exception:
        pass

        # Select WC row
        try:
        row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, f"//td[contains(normalize-space(.),'{self.created_wc_name}')]")))
        driver.execute_script("arguments[0].click();", row)
        time.sleep(1)
        except Exception:
            # Fallback: click first data row
        driver.execute_script("""
        var r = document.querySelector('#Workcenter tr.DataRow, #Workcenter tr.AltDataRow');
        if (r) r.click();
        """)
        time.sleep(1)

        # More Options dropdown
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        time.sleep(1)
        except Exception:
        safe_click(
            driver,
            By.XPATH,
            "//button[contains(.,'More Options')] | //a[contains(.,'More Options')]")
        time.sleep(1)

        # Click 'RYG Rules' from dropdown
        try:
        driver.execute_script("""
        var items = document.querySelectorAll('li a, li');
        for (var i = 0; i < items.length; i++) {
        var t = items[i].textContent.trim();
        if (t === 'RYG Rules' || t === 'RYG Rule') {
        items[i].click(); return;
        }
        }
        """)
        except Exception:
        safe_click(driver, By.XPATH,
                   "//li[contains(normalize-space(.),'RYG Rule')]")

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        print(f"  [INFO] RYG Rules page: {driver.current_url}")

        # ====================================================================
        # PHASE 20: ADD RYG RULE
        # ====================================================================
    def test_20_add_ryg_rule(self, driver):
        """
        RYG Rule — Add a new RYG rule to the created workcenter:
        1. Navigate to WC list → search WC → select row
        2. More Options → RYG Rules
        3. Click '+ Add' to open Add RYG Rule form
        4. Select any available rule from the rule dropdown
        5. Fill mandatory fields (values, thresholds)
        6. Click Save
        """
        print_header("PHASE 20: ADD RYG RULE")

        # Step 0: RYG Rule — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: RYG Rule — Navigate to RYG Rules list
        print_step(1, "Navigating to RYG Rules list")
        self._nav_to_ryg_list(driver)
        driver.save_screenshot("ryg_rules_list.png")

        # Step 2: RYG Rule — Click '+ Add' button
        print_step(2, "Clicking '+ Add' button")
        add_clicked = False

        # Try span/button with id containing 'ADD' or 'Add'
        add_url = driver.execute_script("""
        var el = document.querySelector(
        'span[id*="ADDRYG"], span[id*="AddRYG"], span[id*="ADD"]');
        if (el) {
        var oc = el.getAttribute('onclick') || '';
        var m = oc.match(/goPage\\('([^']+)'/);
        if (m) return m[1];
        el.click();
        return 'clicked';
        }
        return null;
        """)
        if add_url and add_url != 'clicked':
            # RYG Rule — Navigate via extracted goPage URL
        full_url = f"https://engineering.ultrivalms.com{add_url}"
        driver.get(full_url)
        add_clicked = True
        print(f"  [PASS] Navigated to Add RYG Rule via goPage URL")
        elif add_url == 'clicked':
        add_clicked = True
        print("  [PASS] Add button clicked via JS")

        if not add_clicked:
            # RYG Rule — Fallback: try standard Add selectors
        for sel in [
            "//a[normalize-space(.)='Add' or normalize-space(.)='+ Add']",
            "//button[normalize-space(.)='Add' or normalize-space(.)='+ Add']",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Add')]",
        ]:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        add_clicked = True
        print("  [PASS] '+ Add' button clicked")
        break
        except Exception:
        continue

        if not add_clicked:
            # RYG Rule — Last resort: build URL from current page GID
        cur = driver.current_url
        if "GID=" in cur:
        gid = cur.split("GID=")[1].split("&")[0]
        driver.get(f"{BASE_URL}/RYGRule/Save?GID={gid}")
        print("  [INFO] Navigated to Add RYG Rule via GID")
        else:
        print("  [WARN] Could not find Add button for RYG Rule")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("ryg_add_form.png")
        print(f"  [INFO] Add RYG Rule URL: {driver.current_url}")

        # Step 3: RYG Rule — Select a rule from the rule dropdown
        print_step(3, "Selecting RYG rule from dropdown")
        rule_selected = False

        # RYG Rule — Try common select IDs for the rule template
        rule_selectors = [
            (By.ID, "WIZARD_TemplateGID"),
            (By.ID, "RYGRuleTemplateGID"),
            (By.XPATH, "//select[contains(@id,'Template') or contains(@id,'Rule')]"),
            (By.XPATH, "//select[contains(@name,'Template') or contains(@name,'Rule')]"),
        ]
        for by, sel in rule_selectors:
        try:
        el = WebDriverWait(driver, 8).until(
            EC.presence_of_element_located((by, sel)))
        select = Select(el)
        # RYG Rule — Pick first non-empty option
        for opt in select.options:
        if opt.get_attribute("value") and opt.get_attribute("value") != "":
        select.select_by_value(opt.get_attribute("value"))
        rule_selected = True
        print(f"  [PASS] Selected rule: {opt.text.strip()}")
        break
        if rule_selected:
        break
        except Exception:
        continue

        if not rule_selected:
            # RYG Rule — JS fallback: select first option with a value
        driver.execute_script("""
        var selects = document.querySelectorAll('select');
        for (var s = 0; s < selects.length; s++) {
        for (var j = 0; j < selects[s].options.length; j++) {
        if (selects[s].options[j].value) {
        selects[s].selectedIndex = j;
        selects[s].dispatchEvent(new Event('change', {bubbles:true}));
        return;
        }
        }
        }
        """)
        print("  [INFO] Rule selected via JS fallback")
        time.sleep(1)

        # Step 4: RYG Rule — Click 'Select' button to load rule template
        print_step(4, "Clicking 'Select' to load rule description")
        try:
            # RYG Rule — Try JS function similar to shipping rules
        driver.execute_script("selectShipRule('N','0');")
        print("  [PASS] selectShipRule() called for RYG")
        except Exception:
            # RYG Rule — Fallback: click any 'Select' button/span
        try:
        driver.execute_script("""
        var btns = document.querySelectorAll('span, a, button, input');
        for (var i = 0; i < btns.length; i++) {
        var t = btns[i].textContent ? btns[i].textContent.trim() : '';
        var v = btns[i].value ? btns[i].value.trim() : '';
        if ((t === 'Select' || v === 'Select') && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [PASS] 'Select' button clicked via JS")
        except Exception:
        print("  [INFO] No 'Select' button found — rule may auto-load")
        time.sleep(PAUSE + 1)
        driver.save_screenshot("ryg_rule_selected.png")

        # Step 5: RYG Rule — Fill mandatory fields (thresholds, values)
        print_step(5, "Filling RYG Rule mandatory fields")

        # RYG Rule — Get count of clickable links in rule description via JS
        link_count = driver.execute_script("""
        var rh = document.getElementById('ruleHtml');
        if (!rh) return 0;
        return rh.querySelectorAll('a').length;
        """)
        print(f"  [INFO] Rule links count: {link_count}")

        # RYG Rule — Click each link by index (JS) and fill dialog values
        for idx in range(link_count):
        print(f"  [INFO] Filling rule link #{idx + 1}")
        try:
            # RYG Rule — Click link by index using JS (handles '0' text etc.)
        link_text = driver.execute_script(f"""
        var rh = document.getElementById('ruleHtml');
        var links = rh.querySelectorAll('a');
        if (links[{idx}]) {{ links[{idx}].click(); return links[{idx}].textContent.trim(); }}
        return null;
        """)
        print(f"    [INFO] Clicked link: '{link_text}'")
        time.sleep(PAUSE)

        # RYG Rule — Wait for value dialog
        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "dlgValueDialog")))

        # RYG Rule — Fill all visible inputs in the dialog
        dialog = driver.find_element(By.ID, "dlgValueDialog")

        # RYG Rule — Fill text/number inputs
        inputs = dialog.find_elements(
            By.CSS_SELECTOR,
            "input[type='text'], input[type='number'], input:not([type='hidden'])")
        for inp in inputs:
        if inp.is_displayed() and inp.is_enabled():
        inp.clear()
        inp.send_keys(str(random.randint(1, 30)))
        print(
            f"    [FILLED] Input '{
                inp.get_attribute('id')}' = {
                inp.get_attribute('value')}")

        # RYG Rule — Select first non-empty option for any dropdowns
        selects = dialog.find_elements(By.TAG_NAME, "select")
        for s in selects:
        if s.is_displayed():
        sel_obj = Select(s)
        for opt in sel_obj.options:
        if opt.get_attribute("value"):
        sel_obj.select_by_value(opt.get_attribute("value"))
        print(
            f"    [SELECTED] Dropdown '{
                s.get_attribute('id')}' = {
                opt.text.strip()}")
        break

        # RYG Rule — Click Apply to close dialog
        driver.execute_script("applyValue();")
        time.sleep(PAUSE)
        print(f"  [PASS] Link #{idx + 1} applied")
        except Exception as e:
        print(f"  [WARN] Could not fill link #{idx + 1}: {e}")

        # RYG Rule — Also fill any standalone inputs on the page (outside
        # dialog)
        standalone_fields = driver.find_elements(
            By.CSS_SELECTOR, "input.form-control:not([type='hidden']):not([readonly])")
        for field in standalone_fields:
        try:
        if field.is_displayed() and field.is_enabled() and not field.get_attribute("value"):
        field.clear()
        field.send_keys(str(random.randint(1, 100)))
        fid = field.get_attribute("id") or field.get_attribute("name")
        print(
            f"  [FILLED] Standalone field '{fid}' = {
                field.get_attribute('value')}")
        except Exception:
        continue

        driver.save_screenshot("ryg_fields_filled.png")

        # Step 6: RYG Rule — Click Save
        print_step(6, "Clicking Save")
        try:
            # RYG Rule — Try rulesubmit() first (same pattern as shipping
            # rules)
        driver.execute_script("return rulesubmit();")
        print("  [PASS] rulesubmit() called")
        except Exception:
        try:
            # RYG Rule — Fallback: entryPGSubmit
        save_btn = driver.find_element(By.ID, "entryPGSubmit")
        driver.execute_script("arguments[0].click();", save_btn)
        print("  [PASS] Save clicked (entryPGSubmit)")
        except Exception:
            # RYG Rule — Generic save fallback
        self._click_save(driver)

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        driver.save_screenshot("ryg_saved.png")

        current_url = driver.current_url
        print(f"  [PASS] RYG Rule saved -> {current_url}")
        print(
            f"  [SUMMARY] RYG Rule added to workcenter '{
                self.created_wc_name}'")

        # ====================================================================
        # PHASE 21: EDIT RYG RULE
        # ====================================================================
    def test_21_edit_ryg_rule(self, driver):
        """
        Edit RYG Rule:
        1. Navigate to RYG Rules list for the workcenter
        2. Select the created rule row
        3. Click Edit button
        4. Update Red/Yellow threshold values in rule links
        5. Click Save
        """
        print_header("PHASE 21: EDIT RYG RULE")

        # Edit RYG Rule — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: Edit RYG Rule — Navigate to RYG Rules list
        print_step(1, "Navigating to RYG Rules list")
        self._nav_to_ryg_list(driver)
        driver.save_screenshot("ryg_edit_list.png")

        # Step 2: Edit RYG Rule — Select rule row (last/first data row)
        print_step(2, "Selecting RYG rule row")
        row_text = driver.execute_script("""
        var rows = document.querySelectorAll('tr.DataRow, tr.AltDataRow');
        if (rows.length > 0) {
        rows[rows.length - 1].click();
        return rows[rows.length - 1].textContent.trim().substring(0, 80);
        }
        return null;
        """)
        if row_text:
        print(f"  [PASS] Rule row selected: {row_text}")
        else:
        print("  [WARN] No rule rows found")
        time.sleep(1)

        # Step 3: Edit RYG Rule — Click Edit button
        print_step(3, "Clicking 'Edit' button")
        edit_clicked = False
        for sel in [
            "//a[normalize-space(.)='Edit' or @title='Edit']",
            "//button[normalize-space(.)='Edit']",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Edit')]",
        ]:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        edit_clicked = True
        print("  [PASS] Edit button clicked")
        break
        except Exception:
        continue

        if not edit_clicked:
            # Edit RYG Rule — JS fallback
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, span');
        for (var i = 0; i < btns.length; i++) {
        if (btns[i].textContent.trim() === 'Edit' && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] Edit clicked via JS fallback")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("ryg_edit_form.png")
        print(f"  [INFO] Edit RYG Rule URL: {driver.current_url}")

        # Step 4: Edit RYG Rule — Update threshold values via rule links
        print_step(4, "Updating RYG Rule threshold values")
        link_count = driver.execute_script("""
        var rh = document.getElementById('ruleHtml');
        if (!rh) return 0;
        return rh.querySelectorAll('a').length;
        """)
        print(f"  [INFO] Rule links count: {link_count}")

        for idx in range(link_count):
        try:
            # Edit RYG Rule — Click link by index
        link_text = driver.execute_script(f"""
        var rh = document.getElementById('ruleHtml');
        var links = rh.querySelectorAll('a');
        if (links[{idx}]) {{ links[{idx}].click(); return links[{idx}].textContent.trim(); }}
        return null;
        """)
        print(f"    [INFO] Clicked link #{idx + 1}: '{link_text}'")
        time.sleep(PAUSE)

        # Edit RYG Rule — Wait for value dialog
        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "dlgValueDialog")))
        dialog = driver.find_element(By.ID, "dlgValueDialog")

        # Edit RYG Rule — Fill inputs with new random values
        inputs = dialog.find_elements(
            By.CSS_SELECTOR,
            "input[type='text'], input[type='number'], input:not([type='hidden'])")
        for inp in inputs:
        if inp.is_displayed() and inp.is_enabled():
        new_val = str(random.randint(5, 50))
        inp.clear()
        inp.send_keys(new_val)
        print(f"    [UPDATED] '{inp.get_attribute('id')}' = {new_val}")

        # Edit RYG Rule — Select dropdown options
        selects = dialog.find_elements(By.TAG_NAME, "select")
        for s in selects:
        if s.is_displayed():
        sel_obj = Select(s)
        opts = [o for o in sel_obj.options if o.get_attribute("value")]
        if len(opts) > 1:
        sel_obj.select_by_value(opts[-1].get_attribute("value"))
        print(
            f"    [UPDATED] Dropdown '{s.get_attribute('id')}' = {opts[-1].text.strip()}")

        # Edit RYG Rule — Click Apply
        driver.execute_script("applyValue();")
        time.sleep(PAUSE)
        print(f"  [PASS] Link #{idx + 1} updated and applied")
        except Exception as e:
        print(f"  [WARN] Could not update link #{idx + 1}: {e}")

        driver.save_screenshot("ryg_edit_updated.png")

        # Step 5: Edit RYG Rule — Click Save
        print_step(5, "Clicking Save")
        try:
        driver.execute_script("return rulesubmit();")
        print("  [PASS] rulesubmit() called")
        except Exception:
        try:
        save_btn = driver.find_element(By.ID, "entryPGSubmit")
        driver.execute_script("arguments[0].click();", save_btn)
        print("  [PASS] Save clicked (entryPGSubmit)")
        except Exception:
        self._click_save(driver)

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        driver.save_screenshot("ryg_edit_saved.png")
        print(f"  [PASS] RYG Rule edited and saved -> {driver.current_url}")

        # ====================================================================
        # PHASE 22: DELETE RYG RULE
        # ====================================================================
    def test_22_delete_ryg_rule(self, driver):
        """
        Delete RYG Rule:
        1. Navigate to RYG Rules list for the workcenter
        2. Select the rule row
        3. Click Delete button
        4. Confirm 'Yes' in "Do you want to delete this RYG Rule?" modal
        5. Verify rule is removed from the list
        """
        print_header("PHASE 22: DELETE RYG RULE")

        # Delete Rule — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: Delete Rule — Navigate to RYG Rules list
        print_step(1, "Navigating to RYG Rules list")
        self._nav_to_ryg_list(driver)
        driver.save_screenshot("ryg_delete_list.png")

        # Step 2: Delete Rule — Count rules before delete
        print_step(2, "Selecting RYG rule row")
        rows_before = driver.find_elements(
            By.CSS_SELECTOR, "tr.DataRow, tr.AltDataRow")
        count_before = len(rows_before)
        print(f"  [INFO] Rules before delete: {count_before}")

        if count_before == 0:
        print("  [SKIP] No RYG rules to delete")
        return

        # Delete Rule — Select last rule row
        last_row = rows_before[-1]
        scroll_to(driver, last_row)
        driver.execute_script("arguments[0].click();", last_row)
        time.sleep(1)
        print(f"  [PASS] Last rule row selected")

        # Step 3: Delete Rule — Click Delete button
        print_step(3, "Clicking 'Delete' button")
        delete_clicked = False
        for sel in [
            "//a[normalize-space(.)='Delete' or @title='Delete']",
            "//button[normalize-space(.)='Delete']",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Delete')]",
        ]:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        delete_clicked = True
        print("  [PASS] Delete button clicked")
        break
        except Exception:
        continue

        if not delete_clicked:
            # Delete Rule — JS fallback
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, span');
        for (var i = 0; i < btns.length; i++) {
        if (btns[i].textContent.trim() === 'Delete' && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] Delete clicked via JS fallback")
        time.sleep(PAUSE)

        # Step 4: Delete Rule — Confirm 'Yes' in "Do you want to delete this
        # RYG Rule?"
        print_step(
            4, "Confirming delete — 'Do you want to delete this RYG Rule?'")
        try:
        modal = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "Modal-modal-alert-id")))
        modal_text = modal.text.strip()
        print(f"  [INFO] Modal: '{modal_text[:120]}'")

        # Delete Rule — Click 'Yes' button (span.modal-save-btn)
        yes_btn = WebDriverWait(
            driver,
            10).until(
            EC.element_to_be_clickable(
                (By.XPATH,
                 "//*[@id='Modal-modal-alert-id']//span[contains(@class,'modal-save-btn')] | "
                 "//button[normalize-space(.)='Yes'] | "
                 "//a[normalize-space(.)='Yes'] | "
                 "//*[@id='Modal-modal-alert-id']//*[contains(normalize-space(.),'Yes')]")))
        driver.execute_script("arguments[0].click();", yes_btn)
        page_loaded(driver)
        time.sleep(PAUSE)
        print("  [PASS] 'Yes' clicked — RYG Rule deleted")
        except Exception as e:
        print(f"  [WARN] Delete confirmation error: {e}")

        driver.save_screenshot("ryg_deleted.png")

        # Step 5: Delete Rule — Verify rule count decreased
        print_step(5, "Verifying RYG rule deleted")
        rows_after = driver.find_elements(
            By.CSS_SELECTOR, "tr.DataRow, tr.AltDataRow")
        count_after = len(rows_after)
        print(f"  [INFO] Rules after delete: {count_after}")
        if count_after < count_before:
        print("  [PASS] RYG Rule deleted successfully")
        else:
        print("  [WARN] Rule count unchanged — delete may not have worked")

        # ====================================================================
        # PHASE 23: CHECK KANBAN FORMULA
        # ====================================================================
    def test_23_check_kanban_formula(self, driver):
        """
        Check Kanban Formula:
        1. Navigate to WC list → search created WC → select row
        2. More Options → Kanban Formula
        3. Verify Kanban Formula page loads with expression
        4. Click Save
        """
        print_header("PHASE 23: CHECK KANBAN FORMULA")

        # Check Kanban formula — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: Check Kanban formula — Navigate to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Check Kanban formula — Search for created workcenter
        try:
        find_box = WebDriverWait(driver, 5).until(EC.visibility_of_element_located(
            (By.XPATH, "//input[contains(@placeholder,'Find Name') or contains(@id,'Find')]")))
        find_box.clear()
        find_box.send_keys(self.created_wc_name)
        time.sleep(1)
        print(f"  [PASS] Searched for WC '{self.created_wc_name}'")
        except Exception:
        print("  [INFO] Find box not found, continuing with list")

        # Check Kanban formula — Select WC row
        try:
        row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, f"//td[contains(normalize-space(.),'{self.created_wc_name}')]")))
        driver.execute_script("arguments[0].click();", row)
        time.sleep(1)
        print(f"  [PASS] Selected workcenter '{self.created_wc_name}'")
        except Exception:
        driver.execute_script("""
        var r = document.querySelector('tr.DataRow, tr.AltDataRow');
        if (r) r.click();
        """)
        time.sleep(1)
        print("  [INFO] Selected first WC row (fallback)")

        # Step 2: Check Kanban formula — Click More Options
        print_step(2, "Opening More Options > Kanban Formula")
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        time.sleep(1)
        except Exception:
        safe_click(
            driver,
            By.XPATH,
            "//button[contains(.,'More Options')] | //a[contains(.,'More Options')]")
        time.sleep(1)

        # Check Kanban formula — Click 'Kanban Formula'
        try:
        driver.execute_script("""
        var items = document.querySelectorAll('li a, li');
        for (var i = 0; i < items.length; i++) {
        var t = items[i].textContent.trim();
        if (t === 'Kanban Formula') {
        items[i].click(); return;
        }
        }
        """)
        except Exception:
        safe_click(driver, By.XPATH,
                   "//li[contains(normalize-space(.),'Kanban Formula')]")

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        print(f"  [INFO] Kanban Formula page: {driver.current_url}")
        driver.save_screenshot("kanban_formula_page.png")

        # Step 3: Check Kanban formula — Verify page loaded
        print_step(3, "Verifying Kanban Formula page")
        page_title = ""
        try:
        heading = WebDriverWait(
            driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, "//h3[contains(.,'Kanban Formula')] | "
                 "//*[contains(@class,'page-title') and contains(.,'Kanban')]")))
        page_title = heading.text.strip()
        print(f"  [PASS] Page heading: '{page_title}'")
        except Exception:
        if "KanbanFormula" in driver.current_url:
        print(f"  [PASS] On Kanban Formula page (URL verified)")
        else:
        print(f"  [WARN] Could not verify Kanban Formula page")

        # Check Kanban formula — Read expression textarea
        expr_text = ""
        try:
        expr_area = driver.find_element(By.TAG_NAME, "textarea")
        expr_text = expr_area.get_attribute("value") or expr_area.text
        if expr_text.strip():
        print(f"  [INFO] Expression: {expr_text.strip()[:120]}")
        else:
        print("  [INFO] Expression is empty")
        except Exception:
        print("  [INFO] No textarea found for expression")

        # Check Kanban formula — Verify Available Functions list
        try:
        func_list = driver.find_element(
            By.XPATH, "//select[preceding-sibling::*[contains(.,'Available Functions')] "
            "or preceding::*[contains(.,'Available Functions')]]")
        funcs = [
            o.text.strip() for o in func_list.find_elements(
                By.TAG_NAME,
                "option") if o.text.strip()]
        print(f"  [INFO] Available Functions: {', '.join(funcs[:8])}")
        except Exception:
        pass

        # Check Kanban formula — Verify Available Fields list
        try:
        field_list = driver.find_element(
            By.XPATH, "//select[preceding-sibling::*[contains(.,'Available Fields')] "
            "or preceding::*[contains(.,'Available Fields')]]")
        fields = [
            o.text.strip() for o in field_list.find_elements(
                By.TAG_NAME,
                "option") if o.text.strip()]
        print(f"  [INFO] Available Fields: {', '.join(fields[:8])}")
        except Exception:
        pass

        driver.save_screenshot("kanban_formula_verified.png")

        # Step 4: Check Kanban formula — Click Save
        print_step(4, "Clicking Save")
        saved = False
        for sel in [
            (By.ID, "entryPGSubmit"),
            (By.XPATH, "//button[contains(.,'Save')]"),
            (By.XPATH, "//a[contains(.,'Save')]"),
            (By.XPATH, "//*[contains(@class,'btn') and contains(.,'Save')]"),
        ]:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable(sel))
        scroll_to(driver, btn)
        btn.click()
        saved = True
        print("  [PASS] Save clicked")
        break
        except Exception:
        continue

        if not saved:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, span');
        for (var i = 0; i < btns.length; i++) {
        if (btns[i].textContent.trim().indexOf('Save') >= 0
        && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [PASS] Save clicked via JS fallback")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("kanban_formula_saved.png")
        print(f"  [PASS] Kanban Formula saved -> {driver.current_url}")
        print(
            f"  [SUMMARY] Kanban Formula checked for workcenter '{
                self.created_wc_name}'")

        # ====================================================================
        # PHASE 24: ATTACH FILE TO WORKCENTER
        # ====================================================================
    def test_24_attach_file_to_workcenter(self, driver):
        """
        Attach file process:
        1. Navigate to Workcenter list → search created WC → select row
        2. More Options → Attachment
        3. Click 'Add Attachment'
        4. Choose file from Desktop location
        5. Click 'Upload File(s)'
        6. Verify attachment uploaded successfully
        """
        print_header("PHASE 24: ATTACH FILE TO WORKCENTER")

        # Attach file process — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: Attach file process — Navigate to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Attach file process — Search for created workcenter
        print_step(2, f"Searching for '{self.created_wc_name}'")
        try:
        find_box = WebDriverWait(driver, 5).until(EC.visibility_of_element_located(
            (By.XPATH, "//input[contains(@placeholder,'Find Name') or contains(@id,'Find')]")))
        find_box.clear()
        find_box.send_keys(self.created_wc_name)
        time.sleep(1)
        try:
        safe_click(driver, By.XPATH,
                   "//img[contains(@src,'find') or contains(@alt,'Find')] | "
                   "//a[contains(@onclick,'Find')]", timeout=3)
        except Exception:
        find_box.send_keys(Keys.RETURN)
        print(f"  [PASS] Searched for '{self.created_wc_name}'")
        except Exception:
        print("  [INFO] Find box not found, continuing with list")
        time.sleep(PAUSE)

        # Attach file process — Select WC row
        print_step(3, f"Selecting '{self.created_wc_name}' row")
        row_selected = False
        try:
        row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, f"//td[contains(normalize-space(.),'{self.created_wc_name}')]")))
        driver.execute_script("arguments[0].click();", row)
        time.sleep(1)
        row_selected = True
        print(f"  [PASS] '{self.created_wc_name}' row selected")
        except Exception:
            # Fallback — select first available data row
        driver.execute_script("""
        var r = document.querySelector('tr.DataRow, tr.AltDataRow');
        if (r) r.click();
        """)
        time.sleep(1)
        row_selected = True
        print("  [INFO] Selected first WC row (fallback)")

        # Step 4: Attach file process — Click More Options
        print_step(4, "Clicking 'More Options' dropdown")
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        time.sleep(1)
        print("  [PASS] 'More Options' dropdown clicked via ID")
        except Exception:
        safe_click(
            driver,
            By.XPATH,
            "//button[contains(.,'More Options')] | //a[contains(.,'More Options')]")
        time.sleep(1)
        print("  [PASS] 'More Options' dropdown clicked via XPATH")

        # Dump visible dropdown items for debugging
        dropdown_items = driver.execute_script("""
        var items = [];
        var links = document.querySelectorAll('li a');
        for (var i = 0; i < links.length; i++) {
        if (links[i].offsetParent !== null) {
        items.push(links[i].textContent.trim());
        }
        }
        return items;
        """)
        print(f"  [DEBUG] Visible dropdown items: {dropdown_items}")

        # Step 5: Attach file process — Click 'Attachment' from dropdown
        print_step(5, "Clicking 'Attachment' from dropdown menu")
        attachment_clicked = False

        # Primary approach — same pattern as test_23 (proven to work)
        try:
        result = driver.execute_script("""
        var items = document.querySelectorAll('li a, li');
        for (var i = 0; i < items.length; i++) {
        var t = items[i].textContent.trim();
        if (t === 'Attachment') {
        items[i].click(); return 'clicked';
        }
        }
        return 'not-found';
        """)
        if result == 'clicked':
        attachment_clicked = True
        print("  [PASS] 'Attachment' clicked via JS")
        else:
        print(f"  [INFO] Attachment JS result: {result}")
        except Exception as e:
        print(f"  [WARN] Attachment JS click error: {e}")

        if not attachment_clicked:
            # XPATH fallback
        for sel in [
            "//a[normalize-space(.)='Attachment']",
            "//li//a[contains(normalize-space(.),'Attachment')]",
            "//*[contains(@class,'dropdown-menu')]//a[contains(.,'Attachment')]",
        ]:
        try:
        link = WebDriverWait(driver, 3).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        driver.execute_script("arguments[0].click();", link)
        attachment_clicked = True
        print("  [PASS] 'Attachment' clicked via XPATH")
        break
        except Exception:
        continue

        if not attachment_clicked:
        print("  [WARN] Could not click Attachment from dropdown")

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        driver.save_screenshot("workcenter_attachment_list.png")
        current_url = driver.current_url
        print(f"  [INFO] Attachment List URL: {current_url}")

        # Verify we reached the Attachment page
        if "Attachment" not in current_url:
        print("  [WARN] Not on Attachment page, retrying with fresh row selection")
        # Re-navigate, re-select, re-open dropdown, re-click Attachment
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Select first data row
        driver.execute_script("""
        var r = document.querySelector('tr.DataRow, tr.AltDataRow');
        if (r) r.click();
        """)
        time.sleep(1)

        # Click More Options
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        except Exception:
        safe_click(
            driver,
            By.XPATH,
            "//button[contains(.,'More Options')] | //a[contains(.,'More Options')]")
        time.sleep(2)

        # Click Attachment — use broader search
        driver.execute_script("""
        var all = document.querySelectorAll('a');
        for (var i = 0; i < all.length; i++) {
        var t = all[i].textContent.trim();
        if (t === 'Attachment' && all[i].offsetParent !== null) {
        all[i].click(); return;
        }
        }
        """)
        page_loaded(driver)
        time.sleep(PAUSE + 1)
        current_url = driver.current_url
        print(f"  [INFO] Retry — Attachment URL: {current_url}")

        assert "Attachment" in current_url, \
            f"Failed to navigate to Attachment page. URL: {current_url}"

        # Step 6: Attach file process — Click 'Add Attachment' button
        print_step(6, "Clicking 'Add Attachment' button")
        add_att_selectors = [
            "//a[contains(normalize-space(.),'Add Attachment')]",
            "//button[contains(normalize-space(.),'Add Attachment')]",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Add Attachment')]",
            "//a[contains(@href,'FileUpload')]",
        ]
        add_att_clicked = False
        for sel in add_att_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        add_att_clicked = True
        print("  [PASS] 'Add Attachment' button clicked")
        break
        except Exception:
        continue

        if not add_att_clicked:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button');
        for (var i = 0; i < btns.length; i++) {
        if (btns[i].textContent.trim().indexOf('Add Attachment') >= 0
        && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] 'Add Attachment' clicked via JS fallback")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("workcenter_file_upload_form.png")
        print(f"  [INFO] File Upload URL: {driver.current_url}")

        # Step 7: Attach file process — Create test file on Desktop
        print_step(7, "Preparing test file for upload")
        test_file_name = f"WC_Attachment_{self.created_wc_name}.txt"

        # Try multiple Desktop paths (standard + OneDrive)
        home = os.path.expanduser("~")
        desktop_candidates = [
            os.path.join(home, "Desktop"),
            os.path.join(home, "OneDrive", "Desktop"),
            os.path.join(home, "OneDrive - Uplandsoftware", "Desktop"),
        ]
        test_file_path = None
        for dp in desktop_candidates:
        if os.path.isdir(dp):
        test_file_path = os.path.join(dp, test_file_name)
        break

        if test_file_path is None:
            # Fallback — create Desktop folder or use temp
        import tempfile
        test_file_path = os.path.join(tempfile.gettempdir(), test_file_name)

        try:
        with open(test_file_path, "w") as f:
        f.write(f"Workcenter Attachment Test File\n")
        f.write(f"Workcenter: {self.created_wc_name}\n")
        f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Comment: Attach file process\n")
        print(f"  [PASS] Test file created: {test_file_path}")
        except Exception as e:
        print(f"  [WARN] Could not create file: {e}")
        import tempfile
        test_file_path = os.path.join(tempfile.gettempdir(), test_file_name)
        with open(test_file_path, "w") as f:
        f.write(f"Workcenter Attachment Test File\n")
        f.write(f"Workcenter: {self.created_wc_name}\n")
        f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Comment: Attach file process\n")
        print(f"  [INFO] Test file created in temp: {test_file_path}")

        # Step 8: Attach file process — Choose File (send file path to input)
        print_step(8, "Choosing file for upload")

        # First make any hidden file inputs visible
        driver.execute_script("""
        var inputs = document.querySelectorAll('input[type=file]');
        for (var i = 0; i < inputs.length; i++) {
        inputs[i].style.display = 'block';
        inputs[i].style.visibility = 'visible';
        inputs[i].style.opacity = '1';
        inputs[i].style.height = '30px';
        inputs[i].style.width = '200px';
        }
        """)
        time.sleep(1)

        file_sent = False
        file_input_selectors = [
            (By.CSS_SELECTOR, "input[type='file']"),
            (By.XPATH, "//input[@type='file']"),
            (By.XPATH, "//input[contains(@name,'file') or contains(@name,'File')]"),
            (By.XPATH, "//input[contains(@name,'Attachment') or contains(@id,'Attachment')]"),
        ]
        for by, sel in file_input_selectors:
        try:
        file_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((by, sel)))
        file_input.send_keys(test_file_path)
        file_sent = True
        print(f"  [PASS] File selected: {test_file_path}")
        break
        except Exception:
        continue

        assert file_sent, "Could not send file path to file input"
        time.sleep(1)
        driver.save_screenshot("workcenter_file_chosen.png")

        # Step 9: Attach file process — Click 'Upload File(s)' button
        print_step(9, "Clicking 'Upload File(s)' button")
        upload_selectors = [
            "//input[@type='submit' and contains(@value,'Upload')]",
            "//button[contains(normalize-space(.),'Upload File')]",
            "//a[contains(normalize-space(.),'Upload File')]",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Upload')]",
            "//input[@type='button' and contains(@value,'Upload')]",
        ]
        upload_clicked = False
        for sel in upload_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        upload_clicked = True
        print("  [PASS] 'Upload File(s)' button clicked")
        break
        except Exception:
        continue

        if not upload_clicked:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, input[type=submit], input[type=button]');
        for (var i = 0; i < btns.length; i++) {
        var txt = btns[i].textContent.trim() || btns[i].value || '';
        if (txt.indexOf('Upload') >= 0 && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] Upload clicked via JS fallback")

        page_loaded(driver)
        time.sleep(PAUSE + 2)
        driver.save_screenshot("workcenter_file_uploaded.png")

        # Step 10: Attach file process — Verify upload success
        print_step(10, "Verifying attachment uploaded")
        current_url = driver.current_url
        page_src = driver.page_source

        if "Attachment" in current_url or "List" in current_url:
        print(f"  [PASS] Returned to Attachment List -> {current_url}")
        if test_file_name in page_src or self.created_wc_name in page_src:
        print(f"  [PASS] Attachment '{test_file_name}' visible in list")
        else:
        print(f"  [INFO] After upload URL: {current_url}")

        # Check for "No Attachment(s)" message is gone
        try:
        no_att = driver.find_element(
            By.XPATH, "//*[contains(text(),'No Attachment(s) found')]")
        if no_att.is_displayed():
        print(
            "  [WARN] 'No Attachments' message still visible — upload may have failed")
        except Exception:
        print(
            "  [PASS] 'No Attachments' message no longer visible — upload succeeded")

        # Cleanup temp file
        try:
        os.remove(test_file_path)
        print(f"  [INFO] Temp file removed: {test_file_path}")
        except Exception:
        pass

        driver.save_screenshot("workcenter_attachment_final.png")
        print(
            f"  [SUMMARY] Attach file process completed for workcenter '{
                self.created_wc_name}'")

        # ====================================================================
        # PHASE 25: EDIT ATTACHMENT — UPLOAD NEW IMAGE
        # ====================================================================
    def test_25_edit_attachment(self, driver):
        """
        Edit attachment:
        1. From Attachment List, select the uploaded attachment row
        2. Click 'Edit' button
        3. On File Upload page, choose a new image file
        4. Click 'Upload File(s)' to replace with new image
        5. Verify updated attachment in list
        """
        print_header("PHASE 25: EDIT ATTACHMENT — UPLOAD NEW IMAGE")

        # Edit attachment — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: Edit attachment — Navigate to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Edit attachment — Select WC row
        print_step(2, f"Selecting workcenter row")
        try:
        row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, f"//td[contains(normalize-space(.),'{self.created_wc_name}')]")))
        driver.execute_script("arguments[0].click();", row)
        time.sleep(1)
        print(f"  [PASS] '{self.created_wc_name}' row selected")
        except Exception:
        driver.execute_script("""
        var r = document.querySelector('tr.DataRow, tr.AltDataRow');
        if (r) r.click();
        """)
        time.sleep(1)
        print("  [INFO] Selected first WC row (fallback)")

        # Step 3: Edit attachment — Click More Options > Attachment
        print_step(3, "Opening More Options > Attachment")
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        time.sleep(1)
        print("  [PASS] 'More Options' dropdown clicked")
        except Exception:
        safe_click(
            driver,
            By.XPATH,
            "//button[contains(.,'More Options')] | //a[contains(.,'More Options')]")
        time.sleep(1)

        # Edit attachment — Click 'Attachment'
        driver.execute_script("""
        var items = document.querySelectorAll('li a, li');
        for (var i = 0; i < items.length; i++) {
        var t = items[i].textContent.trim();
        if (t === 'Attachment') {
        items[i].click(); return;
        }
        }
        """)
        page_loaded(driver)
        time.sleep(PAUSE + 1)
        driver.save_screenshot("edit_att_list.png")
        print(f"  [INFO] Attachment List URL: {driver.current_url}")

        # Step 4: Edit attachment — Select the attachment row
        print_step(4, "Selecting attachment row")
        row_clicked = False
        try:
        att_row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, "//tr[contains(@class,'DataRow') or contains(@class,'AltDataRow')]")))
        driver.execute_script("arguments[0].click();", att_row)
        row_clicked = True
        time.sleep(1)
        print("  [PASS] Attachment row selected")
        except Exception:
        driver.execute_script("""
        var r = document.querySelector('tr.DataRow, tr.AltDataRow');
        if (r) { r.click(); }
        """)
        row_clicked = True
        time.sleep(1)
        print("  [INFO] Attachment row selected via JS fallback")
        driver.save_screenshot("edit_att_row_selected.png")

        # Step 5: Edit attachment — Click 'Edit' button
        print_step(5, "Clicking 'Edit' button")
        edit_clicked = False
        edit_selectors = [
            "//a[normalize-space(.)='Edit' or contains(normalize-space(.),'Edit')]",
            "//button[normalize-space(.)='Edit']",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Edit')]",
        ]
        for sel in edit_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        edit_clicked = True
        print("  [PASS] 'Edit' button clicked")
        break
        except Exception:
        continue

        if not edit_clicked:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, span');
        for (var i = 0; i < btns.length; i++) {
        var txt = btns[i].textContent.trim();
        if (txt === 'Edit' && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] 'Edit' clicked via JS fallback")

        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("edit_att_upload_form.png")
        print(f"  [INFO] Edit File Upload URL: {driver.current_url}")

        # Step 6: Edit attachment — Create a new image file on Desktop
        print_step(6, "Preparing new image file for upload")
        img_file_name = f"WC_Edit_Image_{self.created_wc_name}.png"

        # Try multiple Desktop paths (standard + OneDrive)
        home = os.path.expanduser("~")
        desktop_candidates = [
            os.path.join(home, "Desktop"),
            os.path.join(home, "OneDrive", "Desktop"),
            os.path.join(home, "OneDrive - Uplandsoftware", "Desktop"),
        ]
        img_file_path = None
        for dp in desktop_candidates:
        if os.path.isdir(dp):
        img_file_path = os.path.join(dp, img_file_name)
        break

        if img_file_path is None:
        import tempfile
        img_file_path = os.path.join(tempfile.gettempdir(), img_file_name)

        # Create a minimal valid PNG image (1x1 pixel, red)
        try:
        import struct
        import zlib

        def _create_png(path):
            # IHDR
        width, height = 100, 100
        ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
        ihdr_crc = zlib.crc32(b'IHDR' + ihdr_data) & 0xFFFFFFFF
        ihdr = struct.pack('>I', 13) + b'IHDR' + \
            ihdr_data + struct.pack('>I', ihdr_crc)
        # IDAT — uncompressed red pixels
        raw = b''
        for _ in range(height):
        raw += b'\x00'  # filter byte
        raw += b'\xff\x00\x00' * width  # RGB red
        compressed = zlib.compress(raw)
        idat_crc = zlib.crc32(b'IDAT' + compressed) & 0xFFFFFFFF
        idat = struct.pack('>I', len(compressed)) + b'IDAT' + \
            compressed + struct.pack('>I', idat_crc)
        # IEND
        iend_crc = zlib.crc32(b'IEND') & 0xFFFFFFFF
        iend = struct.pack('>I', 0) + b'IEND' + struct.pack('>I', iend_crc)
        # Write
        with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + ihdr + idat + iend)

        _create_png(img_file_path)
        print(f"  [PASS] Image file created: {img_file_path}")
        except Exception as e:
        print(f"  [WARN] PNG creation error: {e}, falling back to text file")
        img_file_name = f"WC_Edit_Attachment_{self.created_wc_name}.txt"
        img_file_path = os.path.join(
            os.path.dirname(img_file_path), img_file_name)
        with open(img_file_path, "w") as f:
        f.write(f"Edit attachment\n")
        f.write(f"Workcenter: {self.created_wc_name}\n")
        f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        print(f"  [INFO] Fallback file created: {img_file_path}")

        # Step 7: Edit attachment — Choose new file
        print_step(7, "Choosing new image file for upload")

        # Make hidden file inputs visible
        driver.execute_script("""
        var inputs = document.querySelectorAll('input[type=file]');
        for (var i = 0; i < inputs.length; i++) {
        inputs[i].style.display = 'block';
        inputs[i].style.visibility = 'visible';
        inputs[i].style.opacity = '1';
        inputs[i].style.height = '30px';
        inputs[i].style.width = '200px';
        }
        """)
        time.sleep(1)

        file_sent = False
        file_input_selectors = [
            (By.CSS_SELECTOR, "input[type='file']"),
            (By.XPATH, "//input[@type='file']"),
            (By.XPATH, "//input[contains(@name,'file') or contains(@name,'File')]"),
        ]
        for by, sel in file_input_selectors:
        try:
        file_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((by, sel)))
        file_input.send_keys(img_file_path)
        file_sent = True
        print(f"  [PASS] New image file selected: {img_file_path}")
        break
        except Exception:
        continue

        assert file_sent, "Could not send image file path to file input"
        time.sleep(1)
        driver.save_screenshot("edit_att_file_chosen.png")

        # Step 8: Edit attachment — Click 'Upload File(s)' button
        print_step(8, "Clicking 'Upload File(s)' button")
        upload_selectors = [
            "//input[@type='submit' and contains(@value,'Upload')]",
            "//button[contains(normalize-space(.),'Upload File')]",
            "//a[contains(normalize-space(.),'Upload File')]",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Upload')]",
            "//input[@type='button' and contains(@value,'Upload')]",
        ]
        upload_clicked = False
        for sel in upload_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        upload_clicked = True
        print("  [PASS] 'Upload File(s)' button clicked")
        break
        except Exception:
        continue

        if not upload_clicked:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, input[type=submit], input[type=button]');
        for (var i = 0; i < btns.length; i++) {
        var txt = btns[i].textContent.trim() || btns[i].value || '';
        if (txt.indexOf('Upload') >= 0 && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] Upload clicked via JS fallback")

        page_loaded(driver)
        time.sleep(PAUSE + 2)
        driver.save_screenshot("edit_att_uploaded.png")

        # Step 9: Edit attachment — Verify updated attachment
        print_step(9, "Verifying edited attachment")
        current_url = driver.current_url
        page_src = driver.page_source

        if "Attachment" in current_url or "List" in current_url:
        print(f"  [PASS] Returned to Attachment List -> {current_url}")
        if img_file_name in page_src:
        print(f"  [PASS] Updated attachment '{img_file_name}' visible in list")
        else:
        print(f"  [INFO] After edit upload URL: {current_url}")

        # Cleanup image file
        try:
        os.remove(img_file_path)
        print(f"  [INFO] Image file removed: {img_file_path}")
        except Exception:
        pass

        driver.save_screenshot("edit_att_final.png")
        print(
            f"  [SUMMARY] Edit attachment completed for workcenter '{
                self.created_wc_name}'")

        # ====================================================================
        # PHASE 26: CROP ATTACHMENT IMAGE
        # ====================================================================
    def test_26_crop_attachment_image(self, driver):
        """
        CropImage process:
        1. Navigate to Workcenter List, search created workcenter
        2. Click More Options > Attachment
        3. From Attachment List, select attachment row
        4. Click 'Crop' button
        5. On Crop File page, click 'Crop Image' button
        6. Verify crop completed
        """
        print_header("PHASE 26: CROP ATTACHMENT IMAGE")

        # CropImage process — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: CropImage process — Navigate to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Step 2: CropImage process — Search and select workcenter
        print_step(2, f"Searching for workcenter '{self.created_wc_name}'")
        try:
        row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, f"//td[contains(normalize-space(.),'{self.created_wc_name}')]")))
        driver.execute_script("arguments[0].click();", row)
        time.sleep(1)
        print(f"  [PASS] '{self.created_wc_name}' row selected")
        except Exception:
        driver.execute_script("""
        var r = document.querySelector('tr.DataRow, tr.AltDataRow');
        if (r) r.click();
        """)
        time.sleep(1)
        print("  [INFO] Selected first WC row (fallback)")

        # Step 3: CropImage process — Click More Options > Attachment
        print_step(3, "Opening More Options > Attachment")
        try:
        driver.execute_script(
            "document.getElementById('Workcenter_tbrMoreActions').click();")
        time.sleep(1)
        print("  [PASS] 'More Options' dropdown clicked")
        except Exception:
        safe_click(
            driver,
            By.XPATH,
            "//button[contains(.,'More Options')] | //a[contains(.,'More Options')]")
        time.sleep(1)

        # CropImage process — Click 'Attachment'
        driver.execute_script("""
        var items = document.querySelectorAll('li a, li');
        for (var i = 0; i < items.length; i++) {
        var t = items[i].textContent.trim();
        if (t === 'Attachment') {
        items[i].click(); return;
        }
        }
        """)
        page_loaded(driver)
        time.sleep(PAUSE + 1)
        driver.save_screenshot("crop_att_list.png")
        print(f"  [INFO] Attachment List URL: {driver.current_url}")

        # Step 4: CropImage process — Select the attachment row
        print_step(4, "Selecting attachment row")
        try:
        att_row = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
            (By.XPATH, "//tr[contains(@class,'DataRow') or contains(@class,'AltDataRow')]")))
        driver.execute_script("arguments[0].click();", att_row)
        time.sleep(1)
        print("  [PASS] Attachment row selected")
        except Exception:
        driver.execute_script("""
        var r = document.querySelector('tr.DataRow, tr.AltDataRow');
        if (r) { r.click(); }
        """)
        time.sleep(1)
        print("  [INFO] Attachment row selected via JS fallback")
        driver.save_screenshot("crop_att_row_selected.png")

        # Step 5: CropImage process — Click 'Crop' button
        print_step(5, "Clicking 'Crop' button")
        crop_clicked = False
        crop_selectors = [
            "//a[normalize-space(.)='Crop']",
            "//button[normalize-space(.)='Crop']",
            "//*[contains(@class,'btn') and normalize-space(.)='Crop']",
            "//a[contains(normalize-space(.),'Crop')]",
            "//button[contains(normalize-space(.),'Crop')]",
        ]
        for sel in crop_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        crop_clicked = True
        print("  [PASS] 'Crop' button clicked")
        break
        except Exception:
        continue

        if not crop_clicked:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, span');
        for (var i = 0; i < btns.length; i++) {
        var txt = btns[i].textContent.trim();
        if (txt === 'Crop' && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] 'Crop' clicked via JS fallback")

        page_loaded(driver)
        time.sleep(PAUSE + 1)
        driver.save_screenshot("crop_file_page.png")
        print(f"  [INFO] Crop File URL: {driver.current_url}")

        # Step 6: CropImage process — Verify image is displayed and select crop
        # area
        print_step(6, "Verifying image and selecting crop area")
        crop_img_el = None
        try:
        crop_img_el = WebDriverWait(
            driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, "//img[contains(@src,'Attachment') or contains(@src,'attachment') "
                 "or contains(@src,'File') or contains(@src,'Logo')]")))
        print(
            f"  [PASS] Image found on Crop page: {
                crop_img_el.get_attribute('src')[
                    :80]}...")
        except Exception:
            # Try any visible img tag with reasonable size
        imgs = driver.find_elements(By.TAG_NAME, "img")
        visible = [i for i in imgs if i.is_displayed()
                   and i.size['height'] > 20]
        if visible:
        crop_img_el = visible[0]
        print(f"  [PASS] {len(visible)} image(s) visible on Crop page")
        else:
        print("  [INFO] No large image detected, proceeding with Crop anyway")

        # CropImage process — Draw crop selection on the image
        print_step("6b", "Drawing crop selection on image")
        if crop_img_el:
        try:
        scroll_to(driver, crop_img_el)
        time.sleep(1)
        img_w = crop_img_el.size['width']
        img_h = crop_img_el.size['height']
        # Select roughly the center 50% of the image
        start_x = -int(img_w * 0.25)
        start_y = -int(img_h * 0.25)
        drag_x = int(img_w * 0.5)
        drag_y = int(img_h * 0.5)
        ActionChains(driver) \
            .move_to_element(crop_img_el) \
            .move_by_offset(start_x, start_y) \
            .click_and_hold() \
            .move_by_offset(drag_x, drag_y) \
            .release() \
            .perform()
        time.sleep(1)
        print(f"  [PASS] Crop area drawn on image ({img_w}x{img_h})")
        except Exception as e:
        print(f"  [WARN] ActionChains drag failed: {e}")
        # Fallback: try to set crop coordinates via JS (jCrop/imgAreaSelect)
        try:
        driver.execute_script("""
        // Try setting hidden crop coordinate inputs
        var fields = ['x1','y1','x2','y2','w','h',
        'X','Y','W','H','Width','Height'];
        var vals = [10, 10, 80, 80, 70, 70,
        10, 10, 70, 70, 70, 70];
        for (var i = 0; i < fields.length; i++) {
        var el = document.getElementById(fields[i])
        || document.querySelector('input[name="'+fields[i]+'"]');
        if (el) { el.value = vals[i]; }
        }
        """)
        print("  [INFO] Crop coords set via JS fallback")
        except Exception:
        pass
        else:
        print("  [WARN] No image element to draw crop selection on")

        time.sleep(1)
        driver.save_screenshot("crop_selection_drawn.png")

        # Step 7: CropImage process — Click 'Crop Image' button
        print_step(7, "Clicking 'Crop Image' button")
        crop_img_clicked = False
        crop_img_selectors = [
            "//input[@type='submit' and contains(@value,'Crop Image')]",
            "//button[contains(normalize-space(.),'Crop Image')]",
            "//a[contains(normalize-space(.),'Crop Image')]",
            "//*[contains(@class,'btn') and contains(normalize-space(.),'Crop Image')]",
            "//input[@type='button' and contains(@value,'Crop')]",
        ]
        for sel in crop_img_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        crop_img_clicked = True
        print("  [PASS] 'Crop Image' button clicked")
        break
        except Exception:
        continue

        if not crop_img_clicked:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, input[type=submit], input[type=button]');
        for (var i = 0; i < btns.length; i++) {
        var txt = btns[i].textContent.trim() || btns[i].value || '';
        if (txt.indexOf('Crop Image') >= 0 && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)
        print("  [INFO] 'Crop Image' clicked via JS fallback")

        # Handle possible alert "Please select image to crop"
        time.sleep(2)
        try:
        alert = driver.switch_to.alert
        alert_text = alert.text
        print(
            f"  [WARN] Alert detected: '{alert_text}' — accepting and retrying crop")
        alert.accept()
        time.sleep(1)

        # Retry: draw selection again more aggressively
        if crop_img_el:
        try:
        scroll_to(driver, crop_img_el)
        time.sleep(1)
        ActionChains(driver) \
            .move_to_element(crop_img_el) \
            .click_and_hold() \
            .move_by_offset(50, 50) \
            .release() \
            .perform()
        time.sleep(1)
        print("  [INFO] Retry crop selection drawn")
        except Exception:
        pass

        # Retry click 'Crop Image'
        for sel in crop_img_selectors:
        try:
        btn = WebDriverWait(driver, 8).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        scroll_to(driver, btn)
        btn.click()
        print("  [PASS] 'Crop Image' clicked on retry")
        break
        except Exception:
        continue

        time.sleep(2)
        # Handle alert again if needed
        try:
        alert = driver.switch_to.alert
        print(f"  [INFO] Alert again: '{alert.text}' — accepting")
        alert.accept()
        except Exception:
        pass
        except Exception:
        print("  [INFO] No alert after Crop Image click — proceeding")

        try:
        page_loaded(driver)
        except Exception:
        try:
        alert = driver.switch_to.alert
        alert.accept()
        time.sleep(1)
        page_loaded(driver)
        except Exception:
        pass

        time.sleep(PAUSE + 2)
        driver.save_screenshot("crop_image_done.png")

        # Step 8: CropImage process — Verify crop completed
        print_step(8, "Verifying crop completed")
        current_url = driver.current_url
        page_src = driver.page_source

        if "Attachment" in current_url and "List" in current_url:
        print(f"  [PASS] Returned to Attachment List -> {current_url}")
        elif "Crop" in current_url:
        print(f"  [INFO] Still on Crop page -> {current_url}")
        else:
        print(f"  [INFO] After crop URL: {current_url}")

        # Check for success indicators
        if "success" in page_src.lower() or "saved" in page_src.lower():
        print("  [PASS] Success message detected after crop")

        driver.save_screenshot("crop_att_final.png")
        print(
            f"  [SUMMARY] CropImage process completed for workcenter '{
                self.created_wc_name}'")

        # ====================================================================
        # PHASE 27: FILTER WORKCENTER LIST BY NAME, CODE, LOCATION
        # ====================================================================
    def test_27_filter_workcenter_list(self, driver):
        """
        Filtering data:
        Apply filters on Workcenter List by Name, Code, Location
        with different operator conditions and values, then verify
        filtered data in the list.
        """
        print_header("PHASE 27: FILTER WORKCENTER LIST — NAME, CODE, LOCATION")

        # Filtering data — Ensure logged in
        self._ensure_logged_in(driver)

        # Step 1: Filtering data — Navigate to Workcenter list
        print_step(1, "Navigating to Workcenter list")
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)
        driver.save_screenshot("filter_wc_list_initial.png")

        # Collect existing workcenter names from the list for filter values
        print_step(2, "Collecting workcenter data from list for filter tests")
        rows = driver.find_elements(
            By.XPATH, "//tr[contains(@class,'DataRow') or contains(@class,'AltDataRow')]")
        first_wc_name = ""
        first_wc_code = ""
        first_wc_location = ""
        if rows:
        cells = rows[0].find_elements(By.TAG_NAME, "td")
        if len(cells) >= 3:
        first_wc_name = cells[0].text.strip()
        first_wc_location = cells[1].text.strip()
        first_wc_code = cells[2].text.strip()
        print(f"  [INFO] First WC: Name='{first_wc_name}', "
              f"Location='{first_wc_location}', Code='{first_wc_code}'")
        else:
        first_wc_name = "Databizwarehouse"
        first_wc_code = "Databizwarehouse"
        first_wc_location = "EditLoc314"
        print(f"  [INFO] No rows found, using defaults")

        total_rows_before = len(rows)
        print(f"  [INFO] Total rows before filtering: {total_rows_before}")

        # Helper to apply a filter and check results
        def apply_filter(step_num, filter_by, operator, value, description):
        print_step(step_num, f"Filtering data — {description}")

        # Navigate fresh to avoid stale state
        driver.get(f"{BASE_URL}/Workcenter/List")
        page_loaded(driver)
        time.sleep(PAUSE)

        # Select 'Filter By' dropdown
        try:
        filter_dd = WebDriverWait(
            driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, "//select[contains(@id,'FilterBy') or contains(@name,'FilterBy') "
                 "or contains(@id,'filterBy') or contains(@id,'ddlFilterBy')]")))
        from selenium.webdriver.support.ui import Select
        Select(filter_dd).select_by_visible_text(filter_by)
        time.sleep(0.5)
        print(f"    [PASS] Filter By = '{filter_by}'")
        except Exception as e:
            # Fallback: try JS approach
        driver.execute_script(f"""
        var selects = document.querySelectorAll('select');
        for (var i = 0; i < selects.length; i++) {{
        var opts = selects[i].options;
        for (var j = 0; j < opts.length; j++) {{
        if (opts[j].text.trim() === '{filter_by}') {{
        selects[i].selectedIndex = j;
        selects[i].dispatchEvent(new Event('change'));
        break;
        }}
        }}
        }}
        """)
        time.sleep(0.5)
        print(f"    [INFO] Filter By = '{filter_by}' (JS fallback)")

        # Select 'Operator' dropdown
        try:
        op_dd = WebDriverWait(
            driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, "//select[contains(@id,'Operator') or contains(@name,'Operator') "
                 "or contains(@id,'operator') or contains(@id,'ddlOperator')]")))
        Select(op_dd).select_by_visible_text(operator)
        time.sleep(0.5)
        print(f"    [PASS] Operator = '{operator}'")
        except Exception:
        driver.execute_script(f"""
        var selects = document.querySelectorAll('select');
        for (var i = 0; i < selects.length; i++) {{
        var opts = selects[i].options;
        for (var j = 0; j < opts.length; j++) {{
        if (opts[j].text.trim() === '{operator}') {{
        selects[i].selectedIndex = j;
        selects[i].dispatchEvent(new Event('change'));
        break;
        }}
        }}
        }}
        """)
        time.sleep(0.5)
        print(f"    [INFO] Operator = '{operator}' (JS fallback)")

        # Enter filter value
        try:
        val_input = WebDriverWait(
            driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, "//input[contains(@id,'Value') or contains(@name,'Value') "
                 "or contains(@id,'FilterValue') or contains(@id,'txtValue') "
                 "or contains(@placeholder,'Enter Value')]")))
        val_input.clear()
        val_input.send_keys(value)
        time.sleep(0.5)
        print(f"    [PASS] Value = '{value}'")
        except Exception:
        driver.execute_script(f"""
        var inputs = document.querySelectorAll('input[type=text]');
        for (var i = 0; i < inputs.length; i++) {{
        var ph = inputs[i].placeholder || '';
        if (ph.indexOf('Value') >= 0 || ph.indexOf('Enter') >= 0) {{
        inputs[i].value = '{value}';
        inputs[i].dispatchEvent(new Event('input'));
        break;
        }}
        }}
        """)
        time.sleep(0.5)
        print(f"    [INFO] Value = '{value}' (JS fallback)")

        # Click 'Go' button
        go_clicked = False
        go_selectors = [
            "//button[normalize-space(.)='Go' or contains(normalize-space(.),'Go')]",
            "//input[@type='submit' and contains(@value,'Go')]",
            "//a[contains(@class,'btn') and contains(normalize-space(.),'Go')]",
            "//*[contains(@class,'btn') and normalize-space(.)='Go ►']",
        ]
        for sel in go_selectors:
        try:
        btn = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, sel)))
        btn.click()
        go_clicked = True
        break
        except Exception:
        continue

        if not go_clicked:
        driver.execute_script("""
        var btns = document.querySelectorAll('a, button, input[type=submit]');
        for (var i = 0; i < btns.length; i++) {
        var txt = (btns[i].textContent || btns[i].value || '').trim();
        if (txt.indexOf('Go') >= 0 && btns[i].offsetParent !== null) {
        btns[i].click(); return;
        }
        }
        """)

        page_loaded(driver)
        time.sleep(PAUSE)

        # Check filtered results
        filtered_rows = driver.find_elements(
            By.XPATH, "//tr[contains(@class,'DataRow') or contains(@class,'AltDataRow')]")
        filtered_count = len(filtered_rows)
        page_src = driver.page_source

        driver.save_screenshot(
            f"filter_{
                filter_by.lower()}_{
                operator.replace(
                    ' ',
                    '_').lower()}.png")

        # Verify filter worked
        if filtered_count == 0:
        if "No Record(s)" in page_src or "no record" in page_src.lower():
        print(
            f"    [PASS] Filter returned 0 records (No Records message shown)")
        else:
        print(f"    [INFO] Filter returned 0 rows")
        else:
        print(f"    [PASS] Filter returned {filtered_count} row(s)")
        # Verify filtered data matches expectation
        for row in filtered_rows[:3]:  # Check first 3 rows
        row_text = row.text.strip()
        if value.lower() in row_text.lower():
        print(f"    [PASS] Row contains filter value: "
              f"'{row_text[:60]}...'")

        print(f"    [SUMMARY] {description}: {filtered_count} result(s)")
        return filtered_count

        # ---- FILTER TEST 1: Name — Contains ----
        count1 = apply_filter(3, "Name", "Contains", "WC",
                              "Name Contains 'WC'")

        # ---- FILTER TEST 2: Name — Equal To ----
        count2 = apply_filter(4, "Name", "Equal To", first_wc_name,
                              f"Name Equal To '{first_wc_name}'")

        # ---- FILTER TEST 3: Name — Begins With ----
        count3 = apply_filter(5, "Name", "Begins With", "WC",
                              "Name Begins With 'WC'")

        # ---- FILTER TEST 4: Code — Contains ----
        count4 = apply_filter(6,
                              "Code",
                              "Contains",
                              first_wc_code[:4] if first_wc_code else "WC",
                              f"Code Contains '{first_wc_code[:4] if first_wc_code else 'WC'}'")

        # ---- FILTER TEST 5: Code — Equal To ----
        count5 = apply_filter(7, "Code", "Equal To", first_wc_code,
                              f"Code Equal To '{first_wc_code}'")

        # ---- FILTER TEST 6: Location — Contains ----
        loc_search = first_wc_location[:4] if first_wc_location else "Loc"
        count6 = apply_filter(8, "Location", "Contains", loc_search,
                              f"Location Contains '{loc_search}'")

        # ---- FILTER TEST 7: Location — Equal To ----
        count7 = apply_filter(9, "Location", "Equal To", first_wc_location,
                              f"Location Equal To '{first_wc_location}'")

        # ---- FILTER TEST 8: Name — Does Not Contain ----
        count8 = apply_filter(10, "Name", "Does Not Contain", "ZZZZZ",
                              "Name Does Not Contain 'ZZZZZ'")

        # ---- FILTER TEST 9: Name — Is Not Empty ----
        count9 = apply_filter(11, "Name", "Is Not Empty", "",
                              "Name Is Not Empty")

        # Step 12: Filtering data — Summary
        print_step(12, "Filter test summary")
        print(f"  Total rows (unfiltered):          {total_rows_before}")
        print(f"  Name Contains 'WC':               {count1}")
        print(f"  Name Equal To '{first_wc_name}':  {count2}")
        print(f"  Name Begins With 'WC':            {count3}")
        print(
            f"  Code Contains '{first_wc_code[:4] if first_wc_code else 'WC'}': {count4}")
        print(f"  Code Equal To '{first_wc_code}':  {count5}")
        print(f"  Location Contains '{loc_search}': {count6}")
        print(f"  Location Equal To '{first_wc_location}': {count7}")
        print(f"  Name Does Not Contain 'ZZZZZ':    {count8}")
        print(f"  Name Is Not Empty:                {count9}")

        driver.save_screenshot("filter_wc_final.png")
        print(f"  [SUMMARY] Filtering data completed — 9 filter tests executed")
