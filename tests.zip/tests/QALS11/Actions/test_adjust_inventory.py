import time
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ============================================================================
# CONFIGURATION
# ============================================================================
BASE_URL = "https://engineering.ultrivalms.com/QALS1011"
USERNAME = "buyeruser"
PASSWORD = "Ultriva!23"
PAUSE = 1.5
CURRENT_LOCATION = "1234"
ADJUST_QTY = "200"

# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture(scope="class")
def driver():
    """Class-scoped Chrome driver — one browser session per test class."""
    options = webdriver.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-logging"])
    
    drv = webdriver.Chrome(options=options)
    drv.implicitly_wait(10)
    drv.set_page_load_timeout(30)
    drv.maximize_window()
    yield drv
    drv.quit()

# ============================================================================
# HELPERS
# ============================================================================

def wait_ready(driver, timeout=30):
    """Wait for document.readyState == complete."""
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )

def find(driver, by, locator, timeout=15):
    """Wait for presence and return element."""
    return WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((by, locator))
    )

def clickable(driver, by, locator, timeout=15):
    """Wait until clickable and return element."""
    return WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, locator))
    )

def scroll_to(driver, el):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'})", el)
    time.sleep(0.3)

def take_screenshot(driver, name):
    import os
    screenshots_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "..", "reports", "screenshots"
    )
    os.makedirs(screenshots_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(screenshots_dir, f"adjustinventory_{name}_{ts}.png")
    driver.save_screenshot(path)
    print(f"  [screenshot] {path}")
    return path

# ============================================================================
# TEST CLASS
# ============================================================================

@pytest.mark.usefixtures("driver")
class TestAdjustInventory:

    # ── TC-AI-001: Login ─────────────────────────────────────────────────────
    def test_01_login(self, driver):
        """Login to QA site with buyeruser credentials."""
        print("\n[TC-AI-001] Logging in to QA site...")
        driver.get(BASE_URL)
        wait_ready(driver)

        username_field = find(driver, By.ID, "UserName")
        password_field = find(driver, By.ID, "Password")
        login_button = clickable(driver, By.ID, "login-button")

        username_field.clear()
        username_field.send_keys(USERNAME)
        password_field.clear()
        password_field.send_keys(PASSWORD)
        login_button.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "01_after_login")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert BASE_URL.lower() in current_url.lower() or "Home" in current_url, \
            f"Login may have failed. URL: {current_url}"
        print("  [PASS] Login successful.")

    # ── TC-AI-002: Navigate to Actions ───────────────────────────────────
    def test_02_navigate_to_actions(self, driver):
        """Click Actions in the left sidebar to open the Actions page."""
        print("\n[TC-AI-002] Navigating to Actions page...")

        actions_link = clickable(
            driver,
            By.XPATH,
            "//a[contains(@href, 'Action/Home') or "
            "(.//span[normalize-space()='Actions']) or "
            "normalize-space(.)='Actions']",
        )
        scroll_to(driver, actions_link)
        actions_link.click()
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "02_actions_page")
        assert "Action/Home" in driver.current_url, \
            f"Expected Actions page. Got: {driver.current_url}"
        print(f"  [PASS] Actions page loaded: {driver.current_url}")

    # ── TC-AI-003: Click Adjust Inventory ────────────────────────────────
    def test_03_click_adjust_inventory(self, driver):
        """Click the Adjust Inventory tile from the Buyer Actions section."""
        print("\n[TC-AI-003] Clicking Adjust Inventory tile...")

        adjust_inv_link = None
        for locator in [
            (By.XPATH, "//a[contains(@href,'AdjustInventory') and not(contains(@class,'toplinks'))]"),
            (By.XPATH, "//a[contains(normalize-space(),'Adjust Inventory') and not(contains(@class,'toplinks'))]"),
            (By.XPATH, "//a[contains(@href,'AdjustInventory')]"),
        ]:
            try:
                adjust_inv_link = WebDriverWait(driver, 8).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert adjust_inv_link, "Adjust Inventory link not found on Actions page"
        scroll_to(driver, adjust_inv_link)
        driver.execute_script("arguments[0].click()", adjust_inv_link)
        wait_ready(driver)
        time.sleep(PAUSE)

        take_screenshot(driver, "03_adjust_inventory_items")
        assert "AdjustInventory" in driver.current_url, \
            f"Expected Adjust Inventory page. Got: {driver.current_url}"
        print(f"  [PASS] Adjust Inventory Items page loaded: {driver.current_url}")

    # ── TC-AI-004: Select item and click Show Cards ──────────────────────
    def test_04_select_item_show_cards(self, driver):
        """Click the first item in Adjust Inventory Items List, then click Show Cards."""
        print("\n[TC-AI-004] Selecting first item and clicking Show Cards...")

        # Navigate to AdjustInventoryItems if not already there
        if "AdjustInventoryItems" not in driver.current_url:
            driver.get(f"{BASE_URL}/BuyerAction/AdjustInventoryItems")
            wait_ready(driver)
            time.sleep(PAUSE)

        # Items are rendered as GridLink anchors
        item_links = WebDriverWait(driver, 20).until(
            EC.presence_of_all_elements_located((By.XPATH, "//a[contains(@class,'GridLink')]"))
        )
        assert item_links, "No items found in Adjust Inventory Items List"

        # Prefer an item with multiple cards (00kantest has 52 cards)
        first_item = item_links[0]
        for lnk in item_links:
            if "00kantest" in lnk.text.lower():
                first_item = lnk
                break
                
        item_text = first_item.text.strip()
        print(f"  [INFO] Selected item: '{item_text}'")

        scroll_to(driver, first_item)
        driver.execute_script("arguments[0].click()", first_item)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "04a_after_item_click")
        print(f"  [INFO] URL after item click: {driver.current_url}")

        # If already on AdjustInventoryCards page, we're done
        if "AdjustInventoryCard" in driver.current_url:
            print("  [INFO] Navigated directly to Adjust Inventory Cards page.")
            return

        # Otherwise look for Show Cards button
        show_cards_btn = None
        for locator in [
            (By.XPATH, "//button[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Show Cards')]"),
            (By.XPATH, "//*[contains(@id,'ShowCards') or contains(@id,'showCards')]"),
        ]:
            try:
                show_cards_btn = WebDriverWait(driver, 6).until(
                    EC.element_to_be_clickable(locator)
                )
                break
            except Exception:
                continue

        assert show_cards_btn, "Show Cards button not found and not on Adjust Inventory Cards page"
        scroll_to(driver, show_cards_btn)
        driver.execute_script("arguments[0].click()", show_cards_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "04b_adjust_inventory_cards")
        assert "AdjustInventoryCard" in driver.current_url or "AdjustInventory" in driver.current_url, \
            f"Expected Adjust Inventory Cards page. Got: {driver.current_url}"
        print(f"  [PASS] Adjust Inventory Cards List loaded: {driver.current_url}")

    # ── TC-AI-005: Select card, enter location, adjust qty and click Adjust Inventory ─
    def test_05_adjust_inventory(self, driver):
        """Select card checkbox, enter current location and adjust qty=200, then click Adjust Inventory."""
        print("\n[TC-AI-005] Selecting card and entering adjust qty...")

        # Ensure we are on Adjust Inventory Cards page
        if "AdjustInventoryCard" not in driver.current_url:
            driver.get(f"{BASE_URL}/BuyerAction/AdjustInventoryCards")
            wait_ready(driver)
            time.sleep(PAUSE)

        # ── Dump all input names/ids to debug field patterns ────────────────
        all_inputs = driver.find_elements(By.XPATH, "//input[@type='text' or @type='checkbox' or not(@type)]")
        print(f"  [DEBUG] Total inputs on page: {len(all_inputs)}")
        for inp in all_inputs[:20]:
            name = inp.get_attribute("name") or ""
            iid = inp.get_attribute("id") or ""
            val = inp.get_attribute("value") or ""
            typ = inp.get_attribute("type") or "text"
            if name or iid:
                print(f"    input type={typ}  id='{iid}'  name='{name}'  value='{val}'")

        # ── Step 1: Select checkbox for the first card ───────────────────────
        chk = None
        for locator in [
            (By.XPATH, "//input[@type='checkbox' and (@name='AdjustInventoryCards_1_$CheckboxCardGID' or @id='AdjustInventoryCards_1_$CheckboxCardGID')]"),
            (By.XPATH, "(//input[@type='checkbox' and (contains(@name,'CheckboxCard') or contains(@id,'CheckboxCard'))])[1]"),
            (By.XPATH, "(//input[@type='checkbox' and contains(@name,'AdjustInventory')])[1]"),
            (By.XPATH, "(//td//input[@type='checkbox'])[1]"),
            (By.XPATH, "(//input[@type='checkbox'])[1]"),
        ]:
            try:
                chk = WebDriverWait(driver, 8).until(EC.presence_of_element_located(locator))
                break
            except Exception:
                continue

        if chk:
            scroll_to(driver, chk)
            if not chk.is_selected():
                driver.execute_script("arguments[0].click()", chk)
                time.sleep(0.5)
            chk_name = chk.get_attribute("name") or chk.get_attribute("id") or "unknown"
            print(f"  [INFO] Checkbox selected: '{chk_name}'")
        else:
            print("  [WARN] Checkbox not found — proceeding without selection")

        time.sleep(0.5)

        # ── Step 2: Current Location ─────────────────────────────────────────
        curr_inp = None
        for locator in [
            (By.XPATH, "(//input[contains(@id,'TextboxCurrentLocation') or contains(@name,'TextboxCurrentLocation')])[1]"),
            (By.XPATH, "(//input[contains(@id,'CurrentLocation') or contains(@name,'CurrentLocation')])[1]"),
        ]:
            try:
                curr_inp = driver.find_element(*locator)
                break
            except Exception:
                continue

        if curr_inp:
            scroll_to(driver, curr_inp)
            curr_val = curr_inp.get_attribute("value") or ""
            if not curr_val:
                driver.execute_script("arguments[0].value = '';", curr_inp)
                curr_inp.send_keys(CURRENT_LOCATION)
                driver.execute_script("arguments[0].dispatchEvent(new Event('change', {bubbles:true}));", curr_inp)
                print(f"  [INFO] Set Current Location = '{CURRENT_LOCATION}'")
            else:
                print(f"  [INFO] Current Location already = '{curr_val}' (keeping)")

        # ── Step 3: Adjust Qty — find field, clear & set to ADJUST_QTY ───────
        adj_inp = None

        # Try indexed name patterns first (card index 1..5)
        for idx in range(1, 6):
            for pat in [
                f"AdjustInventoryCards_{idx}_$TextboxAdjustQty",
                f"AdjustInventoryCards_{idx}_$AdjustQty",
                f"AdjustInventoryCards_{idx}_$TextboxAdjustQuantity",
                f"AdjustInventoryCards_{idx}_$AdjustQuantity",
            ]:
                try:
                    el = driver.find_element(By.XPATH, f"//input[@name='{pat}' or @id='{pat}']")
                    adj_inp = el
                    print(f"  [INFO] Found Adjust Qty input by pattern: '{pat}'")
                    break
                except Exception:
                    continue
            if adj_inp:
                break

        # Fallback: any input whose name/id contains AdjustQty / AdjustQuantity
        if adj_inp is None:
            for locator in [
                (By.XPATH, "(//input[contains(@id,'AdjustQty') or contains(@name,'AdjustQty')])[1]"),
                (By.XPATH, "(//input[contains(@id,'AdjustQuantity') or contains(@name,'AdjustQuantity')])[1]"),
                (By.XPATH, "(//input[contains(@id,'Adjust') or contains(@name,'Adjust')])[1]"),
            ]:
                try:
                    adj_inp = driver.find_element(*locator)
                    name = adj_inp.get_attribute("name") or adj_inp.get_attribute("id")
                    print(f"  [INFO] Found Adjust Qty input via fallback: '{name}'")
                    break
                except Exception:
                    continue

        assert adj_inp is not None, "Adjust Qty input not found on page"

        scroll_to(driver, adj_inp)
        driver.execute_script("arguments[0].select();", adj_inp)
        time.sleep(0.2)
        adj_inp.send_keys(ADJUST_QTY)
        
        # Trigger JS change/input events so the framework registers the update
        driver.execute_script(
            "arguments[0].dispatchEvent(new Event('input',  {bubbles:true}));"
            "arguments[0].dispatchEvent(new Event('change', {bubbles:true}));",
            adj_inp
        )
        time.sleep(0.3)
        entered_val = adj_inp.get_attribute("value") or ""
        print(f"  [INFO] Adjust Qty field value after entry = '{entered_val}'")
        assert entered_val == ADJUST_QTY, f"Adjust Qty not set correctly. Expected '{ADJUST_QTY}', got '{entered_val}'"

        take_screenshot(driver, "05a_card_selected_qty_set")

        # ── Step 4: Click Adjust Inventory button ────────────────────────────
        adj_btn = None
        for locator in [
            (By.XPATH, "//button[normalize-space(text())='Adjust Inventory']"),
            (By.XPATH, "//button[contains(normalize-space(),'Adjust Inventory')]"),
            (By.XPATH, "//a[normalize-space(text())='Adjust Inventory' and not(contains(@href,'AdjustInventoryItem'))]"),
            (By.XPATH, "//a[contains(normalize-space(),'Adjust Inventory') and not(contains(@href,'AdjustInventoryItem'))]"),
            (By.XPATH, "//*[@id='btnAdjustInventory' or contains(@id,'btnAdjust')]"),
            (By.XPATH, "//input[@value='Adjust Inventory']"),
        ]:
            try:
                adj_btn = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(locator))
                break
            except Exception:
                continue

        assert adj_btn, "Adjust Inventory button not found on cards page"
        scroll_to(driver, adj_btn)
        print(f"  [INFO] Clicking Adjust Inventory button: '{adj_btn.text.strip()}'")
        driver.execute_script("arguments[0].click()", adj_btn)
        wait_ready(driver)
        time.sleep(PAUSE * 2)

        take_screenshot(driver, "05b_after_adjust_inventory")
        print(f"  [URL] {driver.current_url}")
        assert "AdjustInventory" in driver.current_url or "BuyerAction" in driver.current_url, \
            f"Unexpected URL after Adjust Inventory: {driver.current_url}"
        print(f"  [PASS] Adjust Inventory action completed with Qty = {ADJUST_QTY}.")

    # ── TC-AI-006: Click Back to Items ───────────────────────────────────
    def test_06_back_to_items(self, driver):
        """Click Back To Items from the cards page and verify return to Items List."""
        print("\n[TC-AI-006] Clicking Back to Items...")
        print(f"  [INFO] Currently on: {driver.current_url}")

        if "AdjustInventoryCard" not in driver.current_url:
            print("  [INFO] Navigating to AdjustInventoryItems to load items grid...")
            driver.get(f"{BASE_URL}/BuyerAction/AdjustInventoryItems")
            wait_ready(driver)
            time.sleep(PAUSE * 2)
            print(f"  [INFO] URL: {driver.current_url}")

        # Wait for GridLink items
        try:
            item_links = WebDriverWait(driver, 20).until(
                EC.presence_of_all_elements_located((By.XPATH, "//a[contains(@class,'GridLink')]"))
            )
        except Exception:
            # Fallback: try the filter page
            driver.get(f"{BASE_URL}/BuyerAction/AdjustInventoryFilter")
            wait_ready(driver)
            time.sleep(PAUSE * 2)
            item_links = WebDriverWait(driver, 20).until(
                EC.presence_of_all_elements_located((By.XPATH, "//a[contains(@class,'GridLink')]"))
            )

        assert item_links, "No items found on Adjust Inventory Items page"
        first_item = item_links[0]
        for lnk in item_links:
            if "00kantest" in lnk.text.lower():
                first_item = lnk
                break
                
        print(f"  [INFO] Clicking item: '{first_item.text.strip()}'")
        scroll_to(driver, first_item)
        driver.execute_script("arguments[0].click()", first_item)
        wait_ready(driver)
        time.sleep(PAUSE * 2)
        print(f"  [INFO] URL after item click: {driver.current_url}")

        # Now click Back To Items from the cards page
        back_btn = None
        for locator in [
            (By.XPATH, "//button[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.XPATH, "//a[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.XPATH, "//span[contains(normalize-space(),'Back To Items') or contains(normalize-space(),'Back to Items')]"),
            (By.ID, "btnBackPageTop"),
            (By.ID, "btnBackPageBot"),
            (By.XPATH, "//*[contains(@onclick,'BackToItems') or contains(@href,'AdjustInventoryItem')]"),
        ]:
            try:
                back_btn = WebDriverWait(driver, 6).until(EC.element_to_be_clickable(locator))
                break
            except Exception:
                continue

        if back_btn is None:
            print("  [INFO] Back To Items button not visible — navigating directly to AdjustInventoryItems.")
            driver.get(f"{BASE_URL}/BuyerAction/AdjustInventoryItems")
            wait_ready(driver)
            time.sleep(PAUSE)
        else:
            scroll_to(driver, back_btn)
            print(f"  [INFO] Clicking Back To Items: '{back_btn.text.strip()}'")
            driver.execute_script("arguments[0].click()", back_btn)
            wait_ready(driver)
            time.sleep(PAUSE * 2)

        take_screenshot(driver, "06_back_to_items")
        current_url = driver.current_url
        print(f"  [URL] {current_url}")
        assert "AdjustInventory" in current_url, f"Expected Adjust Inventory Items page. Got: {current_url}"
        print(f"  [PASS] Returned to Adjust Inventory Items List: {current_url}")