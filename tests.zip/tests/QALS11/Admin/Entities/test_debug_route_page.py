import pytest

if __name__ != "__main__":
    pytest.skip("Debug utility script is not part of automated pytest collection.", allow_module_level=True)

import re
from Admin.UserGroup import login
from utils.driver_setup import get_driver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
import pytest

"""

Open Route Add form and dump all input/textarea/select field names.

"""

import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@pytest.fixture(scope="class")
def setup_driver():

    driver = get_driver()

    wait = WebDriverWait(driver, 20)

    yield driver, wait

    driver.quit()


ADMIN_BASE = "https://engineering.ultrivalms.com/QALS1011"

ROUTE_LIST = f"{ADMIN_BASE}/Entity/List?tk=$Routes&busGID=BSU22ZAQALQG&A~1~ABC&"

driver = get_driver()

wait = WebDriverWait(driver, 30)

try:

    login(driver, wait)

    print(f"[LOGIN] {driver.current_url}")

    driver.get(ROUTE_LIST)

    time.sleep(3)

    print(f"[ROUTE LIST] {driver.current_url}")

    # Click Add button

    add_btn = wait.until(EC.element_to_be_clickable(

        (By.XPATH, "//button[contains(.,'Add')] | //a[contains(.,'Add')]")))

    driver.execute_script("arguments[0].click();", add_btn)

    print("[+] Clicked Add button")

    time.sleep(3)

    print(f"[AFTER ADD] URL: {driver.current_url}")

    # Dump all inputs

    inputs = driver.find_elements(By.TAG_NAME, "input")

    print(f"\n[INPUTS] found {len(inputs)}")

    for i in inputs:

        print(
            f"  name='{
                i.get_attribute('name')}'  id='{
                i.get_attribute('id')}'  type='{
                i.get_attribute('type')}'  placeholder='{
                    i.get_attribute('placeholder')}'")

    textareas = driver.find_elements(By.TAG_NAME, "textarea")

    print(f"\n[TEXTAREAS] found {len(textareas)}")

    for t in textareas:

        print(
            f"  name='{
                t.get_attribute('name')}'  id='{
                t.get_attribute('id')}'")

    selects = driver.find_elements(By.TAG_NAME, "select")

    print(f"\n[SELECTS] found {len(selects)}")

    for s in selects:

        print(
            f"  name='{
                s.get_attribute('name')}'  id='{
                s.get_attribute('id')}'")

    # Buttons on form

    btns = driver.find_elements(By.TAG_NAME, "button")

    print(f"\n[BUTTONS] {len(btns)}")

    for b in btns:

        print(f"  text='{b.text.strip()}'  class='{b.get_attribute('class')}'")

    # Spans/anchors that look like buttons

    spans = driver.find_elements(
        By.XPATH,
        "//span[contains(@class,'btn') or contains(@class,'save') or contains(@class,'Save')]")

    print(f"\n[BTN SPANS] {len(spans)}")

    for s in spans:

        print(f"  text='{s.text.strip()}'  class='{s.get_attribute('class')}'")

finally:

    driver.quit()

    print("\n[DONE]")


sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@pytest.fixture(scope="class")
def setup_driver():

    driver = get_driver()

    wait = WebDriverWait(driver, 20)

    yield driver, wait

    driver.quit()


ADMIN_BASE = "https://engineering.ultrivalms.com/QALS1011"

driver = get_driver()

wait = WebDriverWait(driver, 30)

try:

    login(driver, wait)

    print(f"[LOGIN] {driver.current_url}")

    # Go to Entity/List (no tk= param) and wait for content

    driver.get(f"{ADMIN_BASE}/Entity/List")

    time.sleep(5)   # let the page and AJAX settle

    print(f"[ENTITY LIST] URL: {driver.current_url}")

    print(f"[ENTITY LIST] Title: {driver.title}")

    # Check for iframes

    iframes = driver.find_elements(By.TAG_NAME, "iframe")

    print(f"\n[IFRAMES] found {len(iframes)}")

    for i, fr in enumerate(iframes):

        print(
            f"  iframe[{i}] src='{
                fr.get_attribute('src')}' id='{
                fr.get_attribute('id')}'")

    # ── Dump ALL text links ────────────────────────────────────────────────

    all_links = driver.find_elements(By.TAG_NAME, "a")

    print(f"\n[ALL LINKS] found {len(all_links)}")

    for a in all_links:

        txt = (a.text or "").strip()

        href = a.get_attribute("href") or ""

        if txt or href:

            print(f"  text='{txt}'  href='{href}'")

    # ── Look for Route in any element ──────────────────────────────────────

    all_els = driver.find_elements(
        By.XPATH, "//*[contains(translate(text(),'route','ROUTE'),'ROUTE')]")

    print(f"\n[ELEMENTS containing 'Route'] found {len(all_els)}")

    for el in all_els:

        print(
            f"  tag={
                el.tag_name}  text='{
                el.text.strip()}'  href='{
                el.get_attribute('href')}'")

    # ── tk= keys anywhere in page source ──────────────────────────────────

    src = driver.page_source

    tks = re.findall(r'tk=\$([A-Za-z0-9_]+)', src)

    print(f"\n[tk= KEYS in page source]: {sorted(set(tks))}")

    # Also look for 'Route' anywhere in source

    idx = src.lower().find("route")

    if idx >= 0:

        print(
            f"\n[SRC 'route' context]: ...{src[max(0, idx - 100):idx + 200]}...")

    else:

        print("\n[SRC] 'route' NOT found in page source")

    # ── Try switching into any iframe and repeat search ───────────────────

    for i, fr in enumerate(iframes):

        try:

            driver.switch_to.frame(fr)

            print(f"\n[IN IFRAME {i}]")

            tks2 = re.findall(r'tk=\$([A-Za-z0-9_]+)', driver.page_source)

            print(f"  tk= KEYS: {sorted(set(tks2))}")

            idx2 = driver.page_source.lower().find("route")

            if idx2 >= 0:

                print(f"  'route' found in iframe source!")

            links2 = driver.find_elements(By.TAG_NAME, "a")

            for a in links2:

                txt = (a.text or "").strip()

                href = a.get_attribute("href") or ""

                if txt or "tk=" in href:

                    print(f"  a: '{txt}' -> {href}")

            driver.switch_to.default_content()

        except Exception as ex:

            print(f"  iframe {i} error: {ex}")

            driver.switch_to.default_content()

    # ── Try clicking "Entities" link and wait for Route in nav ───────────

    try:

        ent_link = wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//a[contains(text(),'Entities') or contains(@href,'Entity')]")))

        ent_link.click()

        time.sleep(3)

        print(f"\n[AFTER CLICK Entities] URL: {driver.current_url}")

        nav_links = driver.find_elements(By.TAG_NAME, "a")

        print(f"Links in nav after click ({len(nav_links)}):")

        for a in nav_links:

            txt = (a.text or "").strip()

            href = a.get_attribute("href") or ""

            if txt or "tk=" in href:

                print(f"  '{txt}' -> {href}")

    except Exception as ex:

        print(f"[CLICK Entities] error: {ex}")

finally:

    driver.quit()

    print("\n[DONE]")

